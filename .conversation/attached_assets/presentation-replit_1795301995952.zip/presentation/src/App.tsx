import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, MotionConfig } from 'motion/react';
import { ArrowUpRight, ArrowRight, ArrowLeft, RotateCcw, Maximize2, Minimize2, X, Layers3, ChevronDown, Pause, Play } from 'lucide-react';
import { scenes, narrativeScenes, narrativeCount, type PresentationState } from './state/presentation';
import { MathEquation } from './components/MathEquation';
import { formulas, pipeline, slopes } from './data';
const ResearchStage = lazy(() => import('./three/ResearchStage'));
import { headingForState } from './three/sceneLayout';
import { sceneControls, type SceneCommand } from './sceneControls';
import { useLiveSession } from './live/useLiveSession';
import { LiveSessionButton, LiveSessionDialog, LiveStatus } from './live/LiveSessionUI';
function Eq({name}:{name:keyof typeof formulas}){return <MathEquation tex={formulas[name]} label={name==='fitted'?'The fitted Jacobian lens averages Jacobians across examples and token positions':name}/>}
function Copy({state}:{state:PresentationState}){
  const {scene,beat}=state;const current=scenes[scene];
  return <div className="scene-copy">
    <h1 className="accessible-scene-title">{headingForState(state).join(' ')}</h1>
    <AnimatePresence mode="wait" initial={false}><motion.div key={`${scene}-${beat}`} initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-6}} transition={{duration:.25}} className="beat-copy">
      {current.caption&&<p className={current.exhibit==='workspace'?'accessible-scene-title':'lede'}>{current.caption}</p>}
      {current.id==='jspace'&&<>
        <div className="split-equations"><Eq name="fitted"/><Eq name="decomposition"/></div>
      </>}
      {current.id==='engineering'&&<div className="stats"><div><strong>11</strong><span>text models</span></div><div><strong>4</strong><span>vision encoders</span></div><div><strong>10<small>GB</small></strong><span>one RTX 3080</span></div></div>}
    </motion.div></AnimatePresence>
  </div>;
}
function AccessibleResult({state}:{state:PresentationState}){
  if(scenes[state.scene].id==='retention')return <p className="accessible-scene-title">Keep the structure, but scramble the content words. Traditional alignment retained: normal content 100 percent; randomised content 54.1 percent. More than half remains. We seek a measure that tracks meaningful alignment.</p>;
  if(scenes[state.scene].exhibit!=='results')return null;
  const text=scenes[state.scene].id==='content'?'Alignment retained: full activation 54.1 percent; J-space component 26.3 percent. The gap is 27.8 percentage points.':`Regression slopes: full activation +${slopes[state.modality][0]}; J-space +${slopes[state.modality][1]}. Alignment increase per unit HellaSwag accuracy. Axis from zero to ${state.modality==='vision'?'0.2':'0.8'}.`;
  return <p className="accessible-scene-title">{text}</p>;
}
function Engineering({state}:{state:PresentationState}){
  const p=pipeline[state.pipeline];
  return <div className="engineering-panel">
    <AnimatePresence mode="wait"><motion.div key={state.pipeline} className="pipeline-detail" initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0}}><div className="detail-heading"><span className="ownership"><span/>Implemented by me</span></div><h2>{p.detail}</h2><div className="pipeline-explanation"><p>{p.decision}</p><p>{p.reason}</p><p>{p.tradeoff}</p></div></motion.div></AnimatePresence>
  </div>;
}
function Drawer({type,onClose}:{type:string|null;onClose:()=>void}){
  const ref=useRef<HTMLDialogElement>(null);
  useEffect(()=>{if(type){ref.current?.showModal()}else ref.current?.close();},[type]);
  return <dialog ref={ref} className="drawer" onCancel={onClose} onClick={e=>{if(e.target===ref.current)onClose()}}><div className="drawer-inner"><button autoFocus className="icon-button close" onClick={onClose} aria-label="Close details"><X size={20}/></button>
    {type==='paper'&&<><h2>How much of Platonic convergence is semantic?</h2><p className="drawer-sub">Measuring Alignment in the Jacobian Subspace</p><p>Alexander Zhang · Michael Shihong Zhang</p><div className="resource-links"><a href={`${import.meta.env.BASE_URL}paper.pdf`} target="_blank" rel="noreferrer">Read the paper <ArrowUpRight size={18}/></a><a href="https://github.com/excelexx/jspace-convergence" target="_blank" rel="noreferrer">View research code <ArrowUpRight size={18}/></a></div><h3>Measurements used here</h3><p>Retention percentages: Table 1, over 1,000 documents and 55 language-model pairs.</p><p>Convergence slopes: Figure 2 and Section 4.1–4.2. Slopes are reported per unit HellaSwag accuracy; they are not correlation coefficients.</p><p>All 3D animations are schematic. The numeric charts use reported experimental results.</p></>}
    {type==='ownership'&&<><h2>My contribution</h2><p>I implemented all stages of the experimental pipeline, from activation extraction and decomposition to alignment measurement and analysis.</p><p>My coauthor, Michael Shihong Zhang, contributed minor final edits.</p><p>The J-lens itself is an existing method. This project uses it to investigate convergence between models.</p></>}
  </div></dialog>
}
export default function App(){
  const live=useLiveSession(),{state,send:dispatch}=live;const [sharingOpen,setSharingOpen]=useState(false);const [drawer,setDrawer]=useState<string|null>(null);const [menu,setMenu]=useState(false);
  const [reduced,setReduced]=useState(()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches);const [fullscreen,setFullscreen]=useState(false);const [notice,setNotice]=useState('');
  const current=scenes[state.scene],splitReplay=live.replay;
  const command=(action:SceneCommand)=>{if(action.type==='details')setDrawer(action.value);else if(live.canControl)dispatch(action);};
  useEffect(()=>{if(!live.canControl)setMenu(false);},[live.canControl]);
  useEffect(()=>{const media=window.matchMedia('(prefers-reduced-motion: reduce)');const f=(e:MediaQueryListEvent)=>setReduced(e.matches);media.addEventListener('change',f);return()=>media.removeEventListener('change',f);},[]);
  async function toggleFull(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{setNotice('Fullscreen is unavailable here. Open the preview in a browser window.');}}
  useEffect(()=>{const fn=()=>setFullscreen(!!document.fullscreenElement);document.addEventListener('fullscreenchange',fn);return()=>document.removeEventListener('fullscreenchange',fn)},[]);
  useEffect(()=>{const fn=(e:KeyboardEvent)=>{
    if(e.key==='Escape'){setMenu(false);return;}
    if(sharingOpen||!live.canControl||drawer||e.target instanceof Element&&e.target.closest('input,textarea,select,[contenteditable]'))return;
    if(e.key===' '&&e.target instanceof Element&&e.target.closest('button,a'))return;
    if(e.key==='ArrowRight'||e.key===' '){e.preventDefault();dispatch({type:'next'});}if(e.key==='ArrowLeft'){e.preventDefault();dispatch({type:'back'});}if(e.key==='Home'){e.preventDefault();if(live.canControl)dispatch({type:'jump',scene:0});}if(e.key.toLowerCase()==='f')void toggleFull();
  };window.addEventListener('keydown',fn);return()=>window.removeEventListener('keydown',fn)},[drawer,sharingOpen,live.canControl,dispatch]);
  return <MotionConfig reducedMotion={reduced?'always':'never'}><div className={`app scene-${state.scene} exhibit-${current.exhibit} ${reduced?'reduced-motion':''} ${live.role!=='local'?'has-live-session':''} ${live.role==='audience'&&live.following?'audience-following':''}`}>
    <header className="topbar"><a className="brand" href="#" onClick={e=>{e.preventDefault();if(live.canControl)dispatch({type:'jump',scene:0})}} aria-label="Return to opening"><span className="brand-mark"><Layers3 size={19}/></span></a><div className="top-actions"><LiveSessionButton live={live} onClick={()=>setSharingOpen(true)}/><button className="text-button paper-link" onClick={()=>setDrawer('paper')}>The paper <ArrowUpRight size={14}/></button><span className="toolbar-divider"/><button className="icon-button" onClick={()=>setReduced(v=>!v)} title={reduced?'Enable motion':'Pause ambient motion'} aria-label={reduced?'Enable motion':'Pause ambient motion'}>{reduced?<Play size={16}/>:<Pause size={16}/>}</button><button className="icon-button" onClick={()=>void toggleFull()} aria-label="Toggle fullscreen">{fullscreen?<Minimize2 size={16}/>:<Maximize2 size={16}/>}</button></div></header>
    <main className="presentation-body spatial-body" aria-label={current.label}>
      <div className="world-canvas"><Suspense fallback={<div className="loading-stage">Loading…</div>}><ResearchStage state={state} reduced={reduced} replay={splitReplay} onCommand={command} interactive={live.canControl}/></Suspense></div>
      <AnimatePresence mode="wait" initial={false}><motion.section key={state.scene} className="copy-region" data-spatial="copy" data-scene={state.scene} initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} transition={{duration:.3}}><Copy state={state}/><AccessibleResult state={state}/></motion.section></AnimatePresence>
      {current.id==='engineering'&&<section data-spatial="visual" data-scene={state.scene} className="visual-region" aria-label="Implementation details"><Engineering state={state}/></section>}
      <div className="accessible-scene-controls" aria-label="Controls for the 3D scene">{sceneControls(state).map(c=><button key={c.label} aria-pressed={c.active} disabled={!live.canControl} onClick={()=>command(c.command)}>{c.label}</button>)}</div>
        </main>
    <footer className="presentation-footer">
      <div className="footer-nav"><div className="scene-switcher"><button className="scene-trigger" disabled={!live.canControl} onClick={()=>setMenu(v=>!v)} aria-expanded={menu}><span>{current.appendix?'Appendix':<>{String(state.scene+1).padStart(2,'0')}<span className="muted"> / {narrativeCount}</span></>}</span><span>{current.label}</span><ChevronDown size={14}/></button>{menu&&<div className="scene-menu">{scenes.map((s,i)=><button key={s.id} className={state.scene===i?'active':''} onClick={()=>{dispatch({type:'jump',scene:i});setMenu(false)}}><span>{s.appendix?'A':String(i+1).padStart(2,'0')}</span>{s.label}</button>)}</div>}</div>
        <div className="scene-rail">{narrativeScenes.map((s,i)=><button key={s.id} className={`${i===state.scene?'active':''} ${i<state.scene?'completed':''}`} onClick={()=>dispatch({type:'jump',scene:i})} disabled={!live.canControl} title={s.label} aria-label={`Go to ${s.label}`} aria-current={state.scene===i?'step':undefined}><span/></button>)}</div>
        <div className="step-buttons">{current.count>1&&<span className="beat-count">{state.beat+1}<span> / {current.count}</span></span>}<button className="icon-button back-button" aria-label="Previous reveal" disabled={!live.canControl||(state.scene===0&&state.beat===0)} onClick={()=>dispatch({type:'back'})}><ArrowLeft size={18}/></button><button className="next-button" disabled={!live.canControl} aria-label={current.beats[state.beat]} onClick={()=>dispatch({type:'next'})}>{state.scene===narrativeCount-1?<RotateCcw size={16}/>:<ArrowRight size={16}/>}</button></div>
      </div>
    </footer><LiveStatus live={live}/><LiveSessionDialog live={live} open={sharingOpen} onClose={()=>setSharingOpen(false)}/><Drawer type={drawer} onClose={()=>setDrawer(null)}/>{notice&&<button className="notice" onClick={()=>setNotice('')}>{notice} <X size={14}/></button>}
  </div></MotionConfig>
}
