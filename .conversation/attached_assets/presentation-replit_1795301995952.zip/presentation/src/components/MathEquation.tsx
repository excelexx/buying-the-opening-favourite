import { useMemo } from 'react';
import katex from 'katex';
export function MathEquation({ tex, label }: { tex: string; label: string }) {
  const html = useMemo(() => katex.renderToString(tex, { displayMode: true, throwOnError: true, output: 'htmlAndMathml', strict: 'ignore', trust: false }), [tex]);
  return <div className="math-equation" role="group" aria-label={label} dangerouslySetInnerHTML={{ __html: html }} />;
}
