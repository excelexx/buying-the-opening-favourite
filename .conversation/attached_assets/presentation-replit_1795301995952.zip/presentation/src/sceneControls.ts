import { pipeline } from './data';
import { scenes, sceneIndex, type Action, type PresentationState } from './state/presentation';
export type SceneCommand = Action | { type: 'replay' } | { type: 'details'; value: 'ownership' };
export type SceneControl = { label: string; position: [number, number, number]; width?: number; size?: number; color?: string; active?: boolean; command: SceneCommand };
export function sceneControls(state: PresentationState): SceneControl[] {
  const id=scenes[state.scene].id;
  if(id==='convergence')return [{label:'Replay',position:[3.2,-2,3.2],width:1.5,command:{type:'replay'}}];
  if(id==='alignment')return [{label:'Replay comparison',position:[3.2,-2,3.2],width:2.5,command:{type:'replay'}}];
  if(id==='retention')return ['Original','Randomised'].map((label,i)=>({label,position:[2.9+(i-.5)*2.05,-1.85,3.05],active:state.randomised===!!i,command:{type:'randomise',value:!!i}}));
  if(id==='workspace')return [{label:'Replay the decision',position:[3.2,-2.05,3.05],width:2.6,color:'#ffbd69',command:{type:'replay'}}];
  if(id==='vision')return [{label:'How I built it',position:[3.2,-1.95,1.3],width:2.5,command:{type:'jump',scene:sceneIndex('engineering')}}];
  if(id==='engineering')return [
    ...pipeline.map((p,i)=>({label:p.title,position:[3.2+(i-2)*1.5,1.4,.8] as [number,number,number],width:1.4,active:state.pipeline===i,command:{type:'pipeline' as const,value:i}})),
    {label:'Research contributions',position:[3.2,-1.8,3],width:3.2,command:{type:'details',value:'ownership'}},
  ];
  return [];
}
