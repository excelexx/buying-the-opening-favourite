import { Component, Suspense, useEffect, useMemo, useRef, useState, type ReactNode, type RefObject } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Line, RoundedBox, Text, Text3D, useFont, Billboard } from '@react-three/drei';
import * as THREE from 'three';
import { scenes, stateAt, type PresentationState } from '../state/presentation';
import { slopes, retention } from '../data';
import SceneButton from './SceneButton';
import { sceneControls, type SceneCommand } from '../sceneControls';
import WordField from './WordField';
import GlobalWorkspaceExhibit from './GlobalWorkspaceExhibit';
import ImplicationsExhibit from './ImplicationsExhibit';
import { IdeasExhibit, ConvergenceExhibit } from './RepresentationExhibits';
import NeighbourhoodExhibit from './NeighbourhoodExhibit';
import AlignmentBars from './AlignmentBars';
import { schematicDirection, representationCount } from './representationDirections';
import { stations, headingForState } from './sceneLayout';

const CYAN = '#62d8f5', AMBER = '#ffbd69';
const fontUrl = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
const colors = [CYAN, '#80ebbe', '#bbd7ff', AMBER, '#b5a2ed', '#e5c9af'];
const vec = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
function smooth(current: number, target: number, dt: number, reduced = false) { return reduced ? target : THREE.MathUtils.damp(current, target, 5, Math.min(dt, .05)); }
function Glow({ color = CYAN, size = 1, position = [0, 0, 0] }: { color?: string; size?: number; position?: [number, number, number] }) {
  const texture = useMemo(() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const ctx = c.getContext('2d')!; const g = ctx.createRadialGradient(32,32,0,32,32,32);
    g.addColorStop(0,'rgba(255,255,255,.8)'); g.addColorStop(.15,'rgba(255,255,255,.3)'); g.addColorStop(1,'rgba(255,255,255,0)');
    ctx.fillStyle=g;ctx.fillRect(0,0,64,64); return new THREE.CanvasTexture(c);
  }, []);
  useEffect(() => () => texture.dispose(), [texture]);
  return <sprite position={position} scale={[size,size,1]}><spriteMaterial map={texture} color={color} transparent opacity={.6} depthWrite={false} blending={THREE.AdditiveBlending}/></sprite>;
}

function Floor() {
  return <group>
    <mesh position={[0,-2.25,-(stations.length-1)*11]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[40,stations.length*22+70]}/><meshStandardMaterial color="#172330" roughness={.85} metalness={.08}/></mesh>
    {Array.from({length:13},(_,i)=>i*2-12).map(x=><Line key={`x${x}`} points={[[x,-2.235,25],[x,-2.235,-stations.length*22-20]]} color="#55768a" transparent opacity={.25} lineWidth={.65}/>)}
    {Array.from({length:stations.length*11+28},(_,i)=>25-i*2).map(z=><Line key={`z${z}`} points={[[-12,-2.235,z],[12,-2.235,z]]} color="#55768a" transparent opacity={.2} lineWidth={.6}/>)}
    {stations.map(([x,z],i)=><mesh key={i} rotation={[-Math.PI/2,0,0]} position={[x+2.9,-2.22,z]}><ringGeometry args={[4.2,4.22,100]}/><meshBasicMaterial color={['wordfield','workspace'].includes(scenes[i].exhibit)?AMBER:CYAN} transparent opacity={.28}/></mesh>)}
    {stations.map((_,i)=>-10-i*22).map(z=><group key={z}>
      {[-11,11].map(x=><group key={x} position={[x,1.9,z]}><mesh><boxGeometry args={[.09,8.3,.12]}/><meshStandardMaterial color="#294256" metalness={.6} roughness={.4}/></mesh><Line points={[[0,-4.15,.07],[0,4.15,.07]]} color="#73b5cb" transparent opacity={.25} lineWidth={.7}/></group>)}
      <mesh position={[0,6.05,z]}><boxGeometry args={[22,.08,.12]}/><meshStandardMaterial color="#294256" metalness={.6} roughness={.4}/></mesh>
    </group>)}
  </group>;
}
function FloatingHeading({state}:{state:PresentationState}){
  const warm=['wordfield','workspace'].includes(scenes[state.scene].exhibit), headingLines=headingForState(state);
  const font=useFont(`${import.meta.env.BASE_URL}fonts/heading.typeface.json`);
  const {size}=useThree();
  const mobile=size.width<800;
  const lines=mobile?headingLines.join(' ').split(' ').reduce<string[]>((rows,word)=>{const last=rows.length-1;if(rows[last]&&rows[last].length+word.length<32)rows[last]+=` ${word}`;else rows.push(word);return rows;},[]):headingLines;
  const fontSize=mobile?.36:.57;
  const widest=Math.max(...lines.map(line=>Array.from(line).reduce((sum,ch)=>sum+(font.data.glyphs[ch]?.ha??font.data.glyphs['?'].ha),0)/font.data.resolution*fontSize));
  const scale=Math.min(1,(mobile?4.2:12.5)/widest);
  return <group position={mobile?[.8,4.2,.15]:[-5.6,scenes[state.scene].exhibit==='workspace'||['content','language'].includes(scenes[state.scene].id)?3.75:3.35,.15]} rotation={[0,-.08,0]} scale={scale}>
    {lines.map((line,i)=><Text3D key={line} font={font.data} size={fontSize} height={.06} bevelEnabled bevelThickness={.006} bevelSize={.004} bevelSegments={2} curveSegments={8} position={[0,-i*(mobile?.52:.78),0]}>
      {line}
      <meshStandardMaterial attach="material-0" color={i===lines.length-1?(warm?AMBER:CYAN):'#e8f1f6'} emissive={i===lines.length-1?(warm?AMBER:CYAN):'#9bb8d1'} emissiveIntensity={.22} metalness={.18} roughness={.4}/>
      <meshStandardMaterial attach="material-1" color="#2b5b73" metalness={.5} roughness={.3}/>
    </Text3D>)}
  </group>;
}
function CameraRig({ state, reduced, arrivedScene }: {state:PresentationState; reduced:boolean; arrivedScene:RefObject<number|null>}) {
  const { camera,pointer,size }=useThree();const look=useRef(vec(0,.25,0));
  const anchors=useMemo(()=>({copy:vec(0,0,0),visual:vec(0,0,0)}),[]);
  useFrame((_,dt)=>{
    const [cx,cz]=stations[state.scene];const mobile=size.width<800;
    const current=scenes[state.scene];const offset=current.id==='retention'?1.7:['wordfield','workspace'].includes(current.exhibit)?-.35:.8;
    const framing=Math.max(1,1.6*size.height/size.width);
    const dest=vec(cx+offset+(reduced?0:pointer.x*.12),.25+3.05*framing+(reduced?0:pointer.y*.08),cz+14.5*framing);
    if(mobile){const depth=12.5;dest.set(cx+2.9,.25+3.05*depth/14.5,cz+depth);}
    camera.position.lerp(dest,reduced?1:1-Math.exp(-Math.min(dt,.05)*2.2));
    const target=vec(cx+(mobile?2.9:0),.25,cz);
    look.current.lerp(target,reduced?1:1-Math.exp(-Math.min(dt,.05)*3));camera.lookAt(look.current);camera.updateMatrixWorld();
    arrivedScene.current=camera.position.distanceTo(dest)<.3&&look.current.distanceTo(target)<.2?state.scene:null;
    if(mobile){document.querySelectorAll<HTMLElement>('[data-spatial]').forEach(el=>{el.style.visibility='visible'});return;}
    for(const el of document.querySelectorAll<HTMLElement>('[data-spatial]')){
      const name=el.dataset.spatial as 'copy'|'visual';
      const [ax,az]=stations[Number(el.dataset.scene)];
      anchors.copy.set(ax-4.4,-.8,az+1);anchors.visual.set(ax+3.2,.05,az+.5);
      const point=anchors[name].clone().project(camera);const distance=camera.position.distanceTo(anchors[name]);
      const scale=Math.min(1.2,Math.max(.12,size.height/900*15.3/distance));
      const yaw=THREE.MathUtils.clamp((camera.position.x-anchors[name].x)*.8,-8,8);
      el.style.left=`${(point.x*.5+.5)*size.width}px`;el.style.top=`${(-point.y*.5+.5)*size.height}px`;
      el.style.transform=`translate(-50%,-50%) perspective(1600px) rotateY(${yaw}deg) rotateX(2deg) scale(${scale})`;
      el.style.visibility=point.z>1?'hidden':'visible';
    }
  });
  return null;
}
function Model({ x, side, opened, active, reduced, pulseKey, dim = false, labelSize = .12 }: {x: number; side: number; opened: boolean; active: boolean; reduced: boolean; pulseKey: string; dim?: boolean; labelSize?: number}) {
  const group = useRef<THREE.Group>(null!); const layers=useRef<(THREE.Group|null)[]>([]); const materials=useRef<(THREE.MeshStandardMaterial|null)[]>([]); const phase=useRef(0); const lastPulse = useRef(-10);
  const { clock } = useThree();
  useEffect(() => { lastPulse.current = clock.elapsedTime; },[pulseKey,clock]);
  const n = side ? 7 : 6, color = side ? '#9dacef' : CYAN;
  useFrame((state,dt) => {
    phase.current = smooth(phase.current,opened ? 1:0,dt,reduced);
    group.current.position.y = (reduced ? 0 : Math.sin(state.clock.elapsedTime*.5+side)*.065) - phase.current*.4;
    group.current.rotation.y = (side ? -.25 : .2) + (reduced ? 0 : Math.sin(state.clock.elapsedTime*.12)*.07);
    layers.current.forEach((l,i)=>{ if(l) { l.position.y = (i-(n-1)/2)*(.21+phase.current*.065); l.rotation.y = phase.current*(i-(n-1)/2)*.065; } const material=materials.current[i]; if(material) { const t=state.clock.elapsedTime-lastPulse.current-1.05-i*.05; material.emissiveIntensity=.09+(active&&!reduced?Math.exp(-Math.pow(t/.16,2))*.7:0); } });
  });
  return <group position={[x,-.15,0]}>
    <group ref={group}>
      <mesh position={[0,-1.4,0]} rotation={[-Math.PI/2,0,0]}><ringGeometry args={[1.13,1.14,80]}/><meshBasicMaterial color={color} transparent opacity={.42}/></mesh>
      {Array.from({length:n},(_,i)=><group key={i} ref={el=>{layers.current[i]=el;}}>
        <RoundedBox args={[1.7,.055,1.5]} radius={.055} smoothness={3}><meshStandardMaterial ref={el=>{materials.current[i]=el;}} color={dim?'#172535':'#365e77'} emissive={color} emissiveIntensity={.09} metalness={.45} roughness={.3} transparent opacity={.84}/></RoundedBox>
        <Line points={[[-.82,.033,-.72],[.82,.033,-.72],[.82,.033,.72],[-.82,.033,.72],[-.82,.033,-.72]]} color={color} lineWidth={.8} transparent opacity={dim?.22:.85}/>
        {Array.from({length:9},(_,j)=>{
          const px=(j%3-1)*.51,pz=(Math.floor(j/3)-1)*.43;
          return <group key={j} position={[px,.05,pz]}><mesh><sphereGeometry args={[.028,8,8]}/><meshBasicMaterial color={active ? color : '#7aa1ba'} /></mesh>{i<n-1 && j%2===0 && <Line points={[[0,0,0],[.13,.21,-.1]]} color={color} lineWidth={.5} transparent opacity={.2}/>}</group>;
        })}
        {i===Math.floor(n/2)&&active&&<Glow color={color} size={1.4} position={[0,.1,0]}/>}
      </group>)}
      <mesh rotation={[Math.PI/2,0,0]} position={[0,-1.1,0]}><torusGeometry args={[.94,.006,8,80]}/><meshBasicMaterial color={color} transparent opacity={.25}/></mesh>
    </group>
    <Billboard position={[0,-1.55,.9]}><Text font={fontUrl} fontSize={labelSize} color={color} letterSpacing={.05}>{side ? 'Model B':'Model A'}</Text></Billboard>
  </group>;
}
function VectorArrow({ direction, color, emphasis, reduced, origin=[0,0,0], thin=false }: {direction:THREE.Vector3; color:string; emphasis:boolean; reduced:boolean; origin?:[number,number,number]; thin?:boolean}) {
  const group=useRef<THREE.Group>(null!); const body=useRef<THREE.Mesh>(null!); const head=useRef<THREE.Mesh>(null!); const end=useRef<THREE.Group>(null!); const current=useRef(vec(0,.01,0));
  const quaternion=useMemo(()=>new THREE.Quaternion(),[]);
  useFrame((_,dt)=>{
    current.current.lerp(direction,reduced?1:1-Math.exp(-dt*5)); const len=current.current.length();
    quaternion.setFromUnitVectors(vec(0,1,0),current.current.clone().normalize()); group.current.quaternion.copy(quaternion);
    body.current.scale.y=Math.max(.001,len-.13);body.current.position.y=(len-.13)/2;head.current.position.y=len-.055;end.current.position.y=len;
  });
  return <group position={origin}><group ref={group}>
    <mesh ref={body}><cylinderGeometry args={[thin?.008:emphasis?.023:.013,thin?.008:emphasis?.023:.013,1,10]}/><meshStandardMaterial color={color} emissive={color} emissiveIntensity={emphasis?.8:.3} transparent opacity={emphasis?1:.45}/></mesh>
    <mesh ref={head}><coneGeometry args={[emphasis?.08:.055,.16,12]}/><meshStandardMaterial color={color} emissive={color} emissiveIntensity={.5} transparent opacity={emphasis?1:.5}/></mesh>
    <group ref={end}>{emphasis&&<Glow color={color} size={.5}/>}</group>
  </group></group>;
}
function Fan({x,side,randomised,selected,compare,reduced}:{x:number;side:number;randomised:boolean;selected:number;compare:boolean;reduced:boolean}){
  const g=useRef<THREE.Group>(null!);
  useFrame((_,dt)=>{g.current.scale.lerp(vec(1,1,1),reduced?1:1-Math.exp(-dt*4));});
  return <group ref={g} position={[x,.45,0]} scale={.01}>
    <mesh><sphereGeometry args={[.07,16,16]}/><meshBasicMaterial color="#e7faff"/></mesh>
    <Glow size={.8}/>
    {Array.from({length:representationCount},(_,i)=><VectorArrow key={i} direction={vec(...schematicDirection(i,side,randomised))} color={colors[i]} emphasis={!compare||i===selected||(selected<3&&i<3)} reduced={reduced}/>)}
    {[vec(1.75,0,0),vec(0,1.9,0),vec(0,0,1.75)].map((v,i)=><Line key={i} points={[[0,0,0],v]} color="#587384" transparent opacity={.22} lineWidth={.5}/>)}
    {compare&&selected<3&&<mesh position={[.45,1.5,.1]}><sphereGeometry args={[.55,24,24]}/><meshBasicMaterial color={CYAN} transparent opacity={.055} depthWrite={false}/></mesh>}
  </group>;
}
function Pulse({ trigger,reduced }: {trigger:string;reduced:boolean}){
  const nodes=useRef<(THREE.Mesh|null)[]>([]);const start=useRef(0);const {clock}=useThree();
  const paths=useMemo(()=>[-1,1].map(sign=>new THREE.CatmullRomCurve3([vec(0,-.2,3.08),vec(0,.0,2),vec(sign*1.3,.15,1),vec(sign*2.05,.1,0)])),[]);
  useEffect(()=>{start.current=clock.elapsedTime;},[trigger,clock]);
  useFrame(({clock})=>{
    const t=(clock.elapsedTime-start.current)/1.3;
    nodes.current.forEach((m,i)=>{if(m){const progress=t-(i%7)*.022;m.visible=!reduced&&progress>=0&&progress<=1;m.position.copy(paths[Math.floor(i/7)].getPoint(Math.max(0,Math.min(1,progress))));}});
  });
  return <group>{paths.map((p,i)=><Line key={i} points={p.getPoints(50)} color={CYAN} lineWidth={.7} transparent opacity={.12}/>)}{Array.from({length:14},(_,i)=><mesh key={i} ref={el=>{nodes.current[i]=el;}}><sphereGeometry args={[i%7===0?.06:.033,10,10]}/><meshBasicMaterial color={i%7===0?'#e5fbff':CYAN} transparent opacity={1-(i%7)*.12}/></mesh>)}</group>;
}
function SentenceSurface({randomised, reduced, pulseKey, experiment=false}:{randomised:boolean; reduced:boolean; pulseKey:string; experiment?:boolean}) {
  const material=useRef<THREE.MeshStandardMaterial>(null!); const start=useRef(0); const {clock}=useThree();
  useEffect(()=>{start.current=clock.elapsedTime},[pulseKey,clock]);
  useFrame(({clock})=>{material.current.emissiveIntensity=.045+(reduced?0:Math.exp(-Math.pow((clock.elapsedTime-start.current-.1)/.22,2))*.3)});
  return <group position={[0,-.58,3]} rotation={[-.16,0,0]}>
    <RoundedBox args={[6.0,experiment?1.4:1.05,.12]} radius={.09} smoothness={3}><meshStandardMaterial ref={material} color="#153042" emissive={randomised?'#ffbd69':CYAN} emissiveIntensity={.045} metalness={.5} roughness={.24}/></RoundedBox>
    <Line points={[[-2.9,experiment?.65:.48,.068],[2.9,experiment?.65:.48,.068]]} color={randomised?AMBER:CYAN} transparent opacity={.55} lineWidth={1}/>
    {experiment&&<Text font={fontUrl} fontSize={.2} position={[0,.45,.08]} color="#d3e7f2">Keep the structure, but scramble the content words.</Text>}
    <Text font={fontUrl} fontSize={.245} lineHeight={1.4} maxWidth={5.45} textAlign="center" position={[0,experiment?-.15:-.03,.075]} color={randomised?'#ffd2a1':'#e0f3fc'}>{randomised?'Reduce that self each rates\nat their own special.':'Remember that children each progress\nat their own rate.'}</Text>
    {!experiment&&<mesh position={[0,.38,.09]}><sphereGeometry args={[.035,16,16]}/><meshBasicMaterial color={randomised?AMBER:CYAN}/></mesh>}
  </group>;
}
function ResultSculpture({state,reduced}:{state:PresentationState;reduced:boolean}){
  const {size}=useThree();
  const content=scenes[state.scene].id==='content', vision=state.modality==='vision';
  const values=content?retention.map(r=>r.value):slopes[state.modality];
  const limit=content?100:vision?.2:.8, height=content?3.5:3;
  const bars=useRef<(THREE.Group|null)[]>([]);
  const ticks=content?[0,25,50,75,100]:vision?[0,.05,.1,.15,.2]:[0,.2,.4,.6,.8];
  const gap=(values[0]-values[1]).toFixed(1);
  useFrame((_,dt)=>bars.current.forEach((bar,i)=>{if(bar)bar.scale.y=smooth(bar.scale.y,state.beat>0?values[i]/limit*height:.001,dt,reduced)}));
  return <group position={[size.width<800?2.9:vision?3.2:.8,-.05,.35]} rotation={[0,-.08,0]} scale={size.width<800?.75:vision?.88:1.02}>
    <RoundedBox args={[6.1,4.9,.12]} radius={.12} smoothness={3} position={[0,.35,-.48]}><meshPhysicalMaterial color="#142737" metalness={.3} roughness={.25} transparent opacity={.82}/></RoundedBox>
    <Line points={[[-3,2.8,-.4],[3,2.8,-.4],[3,-2.1,-.4],[-3,-2.1,-.4],[-3,2.8,-.4]]} color="#638599" transparent opacity={.35} lineWidth={.6}/>
    <Text font={fontUrl} fontSize={.25} position={[0,2.4,-.28]} color="#dae7ef">{content?'Alignment retained after disruption':vision?'Comparing text with vision':'Comparing language models'}</Text>
    {ticks.map(value=><group key={value} position={[0,-1.4+value/limit*height,0]}><Line points={[[-2.25,0,-.3],[2.4,0,-.3]]} color="#68869c" transparent opacity={.2} lineWidth={.6}/><Text font={fontUrl} fontSize={.15} color="#98afbf" position={[-2.6,0,-.25]}>{content?`${value}%`:value.toFixed(vision?2:1)}</Text></group>)}
    {values.map((value,i)=><group key={i} position={[i===0?-1.2:1.2,-1.4,0]}>
      <group ref={el=>{bars.current[i]=el;}} scale={[1,.001,1]}><mesh position={[0,.5,0]}><boxGeometry args={[content?1.05:.85,1,.5]}/><meshPhysicalMaterial color={i?AMBER:CYAN} emissive={i?AMBER:CYAN} emissiveIntensity={.15} metalness={.4} roughness={.22} transparent opacity={.88}/></mesh></group>
      {state.beat>0&&<Text font={fontUrl} fontSize={.3} color={i?AMBER:CYAN} position={[0,value/limit*height+.27,.15]}>{content?`${value.toFixed(1)}%`:`+${value.toFixed(2)}`}</Text>}
      <Text font={fontUrl} fontSize={.18} color="#c4d6e1" position={[0,-.27,.15]}>{i?'J-space':'Full activation'}</Text>
    </group>)}
    {content&&<group>
      <Line points={[[-.2,-1.4+values[0]/100*height,.36],[.2,-1.4+values[0]/100*height,.36],[0,-1.4+values[0]/100*height,.36],[0,-1.4+values[1]/100*height,.36],[-.2,-1.4+values[1]/100*height,.36],[.2,-1.4+values[1]/100*height,.36]]} color="#e3edf1" lineWidth={1.7}/>
      <Text font={fontUrl} fontSize={.24} color={AMBER} position={[0,-1.95,.15]}>{`${gap} percentage-point gap`}</Text>
    </group>}
    {!content&&<Text font={fontUrl} fontSize={.13} color="#9db4c4" position={[0,-1.95,.1]}>Alignment increase per unit HellaSwag accuracy</Text>}
  </group>;
}
function SurfaceFlow({points,color,reduced,delay=0}:{points:[number,number,number][];color:string;reduced:boolean;delay?:number}){
  const path=useMemo(()=>new THREE.CatmullRomCurve3(points.map(p=>vec(...p))),[points]);
  const pulse=useRef<THREE.Mesh>(null!);const time=useRef(0);
  const orientation=useMemo(()=>new THREE.Quaternion().setFromUnitVectors(vec(0,1,0),path.getTangent(1)),[path]);
  useFrame((_,dt)=>{
    if(!reduced)time.current+=Math.min(dt,.05);
    const phase=((time.current-delay)%3.8+3.8)%3.8;
    pulse.current.visible=!reduced&&phase<1.6;
    pulse.current.position.copy(path.getPoint(Math.min(1,phase/1.6)));
  });
  return <group>
    <Line points={path.getPoints(45)} color={color} lineWidth={1.1} transparent opacity={.5}/>
    <mesh position={path.getPoint(1)} quaternion={orientation}><coneGeometry args={[.065,.16,14]}/><meshStandardMaterial color={color} emissive={color} emissiveIntensity={.4}/></mesh>
    <mesh ref={pulse}><sphereGeometry args={[.044,12,12]}/><meshBasicMaterial color={color}/></mesh>
  </group>;
}
function InterpretationExhibit({state,reduced,replay}:{state:PresentationState;reduced:boolean;replay:number}){
  const {size}=useThree();
  const features=[
    {label:'Shared syntax',detail:'noun → verb → phrase',color:CYAN},
    {label:'Same language',detail:'English',color:'#c6b1ff'},
    {label:'Document length',detail:'6 words each',color:AMBER},
  ];
  return <group position={size.width<800?[2.9,1.7,.1]:[3.1,-.05,.1]} scale={size.width<800?.42:1}>
    {[-1.9,1.9].map((x,side)=><group key={side}>
      <group position={[x,1.6,1.05]} rotation={[-.08,0,0]}>
        <RoundedBox args={[3.45,.73,.12]} radius={.08} smoothness={3}><meshStandardMaterial color="#173247" metalness={.4} roughness={.25}/></RoundedBox>
        <Line points={[[-1.6,.3,.067],[1.6,.3,.067]]} color={side?'#c6b1ff':CYAN} lineWidth={1.5} transparent opacity={.75}/>
        <Text font={fontUrl} fontSize={.225} position={[0,0,.08]} color="#e4edf3">{side?'The car stopped by the shop.':'The cat slept by the fire.'}</Text>
      </group>
      <SurfaceFlow points={[[x,1.2,1.05],[x,.85,.9],[x,.6,.35],[x,.25,0]]} color={side?'#c6b1ff':CYAN} reduced={reduced}/>
      <group position={[x,-.1,0]} scale={.68}><Model x={0} side={side} opened active reduced={reduced} pulseKey={`${state.scene}-${replay}`} labelSize={.23}/></group>
    </group>)}
    <Line points={[[-3.55,1.2,1.17],[-3.55,1.02,1.17],[3.55,1.02,1.17],[3.55,1.2,1.17]]} color="#92b4c8" lineWidth={1.1} transparent opacity={.5}/>
    {features.map((feature,i)=>{
      const x=(i-1)*2.4, endpoint=(i-1)*.52;
      return <group key={feature.label}>
        <SurfaceFlow points={[[x,-1.15,2.2],[x*.36,-.45,2.25],[endpoint,.4,1.8],[endpoint,1.02,1.17]]} color={feature.color} reduced={reduced} delay={.8+i*.2}/>
        <group position={[x,-1.55,2.2]} rotation={[-.08,0,0]}>
          <RoundedBox args={[2.25,.7,.1]} radius={.07} smoothness={3}><meshStandardMaterial color="#153043" emissive={feature.color} emissiveIntensity={.035} roughness={.3} metalness={.4}/></RoundedBox>
          <Text font={fontUrl} fontSize={.2} color={feature.color} position={[0,.13,.065]}>{feature.label}</Text>
          <Text font={fontUrl} fontSize={.16} color="#bdd0dd" position={[0,-.14,.065]}>{feature.detail}</Text>
        </group>
      </group>;
    })}
  </group>;
}
function EngineeringExhibit({state,reduced}:{state:PresentationState;reduced:boolean}){
  const time=useRef(0),pulse=useRef<THREE.Mesh>(null!);
  useEffect(()=>{time.current=0},[state.beat]);
  useFrame((_,dt)=>{
    if(!reduced)time.current+=Math.min(dt,.05);
    const progress=THREE.MathUtils.clamp(time.current/3.2,0,1);
    pulse.current.visible=state.beat>0&&!reduced&&progress<1;
    pulse.current.position.x=.2+progress*6;
  });
  return <group>
    <Line points={[[.2,1.8,.8],[6.2,1.8,.8]]} color={CYAN} transparent opacity={state.beat>.0?.45:.18} lineWidth={1}/>
    {Array.from({length:5},(_,i)=><mesh key={i} position={[.2+i*1.5,1.8,.8]}><sphereGeometry args={[.035,12,12]}/><meshBasicMaterial color={CYAN}/></mesh>)}
    <mesh ref={pulse} position={[.2,1.8,.8]}><sphereGeometry args={[.07,16,16]}/><meshBasicMaterial color="#effcff"/></mesh>
    <group position={[3.2,-1.9,0]}><RoundedBox args={[6.2,.12,3]} radius={.1} smoothness={3}><meshStandardMaterial color="#243b50" metalness={.6} roughness={.3}/></RoundedBox><Glow size={5} color={CYAN} position={[0,.3,0]}/></group>
  </group>;
}
function Exhibit({position,children}:{position:[number,number];children:ReactNode}){
  const group=useRef<THREE.Group>(null!);
  useFrame(({camera})=>{group.current.visible=Math.hypot(camera.position.x-position[0],camera.position.z-14.5-position[1])<18;});
  return <group ref={group} position={[position[0],0,position[1]]}>{children}</group>;
}
function ModelExhibit({state,reduced,replay}:{state:PresentationState;reduced:boolean;replay:number}){
  const {size}=useThree();const current=scenes[state.scene];
  const showSentence=!['vectors','convergence'].includes(current.id);
  const trigger=`${state.scene}-${state.randomised}-${replay}`;
  return <group position={[2.9,size.width<800&&current.id==='retention'?1.75:-.1,0]} scale={size.width<800?(current.id==='retention'?.4:.78):1}>
    <Model x={-2.05} side={0} opened active reduced={reduced} pulseKey={trigger}/>
    <Model x={2.05} side={1} opened active reduced={reduced} pulseKey={trigger}/>
    {[0,1].map(side=><Fan key={side} x={side?2.05:-2.05} side={side} randomised={state.randomised} selected={state.selectedItem} compare={current.visualBeat>=4} reduced={reduced}/>)}
    {showSentence&&<><SentenceSurface randomised={state.randomised} reduced={reduced} pulseKey={trigger} experiment={current.id==='retention'}/><Pulse trigger={trigger} reduced={reduced}/></>}
  </group>;
}
function World({state,reduced,replay,onCommand,interactive}:{state:PresentationState;reduced:boolean;replay:number;onCommand:(command:SceneCommand)=>void;interactive:boolean}){
  const {size}=useThree();const controlScale=size.width<800?.72:1;
  const arrivedScene=useRef<number|null>(null);
  const [cx,cz]=stations[state.scene];
  const exhibits=useRef(stations.map((_,scene)=>stateAt(scene,0)));
  const visited=useRef({current:state.scene,previous:state.scene});
  if(visited.current.current!==state.scene){visited.current.previous=visited.current.current;visited.current.current=state.scene;}
  exhibits.current[state.scene]=state;
  const warm=['wordfield','workspace'].includes(scenes[state.scene].exhibit);
  return <>
    <color attach="background" args={['#0b131f']}/><fog attach="fog" args={['#0b131f',18,32]}/>
    <ambientLight intensity={.95}/><directionalLight position={[10,14,8]} intensity={3} color="#cee7f7"/>
    <pointLight position={[cx+1,3,cz+2]} color={warm?AMBER:CYAN} intensity={30} distance={15}/><pointLight position={[cx+6,3,cz-3]} color="#9597ff" intensity={35} distance={15}/>
    <CameraRig state={state} reduced={reduced} arrivedScene={arrivedScene}/><Floor/>
    {stations.map((position,scene)=>{
      if(scene!==state.scene&&scene!==visited.current.previous)return null;
      const current=scenes[scene], snapshot=exhibits.current[scene];
      return <Exhibit key={current.id} position={position}>
        <FloatingHeading state={snapshot}/>
        {current.exhibit==='vectors'&&<IdeasExhibit reduced={reduced}/>}
        {current.exhibit==='convergence'&&<ConvergenceExhibit reduced={reduced} replay={replay} sharedProgress={snapshot.convergenceProgress} interactive={interactive&&scene===state.scene} onScrub={progress=>onCommand({type:'scrub',progress})}/>}
        {current.exhibit==='neighbourhoods'&&<NeighbourhoodExhibit reduced={reduced} replay={replay} active={scene===state.scene} scene={scene} arrivedScene={arrivedScene}/>}
        {current.exhibit==='models'&&<ModelExhibit state={snapshot} reduced={reduced} replay={replay}/>}
        {current.exhibit==='workspace'&&<>
          <Text font={fontUrl} fontSize={size.width<800?.18:.26} lineHeight={1.18} maxWidth={size.width<800?4.3:11.6} textAlign="center" position={[size.width<800?2.9:.8,size.width<800?2.65:2.58,.8]} color="#cbdce8">{current.caption.replace('subset is','subset\nis')}</Text>
          <group position={[size.width<800?2.9:.8,-.22,.35]} scale={size.width<800?[.9,.78,.9]:[1.6,1.32,1.6]}><GlobalWorkspaceExhibit revealed={current.visualBeat===1} reduced={reduced} replay={replay} active={scene===state.scene} scene={scene} arrivedScene={arrivedScene}/></group>
        </>}
        {current.exhibit==='wordfield'&&<group position={[2.8,-.15,0]} scale={size.width<800?1:1.3}><WordField state={snapshot} reduced={reduced} replay={replay}/></group>}
        {current.exhibit==='results'&&<ResultSculpture state={{...snapshot,beat:1}} reduced={reduced}/>}
        {current.exhibit==='surface'&&<InterpretationExhibit state={snapshot} reduced={reduced} replay={replay}/>}
        {current.id==='surface'&&<AlignmentBars mode="contributions" reduced={reduced}/>}
        {current.id==='retention'&&<AlignmentBars mode="retention" reduced={reduced}/>}
        {(current.exhibit==='training'||current.exhibit==='crossmodal')&&<ImplicationsExhibit beat={current.visualBeat} reduced={reduced} caption={current.id==='implications'?'More compute, more capable models':current.id==='platonic'?'Different inputs, shared representations':'Similar organisation across text and vision'}/>}
        {current.exhibit==='engineering'&&<EngineeringExhibit state={snapshot} reduced={reduced}/>}
        {scene===state.scene&&interactive&&<group position={[(size.width<800&&current.exhibit==='training'?2.9:3.2)-3.2*controlScale+(current.exhibit==='workspace'?(size.width<800?-.3:-2.4):0),size.width<800&&current.id==='retention'?2.5:0,0]} scale={[controlScale,1,1]}>{sceneControls(state).map(c=><SceneButton key={c.label} label={c.label} position={c.position} width={c.width} size={c.size} color={c.color} active={c.active} onClick={()=>onCommand(c.command)}/>)}</group>}
      </Exhibit>;
    })}
  </>;
}
function Fallback(){return <div className="fallback-diagram"><div className="fallback-model">Model A<br/><span>↗ ↑ ↗</span></div><div className="fallback-model">Model B<br/><span>↗ ↑ ↗</span></div><p>Interactive diagrams are shown in a simplified view on this device.</p></div>}
class StageBoundary extends Component<{children:ReactNode},{failed:boolean}>{state={failed:false};static getDerivedStateFromError(){return {failed:true}}render(){return this.state.failed?<Fallback/>:this.props.children}}
export default function ResearchStage({state,reduced,replay,onCommand,interactive=true}:{state:PresentationState;reduced:boolean;replay:number;onCommand:(command:SceneCommand)=>void;interactive?:boolean}){
  const [visible,setVisible]=useState(!document.hidden);
  useEffect(()=>{const f=()=>setVisible(!document.hidden);document.addEventListener('visibilitychange',f);return()=>document.removeEventListener('visibilitychange',f)},[]);
  const kind=scenes[state.scene].exhibit;
  const description=kind==='neighbourhoods'?'Two Cartesian spaces show cat pointing in different directions, then highlight dog and kitten as the same neighbours in both models':kind==='vectors'?'A three-dimensional Cartesian space with arrows labeled cat, philosophy, number and music':kind==='convergence'?'Two three-dimensional model spaces whose matching idea arrows become more similarly directed as a schematic time scale advances':kind==='workspace'?'Illustrative global workspace with key ideas available for report and reasoning':kind==='wordfield'?'Enlarged tip-to-tail vector decomposition into J-space and remainder':kind==='results'?'Three-dimensional measured result charts':kind==='engineering'?'Three-dimensional implementation exhibit':kind==='crossmodal'?'Shared representations across language and vision models':kind==='training'?'Models and compute for training AI':kind==='surface'?'Two sentences feed two models, with arrows highlighting shared syntax, English language and equal document length':'Two hovering models with schematic representation vectors';
  return <StageBoundary><Canvas aria-label={description} dpr={[1,1.65]} camera={{position:[.8,3.3,14.5],fov:42}} gl={{antialias:true,alpha:false,powerPreference:'high-performance'}} frameloop={visible?'always':'never'} fallback={<Fallback/>}>
    <Suspense fallback={null}><World state={state} reduced={reduced} replay={replay} onCommand={onCommand} interactive={interactive}/></Suspense>
  </Canvas></StageBoundary>;
}
