import { scenes, type PresentationState } from '../state/presentation';
// Every narrative slide occupies its own location further inside the room.
const lanes=[0,3,-2,2,-3,1,-2,2,-2,0];
export const stations: [number,number][] = scenes.map((_,index)=>[lanes[index%lanes.length],-index*22]);
export function headingForState(state:PresentationState):string[]{return scenes[state.scene].title;}
