import { useEffect, useMemo, useRef, type RefObject } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Billboard, Line, Text } from '@react-three/drei';
import * as THREE from 'three';
import type { PresentationState } from '../state/presentation';
import { activationTriangle } from './activationGeometry';

const AMBER = '#ffbd69', CYAN = '#62d8f5', LILAC = '#c6b1ff';
const font = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
const v = (x: number, y: number, z = 0) => new THREE.Vector3(x, y, z);
const seed = (n: number) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const ease = (t: number) => { const p = THREE.MathUtils.clamp(t, 0, 1); return p * p * (3 - 2 * p); };
const vocabulary = `meaning understand language garden river reason pattern dream story science letter quiet forest form concept time learn window thought motion world bird answer school human space sound number light shape idea music tree question mind paper order change signal water place network colour attention stone summer sentence family draw read knowledge listen future surface home book system recognise distance remember progress memory growth pace rate ocean mountain horizon rhythm texture voice journey balance movement warmth reflection curiosity discovery connection imagination structure expression direction possibility nature experience wonder breath conversation echo energy detail morning evening seasons leaf cloud rain weather sky earth moon sun stars gravity orbit wave frequency measure geometry symmetry dimension angle vector matrix distance similarity learning training model example context token vocabulary meaning syntax grammar phrase passage document image vision picture sketch painting sculpture photograph perspective depth shadow brightness contrast texture composition architecture bridge building street city village country world travel path road map location position landscape field meadow valley island shore coast beach lake stream snow frost wind spring autumn winter flower seed root branch fruit harvest child adult parent friend people person group community society culture history tradition knowledge research experiment evidence theory hypothesis conclusion method process analysis comparison result insight question answer information message communication translation description explanation prediction reasoning logic mathematics algebra calculus probability statistics equation function derivative integral curve plane line point circle sphere cube shape pattern design craft construction machine computer program code algorithm calculation measurement attention focus awareness intention choice decision action response effect cause consequence difference remainder component direction representation reconstruction selection weight dictionary feature concept object event change motion speed distance scale duration sequence order relation association category identity memory feeling emotion joy hope care trust kindness courage patience calm surprise laughter play imagination creativity music melody harmony tempo dance movement exercise sport running walking swimming flying sailing reading writing speaking listening thinking learning teaching growing building making drawing creating exploring discovering testing comparing understanding`.split(' ');

type WordFieldProps = { state: PresentationState; reduced: boolean; replay: number };

function DriftingWord({ index, word, focused, reduced }: { index: number; word: string; focused: boolean; reduced: boolean }) {
  const group = useRef<THREE.Group>(null!);
  const text = useRef<any>(null!);
  const time = useRef(0);
  const base = useMemo(() => v((seed(index + 3) - .5) * 8.5 + .8, (seed(index + 7) - .5) * 4.1 - .1, (seed(index + 20) - .5) * 6.2 - .4), [index]);
  const target = useMemo(() => v(0, 0, 0), []);
  useFrame(({ camera }, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    const t = time.current, phase = index * 1.618;
    // Absolute, bounded trajectories: clearly visible motion without cumulative drift.
    target.set(
      base.x + Math.sin(t * .32 + phase) * .55 + Math.cos(t * .17 + phase) * .2,
      base.y + Math.sin(t * .41 + phase * .7) * .24,
      base.z + Math.sin(t * .23 + phase * 1.3) * .65,
    );
    if (focused) { target.x *= 1.22; target.z -= 2.2; }
    group.current.position.lerp(target, reduced ? 1 : 1 - Math.exp(-Math.min(dt, .05) * 3));
    group.current.quaternion.copy(camera.quaternion);
    if (text.current) {
      const opacity = focused ? .055 : .26 + seed(index + 14) * .32;
      text.current.fillOpacity = reduced ? opacity : THREE.MathUtils.damp(text.current.fillOpacity ?? 0, opacity, 4, dt);
    }
  });
  return <group ref={group} position={base}>
    <Text ref={text} font={font} fontSize={.15 + seed(index + 9) * .075} color={index % 7 === 0 ? '#a4c9dc' : '#7898af'} fillOpacity={.3} anchorX="center" anchorY="middle">{word}</Text>
  </group>;
}

function ExampleWord({ focused, mobile, reduced }: { focused: boolean; mobile: boolean; reduced: boolean }) {
  const group = useRef<THREE.Group>(null!);
  const time = useRef(0);
  const target = useMemo(() => v(0, 0, 0), []);
  useFrame(({ camera }, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    target.copy(focused ? v(-.7, -.18, .8) : v(-.6 + Math.sin(time.current * .33) * .55, 1.15 + Math.sin(time.current * .42) * .2, .8));
    group.current.position.lerp(target, reduced ? 1 : 1 - Math.exp(-dt * 3));
    group.current.quaternion.copy(camera.quaternion);
    const scale = focused ? 1 : .8;
    group.current.scale.lerp(v(scale, scale, scale), reduced ? 1 : 1 - Math.exp(-dt * 4));
  });
  return <group ref={group} position={[-.4, .65, .8]}>
    <Text font={font} fontSize={mobile ? .28 : .37} color={AMBER} outlineColor="#0b131f" outlineWidth={.009}>children</Text>
    {focused && <Line points={[[-.55, -.24, 0], [.55, -.24, 0]]} color={AMBER} transparent opacity={.55} lineWidth={1.1}/>}
  </group>;
}

type Route = { curve: THREE.CatmullRomCurve3; color: string; delay: number; duration: number; radius: number };
function FlowArrow({ route, timeline, reduced, emphasized }: { route: Route; timeline: RefObject<number>; reduced: boolean; emphasized: boolean }) {
  const segments = 80, radial = 8;
  const geometry = useMemo(() => new THREE.TubeGeometry(route.curve, segments, route.radius, radial, false), [route.curve, route.radius]);
  const tip = useRef<THREE.Group>(null!);
  const body = useRef<THREE.MeshStandardMaterial>(null!);
  const dots = useRef<(THREE.Mesh | null)[]>([]);
  const up = useMemo(() => v(0, 1, 0), []);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame((_, dt) => {
    const progress = reduced ? 1 : ease((timeline.current - route.delay) / route.duration);
    geometry.setDrawRange(0, Math.floor(progress * segments) * radial * 6);
    tip.current.visible = progress > .025;
    tip.current.position.copy(route.curve.getPoint(progress));
    tip.current.quaternion.setFromUnitVectors(up, route.curve.getTangent(progress).normalize());
    body.current.opacity = THREE.MathUtils.damp(body.current.opacity, emphasized ? 1 : .55, 5, dt);
    dots.current.forEach((dot, i) => {
      if (!dot) return;
      const phase = (timeline.current - route.delay - .15) / route.duration - i * .045;
      dot.visible = !reduced && phase >= 0 && phase <= 1;
      if (dot.visible) dot.position.copy(route.curve.getPoint(Math.min(1, phase)));
    });
  });
  return <group>
    <mesh geometry={geometry}><meshStandardMaterial ref={body} color={route.color} emissive={route.color} emissiveIntensity={.65} metalness={.35} roughness={.24} transparent opacity={1}/></mesh>
    <group ref={tip}><mesh rotation={[0, 0, 0]}><coneGeometry args={[.105, .24, 16]}/><meshStandardMaterial color={route.color} emissive={route.color} emissiveIntensity={.6}/></mesh></group>
    {Array.from({ length: 9 }, (_, i) => <mesh ref={el => { dots.current[i] = el; }} key={i}><sphereGeometry args={[i === 0 ? .065 : .035, 10, 10]}/><meshBasicMaterial color={i === 0 ? '#fff8e9' : route.color} transparent opacity={1 - i * .09}/></mesh>)}
  </group>;
}

function ComponentLabel({ children, position, color, timeline, delay, reduced, mobile }: { children: string; position: [number, number, number]; color: string; timeline: RefObject<number>; delay: number; reduced: boolean; mobile: boolean }) {
  const text = useRef<any>(null!);
  useFrame(() => { if (text.current) text.current.fillOpacity = reduced ? 1 : ease((timeline.current - delay) / .5); });
  return <Billboard position={position}><Text ref={text} font={font} fontSize={mobile ? .2 : .25} color={color} anchorX="center" maxWidth={mobile ? 2.3 : 3.3} textAlign="center" outlineColor="#0b131f" outlineWidth={.009} fillOpacity={0}>{children}</Text></Billboard>;
}

function SplitDiagram({ state, reduced, replay, mobile }: { state: PresentationState; reduced: boolean; replay: number; mobile: boolean }) {
  const time = useRef(0);
  const arrival = useRef<THREE.Mesh>(null!);
  const arrivalMaterial = useRef<THREE.MeshBasicMaterial>(null!);
  const { origin, jTip, fullTip } = activationTriangle;
  const routes = useMemo<Route[]>(() => [[origin, fullTip], [origin, jTip], [jTip, fullTip]].map((points, i) => ({
    curve: new THREE.CatmullRomCurve3(points.map(p => v(...p))), color: [CYAN, AMBER, LILAC][i],
    delay: [0, 1.1, 2.25][i], duration: 1.1, radius: i === 0 ? .045 : .034,
  })), [origin, jTip, fullTip]);
  const plane = useMemo(() => {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute([...origin, ...jTip, ...fullTip], 3));
    geometry.computeVertexNormals(); return geometry;
  }, [origin, jTip, fullTip]);
  useEffect(() => () => plane.dispose(), [plane]);
  useEffect(() => { time.current = reduced ? 5 : 0; }, [replay, state.beat, reduced]);
  useFrame((_, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    const progress = ease((time.current - 3.25) / .8);
    arrival.current.scale.setScalar(.3 + progress * 1.4);
    arrivalMaterial.current.opacity = reduced ? .15 : .7 * (1 - progress);
  });
  return <group>
    <mesh geometry={plane} position={[0,0,-.025]}><meshBasicMaterial color={CYAN} transparent opacity={.035} side={THREE.DoubleSide} depthWrite={false}/></mesh>
    {routes.map((route, i) => <FlowArrow key={i} route={route} timeline={time} reduced={reduced} emphasized={state.beat === 2 || state.component === ['full', 'j', 'remainder'][i]}/>)}
    <mesh position={origin}><sphereGeometry args={[.065,16,16]}/><meshBasicMaterial color="#e6f6ff"/></mesh>
    <mesh position={jTip}><sphereGeometry args={[.065,16,16]}/><meshBasicMaterial color={AMBER}/></mesh>
    <mesh ref={arrival} position={fullTip}><ringGeometry args={[.16,.18,64]}/><meshBasicMaterial ref={arrivalMaterial} color="#e6f6ff" transparent side={THREE.DoubleSide}/></mesh>
    <ComponentLabel position={[-.9, 1.08, .65]} color={CYAN} timeline={time} delay={.3} reduced={reduced} mobile={mobile}>Full activation</ComponentLabel>
    <ComponentLabel position={[-.8, -1.3, .65]} color={AMBER} timeline={time} delay={1.1} reduced={reduced} mobile={mobile}>J-space component</ComponentLabel>
    <ComponentLabel position={mobile ? [.65, .3, .65] : [2.8, .28, .65]} color={LILAC} timeline={time} delay={2.3} reduced={reduced} mobile={mobile}>Remainder</ComponentLabel>
    <Line points={[[-.7, -.45, .8], [-.7, -.84, .5]]} color={AMBER} dashed dashSize={.045} gapSize={.055} lineWidth={1} transparent opacity={.5}/>
  </group>;
}

export default function WordField({ state, reduced, replay }: WordFieldProps) {
  const { size } = useThree();
  const mobile = size.width < 800, focused = true;
  const count = mobile ? 150 : 340;
  return <group>
    {Array.from({ length: count }, (_, i) => <DriftingWord key={i} index={i} word={vocabulary[i % vocabulary.length]} focused={focused} reduced={reduced}/>)}
    <ExampleWord focused={focused} mobile={mobile} reduced={reduced}/>
    <group scale={mobile ? .78 : 1}><SplitDiagram state={{...state,beat:2}} reduced={reduced} replay={replay} mobile={mobile}/></group>
  </group>;
}
