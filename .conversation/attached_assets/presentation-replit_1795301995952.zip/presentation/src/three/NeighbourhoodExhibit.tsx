import { useEffect, useMemo, useRef, type RefObject } from 'react';
import { Billboard, Line, Text } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { CartesianFrame } from './RepresentationExhibits';
import { neighbourhoodDirection, neighbourhoodItems } from './neighbourhoodGeometry';

const font = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
const CYAN = '#62d8f5';
type Clock = RefObject<number>;
const ease = (time: number, start: number, end: number) => THREE.MathUtils.smoothstep(time, start, end);
const frameRotation = new THREE.Euler(0, -.38, 0);

function NeighbourArrow({ index, side, time, reduced }: { index: number; side: number; time: Clock; reduced: boolean }) {
  const body = useRef<THREE.MeshStandardMaterial>(null!);
  const head = useRef<THREE.MeshStandardMaterial>(null!);
  const tip = useRef<THREE.Mesh>(null!);
  const tipMaterial = useRef<THREE.MeshBasicMaterial>(null!);
  const text = useRef<any>(null!);
  const item = neighbourhoodItems[index];
  const direction = useMemo(() => new THREE.Vector3(...neighbourhoodDirection(index, side)), [index, side]);
  const length = direction.length();
  const quaternion = useMemo(() => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize()), [direction]);
  const muted = useMemo(() => new THREE.Color('#60778c'), []);
  const color = useMemo(() => new THREE.Color(item.color), [item]);
  useFrame(() => {
    const focus = index < 3 ? reduced ? 1 : index === 0 ? ease(time.current, .7, 1.4) : ease(time.current, 1.8 + index * .22, 2.55 + index * .22) : 0;
    for (const material of [body.current, head.current]) {
      material.color.copy(muted).lerp(color, focus);
      material.emissive.copy(color);
      material.emissiveIntensity = .04 + focus * .7;
      material.opacity = .2 + focus * .8;
    }
    tipMaterial.current.opacity = focus;
    tip.current.scale.setScalar(.6 + focus * .4 + (reduced ? 0 : focus * Math.sin(time.current * 3) * .1));
    if (text.current) {
      text.current.color = index < 3 && focus > .05 ? item.color : '#7c94a8';
      text.current.fillOpacity = index < 3 ? .35 + focus * .65 : .28;
    }
  });
  return <group>
    <group quaternion={quaternion}>
      <mesh position={[0, (length - .2) / 2, 0]}>
        <cylinderGeometry args={[index === 0 ? .04 : .026, index === 0 ? .04 : .026, length - .2, 12]} />
        <meshStandardMaterial ref={body} transparent opacity={.2} roughness={.3} metalness={.3} />
      </mesh>
      <mesh position={[0, length - .1, 0]}><coneGeometry args={[index === 0 ? .12 : .09, .24, 18]} /><meshStandardMaterial ref={head} transparent opacity={.2} /></mesh>
    </group>
    <mesh ref={tip} position={direction}><sphereGeometry args={[index === 0 ? .075 : .05, 16, 16]} /><meshBasicMaterial ref={tipMaterial} color={item.color} transparent opacity={0} /></mesh>
    <Billboard position={[direction.x + (side === 0 && index === 1 ? -.32 : 0), direction.y + (side === 0 && index === 1 ? .06 : side === 0 && index === 0 ? .45 : .29), direction.z]}>
      <Text ref={text} font={font} fontSize={index < 3 ? .34 : .24} outlineWidth={.012} outlineColor="#0b131f">{item.word}</Text>
    </Billboard>
  </group>;
}

function NeighbourGroup({ side, time, reduced }: { side: number; time: Clock; reduced: boolean }) {
  const surface = useRef<THREE.MeshBasicMaterial>(null!);
  const halo = useRef<THREE.MeshBasicMaterial>(null!);
  const outline = useRef<any>(null!);
  const pulse = useRef<THREE.Mesh>(null!);
  const points = useMemo(() => [0, 1, 2].map(index => new THREE.Vector3(...neighbourhoodDirection(index, side))), [side]);
  const centre = useMemo(() => points.reduce((sum, point) => sum.add(point), new THREE.Vector3()).divideScalar(3), [points]);
  const geometry = useMemo(() => {
    const result = new THREE.BufferGeometry();
    result.setAttribute('position', new THREE.Float32BufferAttribute(points.flatMap(point => point.toArray()), 3));
    result.computeVertexNormals();
    return result;
  }, [points]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame(() => {
    const reveal = reduced ? 1 : ease(time.current, 2.6, 3.4);
    surface.current.opacity = reveal * .15;
    halo.current.opacity = reveal * .055;
    outline.current.material.opacity = reveal * .85;
    pulse.current.visible = !reduced && reveal > .8;
    const p = (time.current * .6) % 3, segment = Math.floor(p);
    pulse.current.position.copy(points[segment]).lerp(points[(segment + 1) % 3], p - segment);
  });
  return <group>
    <mesh geometry={geometry}><meshBasicMaterial ref={surface} color={CYAN} transparent opacity={0} side={THREE.DoubleSide} depthWrite={false} /></mesh>
    <mesh position={centre}><sphereGeometry args={[1.02, 32, 24]} /><meshBasicMaterial ref={halo} color={CYAN} transparent opacity={0} depthWrite={false} /></mesh>
    <Line ref={outline} points={[...points, points[0]]} color={CYAN} lineWidth={1.4} transparent opacity={0} />
    <mesh ref={pulse}><sphereGeometry args={[.05, 14, 14]} /><meshBasicMaterial color="#e6fcff" /></mesh>
  </group>;
}

function GroupComparison({ time, reduced }: { time: Clock; reduced: boolean }) {
  const paths = useMemo(() => [0, 1].map(side => {
    const centre = [0, 1, 2].reduce((sum, index) => sum.add(new THREE.Vector3(...neighbourhoodDirection(index, side))), new THREE.Vector3()).divideScalar(3);
    centre.applyEuler(frameRotation).multiplyScalar(.62).add(new THREE.Vector3(side ? 2.1 : -2.1, 0, 0));
    const sign = side ? 1 : -1;
    return new THREE.CatmullRomCurve3([centre, new THREE.Vector3(sign * 3.1, -.5, 1.5), new THREE.Vector3(sign * 1.85, -1.35, 2)]);
  }), []);
  const lines = useRef<any[]>([]), pulses = useRef<(THREE.Mesh | null)[]>([]), text = useRef<any>(null!);
  useFrame(() => {
    const reveal = reduced ? 1 : ease(time.current, 3.3, 4.1);
    lines.current.forEach(line => { if (line) line.material.opacity = reveal * .5; });
    if (text.current) text.current.fillOpacity = reveal;
    pulses.current.forEach((pulse, side) => {
      if (!pulse) return;
      pulse.visible = !reduced && reveal > .8;
      pulse.position.copy(paths[side].getPoint(((time.current - 3.3) * .5 + 100) % 1));
    });
  });
  return <group>
    {paths.map((path, side) => <group key={side}>
      <Line ref={line => { lines.current[side] = line; }} points={path.getPoints(50)} color={CYAN} lineWidth={1} transparent opacity={0} />
      <mesh ref={pulse => { pulses.current[side] = pulse; }}><sphereGeometry args={[.04, 12, 12]} /><meshBasicMaterial color={CYAN} /></mesh>
    </group>)}
    <Billboard position={[0, -1.35, 2]}><Text ref={text} font={font} fontSize={.23} color="#d6f1f5" fillOpacity={0}>Same neighbours in both models</Text></Billboard>
  </group>;
}

export default function NeighbourhoodExhibit({ reduced, replay, active, scene, arrivedScene }: { reduced: boolean; replay: number; active: boolean; scene: number; arrivedScene: RefObject<number|null> }) {
  const time = useRef(0);
  const { size } = useThree();
  useEffect(() => { time.current = 0; }, [replay, active]);
  useFrame((_, dt) => {
    if (!active || arrivedScene.current !== scene) { time.current = 0; return; }
    // Start only after camera travel settles; stretch the reveal to ~7.5 seconds.
    if (!reduced) time.current += Math.min(dt, .05) * .55;
  });
  return <group position={[3.2, -.2, .1]} scale={size.width < 800 ? .67 : 1}>
    {[0, 1].map(side => <group key={side} position={[side ? 2.1 : -2.1, 0, 0]}>
      <Billboard position={[0, 2.1, 0]}><Text font={font} fontSize={.25} color="#dcebf5">{side ? 'Model B' : 'Model A'}</Text></Billboard>
      <group rotation={frameRotation} scale={.62}>
        <CartesianFrame />
        {neighbourhoodItems.map((item, index) => <NeighbourArrow key={item.word} {...{ index, side, time, reduced }} />)}
        <NeighbourGroup {...{ side, time, reduced }} />
      </group>
    </group>)}
    <GroupComparison time={time} reduced={reduced} />
  </group>;
}
