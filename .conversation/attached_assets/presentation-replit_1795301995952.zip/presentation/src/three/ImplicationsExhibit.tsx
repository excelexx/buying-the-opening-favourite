import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Billboard, Line, RoundedBox, Text } from '@react-three/drei';
import * as THREE from 'three';

const CYAN = '#62d8f5', AMBER = '#ffbd69', LILAC = '#bbaaff';
const font = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
const centre = new THREE.Vector3(0, -.35, 1.05);
const sources: [number, number, number][] = [[-2.15, .65, 0], [2.15, .65, 0], [0, 1.45, -2.2]];
const conceptNodes: [number, number, number][] = [[-.38,.3,.08],[.29,.34,-.17],[.5,-.13,.2],[.03,-.43,-.25],[-.41,-.24,.17],[.04,.03,.44],[.05,.08,-.44]];
const links = [[0,1],[1,2],[2,3],[3,4],[4,0],[0,5],[1,5],[2,5],[3,6],[4,6],[0,6],[1,6]];

function ModelSculpture({ index, beat, reduced }: { index: number; beat: number; reduced: boolean }) {
  const group = useRef<THREE.Group>(null!);
  const phase = useRef(index * 1.6);
  const active = index < 2 || beat === 2;
  const color = [CYAN, LILAC, AMBER][index];
  useFrame((_, dt) => {
    if (!reduced) phase.current += Math.min(dt, .05);
    group.current.position.y = reduced ? 0 : Math.sin(phase.current * .65) * .06;
    group.current.rotation.y = index === 2 ? -.16 : (index ? -.25 : .25) + (reduced ? 0 : Math.sin(phase.current * .2) * .06);
  });
  return <group position={sources[index]}>
    <group ref={group}>
      {index < 2 ? Array.from({length:5},(_,i)=><group key={i} position={[0,(i-2)*.15,0]}>
        <RoundedBox args={[1.4,.045,1.02]} radius={.045} smoothness={3}><meshStandardMaterial color="#244153" emissive={beat === 1 && i === 2 ? AMBER : color} emissiveIntensity={beat === 1 && i === 2 ? .8 : .12} metalness={.45} roughness={.25}/></RoundedBox>
        <Line points={[[-.66,.026,-.47],[.66,.026,-.47],[.66,.026,.47],[-.66,.026,.47],[-.66,.026,-.47]]} color={beat === 1 && i === 2 ? AMBER : color} lineWidth={.8} transparent opacity={.75}/>
      </group>) : <group>
        <RoundedBox args={[1.5,1.05,.16]} radius={.07}><meshStandardMaterial color={active ? '#324249' : '#172a36'} metalness={.5} roughness={.3}/></RoundedBox>
        {Array.from({length:12},(_,i)=><mesh key={i} position={[(i%4-1.5)*.32,(1-Math.floor(i/4))*.28,.1]}><boxGeometry args={[.27,.23,.04]}/><meshStandardMaterial color={i<4?'#7aaabc':i%3===0?'#c4a477':'#547a80'} emissive={AMBER} emissiveIntensity={active?.18:0} transparent opacity={active?.85:.3}/></mesh>)}
      </group>}
    </group>
    <Billboard position={[0,index===2?.8:.72,.1]}><Text font={font} fontSize={.18} color={active?'#d4e7ef':'#71818e'}>{['Language model A','Language model B','Vision encoder'][index]}</Text></Billboard>
  </group>;
}
function SignalPath({index,beat,reduced}:{index:number;beat:number;reduced:boolean}) {
  const dots = useRef<(THREE.Mesh|null)[]>([]), time = useRef(0);
  const active = index < 2 || beat === 2;
  const color = beat === 0 ? CYAN : AMBER;
  const path = useMemo(()=>new THREE.CatmullRomCurve3([
    new THREE.Vector3(...sources[index]).add(new THREE.Vector3(0,-.25,.15)),
    new THREE.Vector3(sources[index][0]*.65, -.15, .5),
    centre,
  ]),[index]);
  useEffect(()=>{time.current=0},[beat]);
  useFrame((_,dt)=>{
    if(!reduced)time.current+=Math.min(dt,.05);
    dots.current.forEach((dot,i)=>{if(!dot)return;const t=(time.current*.25-i*.04+index*.12)%1;dot.visible=active&&!reduced&&t>=0;dot.position.copy(path.getPoint(Math.max(0,t)));});
  });
  return <group>
    <Line points={path.getPoints(60)} color={color} lineWidth={active?1.15:.6} transparent opacity={active?.5:.09}/>
    {Array.from({length:5},(_,i)=><mesh key={i} ref={el=>{dots.current[i]=el;}}><sphereGeometry args={[i===0?.045:.025,12,12]}/><meshBasicMaterial color={i===0?'#e9fbff':color} transparent opacity={1-i*.17}/></mesh>)}
  </group>;
}
export default function ImplicationsExhibit({beat,reduced,caption}:{beat:number;reduced:boolean;caption?:string}) {
  const core = useRef<THREE.Group>(null!), halo=useRef<THREE.Mesh>(null!), time=useRef(0);
  const {size}=useThree();
  useFrame((_,dt)=>{
    if(!reduced)time.current+=Math.min(dt,.05);
    core.current.rotation.set(.2,reduced?.35:time.current*.18,.1);
    halo.current.rotation.set(.85,reduced?.3:time.current*.1,.2);
  });
  return <group position={[3.2,-.05,.1]} scale={size.width<800?.76:1}>
    {[0,1,2].map(i=><ModelSculpture key={i} index={i} beat={beat} reduced={reduced}/>)}
    {[0,1,2].map(i=><SignalPath key={i} index={i} beat={beat} reduced={reduced}/>)}
    {beat===0&&<Billboard position={[0,.8,1.1]}><Text font={font} fontSize={.18} color={CYAN}>More data + compute</Text></Billboard>}
    <group position={centre}>
      <mesh><sphereGeometry args={[.69,32,32]}/><meshPhysicalMaterial color="#203e54" transparent opacity={.14} roughness={.18} metalness={.5} depthWrite={false}/></mesh>
      <group ref={core}>
        {links.map(([a,b],i)=><Line key={i} points={[conceptNodes[a],conceptNodes[b]]} color={beat===0?CYAN:AMBER} transparent opacity={.6} lineWidth={.9}/>)}
        {conceptNodes.map((point,i)=><mesh key={i} position={point}><sphereGeometry args={[i===5?.075:.045,16,16]}/><meshStandardMaterial color={i===5?'#fff0cf':AMBER} emissive={AMBER} emissiveIntensity={.75} metalness={.25} roughness={.2}/></mesh>)}
      </group>
      <mesh ref={halo}><torusGeometry args={[.78,.009,8,100]}/><meshBasicMaterial color={beat===2?AMBER:CYAN} transparent opacity={.45}/></mesh>
      <mesh rotation={[1.25,.2,.3]}><torusGeometry args={[.86,.006,8,100]}/><meshBasicMaterial color={LILAC} transparent opacity={.3}/></mesh>
    </group>
    <Billboard position={[0,-1.32,1.05]}><Text font={font} fontSize={beat===0?.19:.22} color="#d9e9f1">{caption??['Could scaling recover shared concepts?','Could explanations transfer?','What crosses modalities?'][beat]}</Text></Billboard>
  </group>;
}
