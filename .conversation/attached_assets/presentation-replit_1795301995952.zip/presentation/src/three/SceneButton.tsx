import { useEffect, useState } from 'react';
import { RoundedBox, Text } from '@react-three/drei';
import type { ThreeEvent } from '@react-three/fiber';

const font = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
/** The visible control is a raycastable object, with real thickness in the room. */
export default function SceneButton({ label, position, onClick, active = false, width = 1.7, color = '#62d8f5', size = .17 }: {
  label: string; position: [number, number, number]; onClick: () => void; active?: boolean; width?: number; color?: string; size?: number;
}) {
  const [hover, setHover] = useState(false);
  useEffect(() => { if (hover) document.body.style.cursor = 'pointer'; return () => { document.body.style.cursor = ''; }; }, [hover]);
  const over = (e: ThreeEvent<PointerEvent>) => { e.stopPropagation(); setHover(true); };
  return <group position={position} onPointerOver={over} onPointerOut={() => setHover(false)} onClick={e => { e.stopPropagation(); onClick(); }}>
    <RoundedBox args={[width, .43, .1]} radius={.07} smoothness={3}>
      <meshStandardMaterial color={active || hover ? '#28465a' : '#122838'} emissive={color} emissiveIntensity={hover ? .25 : active ? .13 : .025} metalness={.45} roughness={.28}/>
    </RoundedBox>
    <mesh position={[0,-.195,.057]}><boxGeometry args={[width - .16,.012,.012]}/><meshBasicMaterial color={color} transparent opacity={active || hover ? .9 : .2}/></mesh>
    <Text font={font} fontSize={size} position={[0,.005,.065]} color={active || hover ? color : '#c2d3e0'}>{label}</Text>
  </group>;
}
