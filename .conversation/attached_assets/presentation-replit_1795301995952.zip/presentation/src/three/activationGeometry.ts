export type Point3 = [number, number, number];
// Illustrative vectors only. The remainder begins exactly at the J component's tip.
export const activationTriangle: { origin: Point3; jTip: Point3; fullTip: Point3 } = {
  origin: [-2.65, -.95, .5], jTip: [1.0, -.95, .5], fullTip: [2.15, 1.65, .5],
};
export function vectorBetween(from: Point3, to: Point3): Point3 {
  return [to[0] - from[0], to[1] - from[1], to[2] - from[2]];
}
