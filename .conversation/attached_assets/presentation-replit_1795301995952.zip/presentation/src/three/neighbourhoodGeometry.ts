export type NeighbourPoint = [number, number, number];
export const neighbourhoodItems = [
  { word: 'cat', direction: [-1.45, 1.25, .75] as NeighbourPoint, color: '#ffbd69' },
  { word: 'dog', direction: [-2.2, 1, .2] as NeighbourPoint, color: '#62d8f5' },
  { word: 'kitten', direction: [-.8, 2.15, .2] as NeighbourPoint, color: '#80ebbe' },
  { word: 'philosophy', direction: [2.25, .5, -.8] as NeighbourPoint, color: '#8398ab' },
  { word: 'number', direction: [1.1, 1.2, 2.15] as NeighbourPoint, color: '#8398ab' },
  { word: 'music', direction: [-.2, -1.55, 1.7] as NeighbourPoint, color: '#8398ab' },
];

// Rotate the representation cloud, leaving the coordinate axes fixed.
// This preserves within-model neighbours without matching raw directions.
export function neighbourhoodDirection(index: number, side: number): NeighbourPoint {
  const [x, y, z] = neighbourhoodItems[index].direction;
  return side ? [y, -x, z] : [x, y, z];
}
