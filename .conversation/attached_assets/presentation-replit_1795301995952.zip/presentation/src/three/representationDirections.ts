type Direction = [number, number, number];
const base: Direction[] = [[.45,1.6,.15],[.8,1.46,.4],[.13,1.38,-.18],[-.9,.85,.7],[.35,.7,-1.1],[-.7,1.1,-.65]];
export const representationCount = base.length;
/** Schematic only: substantial cross-model structure survives the content change.
 * The small offsets are presentation choreography, not measured retention. */
export function schematicDirection(index: number, side: number, randomised: boolean): Direction {
  const [x,y,z]=base[index];
  return [
    x+side*.12*(index%2)+(randomised?Math.sin(index+side)*.045:0),
    y-side*.06+(randomised?Math.cos(index*1.7+side)*.045:0),
    z+side*.07+(randomised?Math.sin(index*.8-side)*.04:0),
  ];
}
