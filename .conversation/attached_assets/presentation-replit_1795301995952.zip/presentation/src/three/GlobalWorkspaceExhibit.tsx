import { useEffect, useMemo, useRef, type RefObject } from 'react';
import { useFrame } from '@react-three/fiber';
import { Billboard, Line, RoundedBox, Text } from '@react-three/drei';
import * as THREE from 'three';

const CYAN = '#62d8f5', AMBER = '#ffbd69', LILAC = '#c6b1ff';
const font = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
const seed = (n: number) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const ease = (n: number) => { const x = THREE.MathUtils.clamp(n, 0, 1); return x * x * (3 - 2 * x); };
const vec = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
type Point = [number, number, number];
type Clock = RefObject<number>;
type Props = { revealed: boolean; reduced: boolean; replay: number; active: boolean; scene: number; arrivedScene: RefObject<number|null> };

// This is a narrative diagram, not a rendering of measured activations or a
// literal architecture. The larger activity field and small workspace have no
// quantitative size relationship.
const words = 'weather forecast cloud jacket morning road bag shoes water tomorrow texture temperature walking pattern raincoat distance route cold afternoon bus door window shape shelter season breeze decision outside memory street umbrella sky journey train sound evening coat thought colour action dry rain wind home light'.split(' ');
const concepts: { word: string; start: Point; end: Point; delay: number; size: number; width: number }[] = [
  { word: 'rain', start: [-1.6, -.57, -.1], end: [-.56, .93, .78], delay: .25, size: .2, width: .69 },
  { word: 'umbrella', start: [.37, -.78, -.45], end: [0, 1.29, .7], delay: .7, size: .25, width: 1.35 },
  { word: 'stay dry', start: [1.45, -.35, -.2], end: [.5, .89, .79], delay: 1.15, size: .19, width: 1.03 },
];
const satellites: { label: string; position: Point; color: string }[] = [
  { label: 'Report', position: [-2.15, .73, .38], color: CYAN },
  { label: 'Reason', position: [2.15, .73, .38], color: LILAC },
  { label: 'Plan', position: [0, -.57, 1], color: CYAN },
];

function BackgroundActivity({ reduced }: { reduced: boolean }) {
  const particles = useRef<THREE.InstancedMesh>(null!);
  const time = useRef(0);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const count = 260;
  const data = useMemo(() => Array.from({ length: count }, (_, i) => ({
    x: (seed(i * 3 + 2) - .5) * 5.55,
    y: (seed(i * 3 + 3) - .5) * 1.25 - .42,
    z: (seed(i * 3 + 4) - .5) * 1.75 - .32,
    phase: seed(i + 91) * Math.PI * 2,
    radius: .012 + seed(i + 431) * .018,
  })), []);
  const circuits = useMemo(() => Array.from({ length: 12 }, (_, i) => {
    const x = (seed(i + 10) - .5) * 4.6, y = (seed(i + 20) - .5) * .8 - .5;
    const z = (seed(i + 30) - .5) * 1.4 - .35;
    return [[x - .5, y - .1, z], [x - .16, y + .06, z + .18], [x + .14, y + .06, z + .18], [x + .44, y + .24, z - .06]] as Point[];
  }), []);
  useEffect(() => {
    particles.current.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    const color = new THREE.Color();
    data.forEach((_, i) => particles.current.setColorAt(i, color.set(i % 6 === 0 ? LILAC : i % 3 === 0 ? '#aac7d6' : CYAN)));
    if (particles.current.instanceColor) particles.current.instanceColor.needsUpdate = true;
  }, [data]);
  useFrame((_, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    const t = time.current;
    data.forEach((p, i) => {
      dummy.position.set(p.x + Math.sin(t * .34 + p.phase) * .1, p.y + Math.cos(t * .43 + p.phase) * .055, p.z + Math.sin(t * .21 + p.phase) * .12);
      const radius = p.radius * (reduced ? 1 : .75 + Math.sin(t * 1.1 + p.phase) * .25);
      dummy.scale.setScalar(radius);
      dummy.updateMatrix();
      particles.current.setMatrixAt(i, dummy.matrix);
    });
    particles.current.instanceMatrix.needsUpdate = true;
  });
  return <group>
    <RoundedBox args={[5.5, 1.38, 1.85]} position={[0, -.43, -.3]} radius={.2} smoothness={3}>
      <meshPhysicalMaterial color="#153042" transparent opacity={.065} roughness={.5} metalness={.15} depthWrite={false}/>
    </RoundedBox>
    {[-1.09, .23].map((y, i) => <Line key={i} points={[[-2.55, y, -.98], [2.55, y, -.98], [2.55, y, .4], [-2.55, y, .4], [-2.55, y, -.98]]} color={CYAN} transparent opacity={.13} lineWidth={.7}/>) }
    <instancedMesh ref={particles} args={[undefined, undefined, count]} frustumCulled={false}>
      <sphereGeometry args={[1, 6, 5]}/><meshBasicMaterial transparent opacity={.62} toneMapped={false}/>
    </instancedMesh>
    {circuits.map((points, i) => <Line key={i} points={points} color={i % 3 === 0 ? LILAC : CYAN} transparent opacity={.19} lineWidth={.6}/>) }
    {words.map((word, i) => <ActivityWord key={`${word}-${i}`} word={word} index={i} reduced={reduced}/>) }
  </group>;
}

function ActivityWord({ word, index, reduced }: { word: string; index: number; reduced: boolean }) {
  const group = useRef<THREE.Group>(null!);
  const time = useRef(index * .23);
  const base = useMemo(() => vec((seed(index + 37) - .5) * 4.95, (seed(index + 119) - .5) * .96 - .44, (seed(index + 203) - .5) * 1.5 - .3), [index]);
  useFrame(({ camera }, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    const t = time.current;
    group.current.position.set(base.x + Math.sin(t * .23 + index) * .13, base.y + Math.sin(t * .29 + index) * .055, base.z + Math.cos(t * .19 + index) * .1);
    group.current.quaternion.copy(camera.quaternion);
  });
  return <group ref={group} position={base}><Text font={font} fontSize={.115 + seed(index + 23) * .03} color={index % 4 === 0 ? '#a8bacf' : '#78a2b9'} fillOpacity={.24 + seed(index + 82) * .22} outlineColor="#07131e" outlineWidth={.008}>{word}</Text></group>;
}

function RisingConcept({ index, time, revealed, reduced }: { index: number; time: Clock; revealed: boolean; reduced: boolean }) {
  const concept = concepts[index];
  const chip = useRef<THREE.Group>(null!);
  const trail = useRef<THREE.Mesh>(null!);
  const light = useRef<THREE.MeshBasicMaterial>(null!);
  const path = useMemo(() => new THREE.CatmullRomCurve3([
    vec(...concept.start), vec(concept.start[0] * .8, .15, .05), vec(concept.end[0] * 1.05, .62, .6), vec(...concept.end),
  ]), [concept]);
  const geometry = useMemo(() => new THREE.TubeGeometry(path, 50, .012, 5, false), [path]);
  const point = useMemo(() => new THREE.Vector3(), []);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame(() => {
    const progress = revealed ? (reduced ? 1 : ease((time.current - concept.delay) / 1.1)) : 0;
    chip.current.visible = revealed && (reduced || time.current > concept.delay);
    path.getPoint(progress, point);
    chip.current.position.copy(point);
    chip.current.scale.setScalar(.62 + progress * .38);
    trail.current.visible = revealed && progress > .01;
    geometry.setDrawRange(0, Math.floor(progress * 50) * 5 * 6);
    light.current.opacity = (1 - ease((time.current - 3.1) / 1.2)) * .3 + .08;
  });
  return <group>
    <mesh ref={trail} geometry={geometry} visible={false}><meshBasicMaterial ref={light} color={AMBER} transparent opacity={.4} toneMapped={false}/></mesh>
    <group ref={chip} position={concept.start} visible={false}>
      <Billboard>
        <RoundedBox args={[concept.width, .33, .055]} radius={.07} smoothness={3}>
          <meshStandardMaterial color="#443322" emissive={AMBER} emissiveIntensity={.21} metalness={.4} roughness={.22}/>
        </RoundedBox>
        <Text position={[0, .005, .042]} font={font} fontSize={concept.size} color="#fff0d7" outlineColor="#322517" outlineWidth={.003}>{concept.word}</Text>
      </Billboard>
    </group>
  </group>;
}

function Broadcast({ index, time, revealed, reduced }: { index: number; time: Clock; revealed: boolean; reduced: boolean }) {
  const satellite = satellites[index];
  const group = useRef<THREE.Group>(null!);
  const pulse = useRef<THREE.Mesh>(null!);
  const material = useRef<THREE.MeshStandardMaterial>(null!);
  const traceMaterial = useRef<THREE.MeshBasicMaterial>(null!);
  const path = useMemo(() => new THREE.CatmullRomCurve3([
    vec(index === 0 ? -.9 : index === 1 ? .9 : .65, .91, .25),
    vec(index === 0 ? -1.35 : index === 1 ? 1.35 : .94, index === 2 ? .12 : 1.35, .56),
    vec(...satellite.position),
  ]), [index, satellite]);
  const geometry = useMemo(() => new THREE.TubeGeometry(path, 55, .013, 6, false), [path]);
  const point = useMemo(() => new THREE.Vector3(), []);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame(() => {
    const elapsed = time.current - 2.2 - index * .16;
    const progress = revealed ? (reduced ? 1 : ease(elapsed / .85)) : 0;
    geometry.setDrawRange(0, Math.floor(progress * 55) * 6 * 6);
    const lit = revealed && (reduced || elapsed > .7);
    material.current.emissiveIntensity = lit ? .3 + (reduced ? 0 : Math.sin(time.current * 2.5 - index) * .07) : .035;
    traceMaterial.current.opacity = revealed ? .58 : 0;
    const phase = ((elapsed - .85) * .42 + 100) % 1;
    pulse.current.visible = revealed && !reduced && elapsed >= 0;
    path.getPoint(elapsed < .85 ? progress : phase, point);
    pulse.current.position.copy(point);
    group.current.position.y = reduced ? 0 : Math.sin(time.current * .7 + index) * .022;
  });
  return <group>
    <mesh geometry={geometry}><meshBasicMaterial ref={traceMaterial} color={AMBER} transparent opacity={0} toneMapped={false}/></mesh>
    <mesh ref={pulse} visible={false}><sphereGeometry args={[.042, 12, 10]}/><meshBasicMaterial color="#fff2d5" toneMapped={false}/></mesh>
    <group position={satellite.position}><group ref={group}>
      <RoundedBox args={[.98, .48, .15]} radius={.095} smoothness={3}><meshStandardMaterial ref={material} color="#153042" emissive={satellite.color} emissiveIntensity={.035} metalness={.5} roughness={.25}/></RoundedBox>
      <Line points={[[-.37, -.18, .085], [.37, -.18, .085]]} color={satellite.color} transparent opacity={.6} lineWidth={1.1}/>
      <Text position={[0, .025, .09]} font={font} fontSize={.19} color="#c9dfe9">{satellite.label}</Text>
    </group></group>
  </group>;
}

function DecisionPlane({ revealed, time, reduced }: { revealed: boolean; time: Clock; reduced: boolean }) {
  const answer = useRef<THREE.Group>(null!);
  const line = useRef<THREE.MeshBasicMaterial>(null!);
  useFrame(() => {
    const progress = revealed ? (reduced ? 1 : ease((time.current - 3.2) / .6)) : 0;
    answer.current.visible = progress > .01;
    answer.current.scale.setScalar(.85 + progress * .15);
    line.current.opacity = .15 + progress * .6;
  });
  return <group position={[0, -1.04, 1.12]} rotation={[-.04, -.025, 0]}>
    <RoundedBox args={[5.25, .56, .1]} radius={.09} smoothness={3}><meshStandardMaterial color="#102536" roughness={.3} metalness={.35}/></RoundedBox>
    <mesh position={[-2.52, 0, .057]}><boxGeometry args={[.022, .43, .01]}/><meshBasicMaterial ref={line} color={AMBER} transparent opacity={.15}/></mesh>
    <Text position={[0, .13, .066]} font={font} fontSize={.19} color="#d1e3ed">Rain is forecast. What should I take?</Text>
    <group ref={answer} position={[0, -.14, .067]} visible={false}><Text font={font} fontSize={.2} color={AMBER}>Take an umbrella.</Text></group>
  </group>;
}

export default function GlobalWorkspaceExhibit({ revealed, reduced, replay, active, scene, arrivedScene }: Props) {
  const time = useRef(0);
  const halo = useRef<THREE.Mesh>(null!);
  const haloMaterial = useRef<THREE.MeshBasicMaterial>(null!);
  const daisMaterial = useRef<THREE.MeshStandardMaterial>(null!);
  useEffect(() => { time.current = reduced && revealed ? 8 : 0; }, [revealed, reduced, replay, active]);
  useFrame((_, dt) => {
    if (!active || arrivedScene.current !== scene) time.current = 0;
    else if (!reduced) time.current += Math.min(dt, .05);
    const arrival = revealed ? (reduced ? 1 : ease((time.current - 1.4) / 1)) : 0;
    halo.current.rotation.z = reduced ? .15 : time.current * .065;
    haloMaterial.current.opacity = .18 + arrival * .27;
    daisMaterial.current.emissiveIntensity = .08 + arrival * .3;
  });
  return <group>
    <BackgroundActivity reduced={reduced}/>
    <group position={[0, .55, .1]}>
      {[-.13, 0, .12].map((y, i) => <group key={i} position={[0, y, 0]} rotation={[0, .08, 0]}>
        <RoundedBox args={[2.16 - i * .12, .045, 1.5 - i * .08]} radius={.055} smoothness={3}><meshStandardMaterial ref={i === 2 ? daisMaterial : undefined} color="#403424" emissive={AMBER} emissiveIntensity={.08} metalness={.55} roughness={.23} transparent opacity={.83}/></RoundedBox>
        <Line points={[[-1 + i * .06, .029, -.68 + i * .04], [1 - i * .06, .029, -.68 + i * .04], [1 - i * .06, .029, .68 - i * .04], [-1 + i * .06, .029, .68 - i * .04], [-1 + i * .06, .029, -.68 + i * .04]]} color={AMBER} transparent opacity={.5} lineWidth={.75}/>
      </group>) }
      <mesh position={[0, .49, 0]}><boxGeometry args={[1.95, .98, 1.27]}/><meshPhysicalMaterial color={AMBER} transparent opacity={.025} roughness={.12} metalness={.2} side={THREE.DoubleSide} depthWrite={false}/></mesh>
      <mesh ref={halo} rotation={[-Math.PI / 2, 0, 0]} position={[0, .1, 0]}><ringGeometry args={[1.33, 1.342, 90]}/><meshBasicMaterial ref={haloMaterial} color={AMBER} transparent opacity={.18} side={THREE.DoubleSide} depthWrite={false}/></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.2, 0]}><circleGeometry args={[1.1, 64]}/><meshBasicMaterial color={AMBER} transparent opacity={.035} depthWrite={false}/></mesh>
    </group>
    <Billboard position={[0, 1.66, .35]}><Text font={font} fontSize={.24} color={AMBER} outlineColor="#0a1722" outlineWidth={.008}>J-space</Text></Billboard>
    {concepts.map((_, i) => <RisingConcept key={i} index={i} time={time} revealed={revealed} reduced={reduced}/>) }
    {satellites.map((_, i) => <Broadcast key={i} index={i} time={time} revealed={revealed} reduced={reduced}/>) }
    <DecisionPlane revealed={revealed} time={time} reduced={reduced}/>
  </group>;
}
