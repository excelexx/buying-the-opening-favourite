import { useRef } from 'react';
import { Line, RoundedBox, Text } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { retention } from '../data';

const font = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
const CYAN = '#62d8f5', AMBER = '#ffbd69';

function ContributionBar({ reduced }: { reduced: boolean }) {
  const time = useRef(0), bars = useRef<(THREE.Group | null)[]>([]);
  // Illustrative contributions only; no measured decomposition is asserted.
  const parts = [
    { label: 'Syntax', width: 1.05, color: CYAN },
    { label: 'Language', width: .9, color: '#c6b1ff' },
    { label: 'Document\nlength', width: .8, color: AMBER },
    { label: 'Meaning', width: 1.2, color: '#80ebbe' },
  ];
  useFrame((_, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    bars.current.forEach((bar, i) => { if (bar) bar.scale.x = reduced ? 1 : Math.max(.001, THREE.MathUtils.smoothstep(time.current, .4 + i * .15, 1.1 + i * .15)); });
  });
  return <group>
    <Text font={font} fontSize={.27} position={[0, 1.35, .1]} color="#dbeaf2">Traditional alignment</Text>
    <mesh position={[0, .55, 0]}><boxGeometry args={[4.2, .46, .16]} /><meshStandardMaterial color="#284050" transparent opacity={.5} /></mesh>
    {parts.map((part, index) => {
      const start = -2.1 + parts.slice(0, index).reduce((sum, item) => sum + item.width, 0);
      const center = start + part.width / 2;
      const labelY = index % 2 ? -1.13 : -.4;
      return <group key={part.label}>
        <group ref={bar => { bars.current[index] = bar; }} position={[start, .55, .02]}>
          <mesh position={[part.width / 2, 0, 0]}><boxGeometry args={[part.width - .025, .46, .23]} /><meshStandardMaterial color={part.color} emissive={part.color} emissiveIntensity={.18} metalness={.35} roughness={.25} /></mesh>
        </group>
        <Line points={[[center, labelY + .23, .16], [center, .13, .16], [center, .23, .16]]} color={part.color} lineWidth={1.2} transparent opacity={.8} />
        <mesh position={[center, .23, .16]}><coneGeometry args={[.055, .13, 12]} /><meshBasicMaterial color={part.color} /></mesh>
        <Text font={font} fontSize={.2} lineHeight={1.25} textAlign="center" position={[center, labelY, .18]} color={part.color}>{part.label}</Text>
      </group>;
    })}
  </group>;
}

function RetainedBars({ reduced }: { reduced: boolean }) {
  const time = useRef(0), bars = useRef<(THREE.Group | null)[]>([]);
  const values = [100, retention[0].value];
  useFrame((_, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    bars.current.forEach((bar, i) => {
      if (bar) bar.scale.x = values[i] / 100 * (reduced ? 1 : Math.max(.001, THREE.MathUtils.smoothstep(time.current, .3 + i * .35, 1.35 + i * .35)));
    });
  });
  return <group>
    <Text font={font} fontSize={.27} position={[0, 1.75, .1]} color="#dbeaf2">Traditional alignment</Text>
    {values.map((value, i) => <group key={i} position={[0, .75 - i * 1.3, 0]}>
      <Text font={font} fontSize={.23} anchorX="left" position={[-2.1, .43, .1]} color="#c9dce9">{i ? 'Randomised content' : 'Normal content'}</Text>
      <Text font={font} fontSize={.27} anchorX="right" position={[2.1, .43, .1]} color={i ? AMBER : CYAN}>{value}%</Text>
      <mesh><boxGeometry args={[4.2, .4, .13]} /><meshStandardMaterial color="#294351" transparent opacity={.5} /></mesh>
      <group ref={bar => { bars.current[i] = bar; }} position={[-2.1, 0, .03]}>
        <mesh position={[2.1, 0, 0]}><boxGeometry args={[4.2, .4, .23]} /><meshStandardMaterial color={i ? AMBER : CYAN} emissive={i ? AMBER : CYAN} emissiveIntensity={.2} metalness={.35} roughness={.25} /></mesh>
      </group>
    </group>)}
    <Line points={[[0, 1.02, .2], [0, -.88, .2]]} color="#d3e6ec" lineWidth={1} dashed dashSize={.065} gapSize={.06} transparent opacity={.65} />
    <Text font={font} fontSize={.18} position={[0, -1.04, .2]} color="#a8c5d5">50%</Text>
    <Text font={font} fontSize={.26} position={[0, -1.62, .15]} color={AMBER}>More than half remains</Text>
  </group>;
}

export default function AlignmentBars({ mode, reduced }: { mode: 'contributions' | 'retention'; reduced: boolean }) {
  const { size } = useThree();
  const mobile = size.width < 800;
  const retained = mode === 'retention';
  return <group position={mobile ? [2.9, -.65, 1] : [-4.2, retained ? .25 : -.1, 1]} rotation={[0, .07, 0]} scale={mobile ? .57 : retained ? .9 : 1}>
    <RoundedBox args={[5.1, retained ? 4.3 : 3.9, .12]} radius={.1} position={[0, retained ? .15 : 0, -.22]}>
      <meshStandardMaterial color="#142b3b" roughness={.3} metalness={.35} transparent opacity={.9} />
    </RoundedBox>
    {mode === 'contributions' ? <ContributionBar reduced={reduced} /> : <RetainedBars reduced={reduced} />}
    {retained&&<Text font={font} fontSize={.3} lineHeight={1.2} maxWidth={5.4} textAlign="center" position={[0,-2.42,.25]} color="#dbeaf2">{'We seek a measure that tracks\nmeaningful alignment.'}</Text>}
  </group>;
}
