import { useEffect, useMemo, useRef, type RefObject } from 'react';
import { Billboard, Line, Text } from '@react-three/drei';
import { useFrame, useThree, type ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';

const font = `${import.meta.env.BASE_URL}fonts/dm-sans.woff`;
type Point = [number, number, number];
type Idea = { word: string; color: string; direction: Point; initial?: Point };
const ideas: Idea[] = [
  { word: 'cat', color: '#62d8f5', direction: [-2.15, 1.35, .35] },
  { word: 'philosophy', color: '#80ebbe', direction: [2.3, .85, .65] },
  { word: 'number', color: '#c6b1ff', direction: [.85, 2.45, -1.2] },
  { word: 'music', color: '#ffbd69', direction: [-.6, -.6, 2.2] },
];
// These coordinates illustrate convergence, rather than recorded model activations.
const modelA: Idea[] = ideas.map((idea, i) => ({
  ...idea,
  initial: ([[-.4, 2.4, -.8], [1.2, -.85, 2.2], [-1.8, 1.55, -1.4], [-2.1, .3, 1.35]] as Point[])[i],
}));
const modelB: Idea[] = ideas.map((idea, i) => ({
  ...idea,
  initial: ([[1.75, 1.8, -.9], [-2.25, .5, .8], [-1.3, 1.3, -2.1], [1.7, 1.15, 1.8]] as Point[])[i],
  direction: idea.direction.map((value, axis) => value + ([.06, -.05, .04][axis]) * (i % 2 ? 1 : -1)) as Point,
}));

function GridPlane({ rotation = [0, 0, 0], opacity = .16 }: { rotation?: Point; opacity?: number }) {
  return <group rotation={rotation}>
    <mesh rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[6, 6]} />
      <meshBasicMaterial color="#527f9b" transparent opacity={opacity * .3} side={THREE.DoubleSide} depthWrite={false} />
    </mesh>
    {Array.from({ length: 13 }, (_, i) => (i - 6) * .5).filter(n => n !== 0).map(n => <group key={n}>
      <Line points={[[-3, 0, n], [3, 0, n]]} color="#6f9eb5" lineWidth={.65} transparent opacity={opacity} />
      <Line points={[[n, 0, -3], [n, 0, 3]]} color="#6f9eb5" lineWidth={.65} transparent opacity={opacity} />
    </group>)}
    <Line points={[[-3, 0, -3], [3, 0, -3], [3, 0, 3], [-3, 0, 3], [-3, 0, -3]]} color="#739caf" lineWidth={.8} transparent opacity={opacity * 1.8} />
  </group>;
}

export function CartesianFrame() {
  return <group>
    <GridPlane />
    <GridPlane rotation={[Math.PI / 2, 0, 0]} opacity={.065} />
    {([[3.2, 0, 0], [0, 2.6, 0], [0, 0, 3.2]] as Point[]).map((end, index) => {
      const direction = new THREE.Vector3(...end);
      const orientation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize());
      return <group key={index}>
        <Line points={[direction.clone().multiplyScalar(-1), [0, 0, 0]]} color="#88a9bd" lineWidth={1} transparent opacity={.24} />
        <Line points={[[0, 0, 0], end]} color="#b4d6e8" lineWidth={1.3} transparent opacity={.65} />
        <mesh position={end} quaternion={orientation}><coneGeometry args={[.052, .15, 12]} /><meshBasicMaterial color="#b4d6e8" /></mesh>
        <Billboard position={direction.multiplyScalar(1.1)}><Text font={font} fontSize={.22} color="#91b4c8">{['x', 'y', 'z'][index]}</Text></Billboard>
      </group>;
    })}
    <mesh><sphereGeometry args={[.072, 20, 20]} /><meshBasicMaterial color="#effaff" /></mesh>
    <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[.13, .15, 48]} /><meshBasicMaterial color="#b4d6e8" transparent opacity={.6} side={THREE.DoubleSide} /></mesh>
  </group>;
}

function IdeaArrow({ idea, index, time, progress, reduced, compact = false }: {
  idea: Idea; index: number; time: RefObject<number>; progress?: RefObject<number>; reduced: boolean; compact?: boolean;
}) {
  const arrow = useRef<THREE.Group>(null!);
  const body = useRef<THREE.Mesh>(null!);
  const head = useRef<THREE.Mesh>(null!);
  const label = useRef<THREE.Group>(null!);
  const pulse = useRef<THREE.Mesh>(null!);
  const target = useMemo(() => new THREE.Vector3(...idea.direction), [idea]);
  const start = useMemo(() => new THREE.Vector3(...(idea.initial ?? idea.direction)), [idea]);
  const direction = useMemo(() => new THREE.Vector3(), []);
  const up = useMemo(() => new THREE.Vector3(0, 1, 0), []);
  useFrame(() => {
    const p = progress?.current ?? 1;
    direction.copy(start).lerp(target, p * p * (3 - 2 * p));
    const reveal = reduced || progress ? 1 : THREE.MathUtils.smoothstep(time.current, .3 + index * .18, 1.4 + index * .18);
    const length = Math.max(.001, direction.length() * reveal);
    arrow.current.visible = reveal > .01;
    arrow.current.quaternion.setFromUnitVectors(up, direction.clone().normalize());
    body.current.scale.y = Math.max(.001, length - .18);
    body.current.position.y = (length - .18) / 2;
    head.current.position.y = length - .09;
    label.current.position.copy(direction).multiplyScalar(reveal);
    label.current.position.y += compact ? .32 : .28;
    label.current.visible = reveal > .85;
    pulse.current.visible = !reduced && reveal > .99;
    pulse.current.position.y = .1 + ((time.current * .3 + index * .23) % 1) * Math.max(.01, length - .25);
  });
  return <group>
    <group ref={arrow}>
      <mesh ref={body}><cylinderGeometry args={[.026, .026, 1, 12]} /><meshStandardMaterial color={idea.color} emissive={idea.color} emissiveIntensity={.6} metalness={.35} roughness={.28} /></mesh>
      <mesh ref={head}><coneGeometry args={[.105, .24, 20]} /><meshStandardMaterial color={idea.color} emissive={idea.color} emissiveIntensity={.65} metalness={.25} roughness={.25} /></mesh>
      <mesh ref={pulse}><sphereGeometry args={[.046, 12, 12]} /><meshBasicMaterial color="#ffffff" /></mesh>
    </group>
    <group ref={label}><Billboard><Text font={font} fontSize={compact ? .36 : .32} color={idea.color} outlineWidth={.012} outlineColor="#0b131f">{idea.word}</Text></Billboard></group>
  </group>;
}

function CoordinateSpace({ vectors = ideas, time, progress, reduced, compact = false }: {
  vectors?: Idea[]; time: RefObject<number>; progress?: RefObject<number>; reduced: boolean; compact?: boolean;
}) {
  return <group rotation={[0, -.38, 0]}>
    <CartesianFrame />
    {vectors.map((idea, index) => <IdeaArrow key={idea.word} {...{ idea, index, time, progress, reduced, compact }} />)}
  </group>;
}

export function IdeasExhibit({ reduced }: { reduced: boolean }) {
  const time = useRef(0);
  const group = useRef<THREE.Group>(null!);
  const { size } = useThree();
  useFrame((_, dt) => {
    if (!reduced) time.current += Math.min(dt, .05);
    group.current.rotation.y = reduced ? 0 : Math.sin(time.current * .22) * .055;
  });
  return <group position={[3.1, -.55, .2]} scale={size.width < 800 ? .7 : 1} ref={group}>
    <CoordinateSpace time={time} reduced={reduced} />
  </group>;
}

export function ConvergenceExhibit({ reduced, replay, sharedProgress, interactive, onScrub }: { reduced: boolean; replay: number; sharedProgress:number|null; interactive:boolean; onScrub:(progress:number)=>void }) {
  const time = useRef(0), progress = useRef(reduced ? 1 : 0), playing = useRef(true);
  const thumb = useRef<THREE.Mesh>(null!), fill = useRef<THREE.Mesh>(null!);
  const timeline = useRef<THREE.Group>(null!);
  const { size } = useThree();
  const lastSent=useRef(0);
  useEffect(() => { time.current = 0; progress.current = reduced ? 1 : 0; playing.current = true; }, [replay]);
  useEffect(()=>{if(sharedProgress!==null){progress.current=sharedProgress;playing.current=false;}},[sharedProgress]);
  useFrame((_, dt) => {
    if (!reduced) {
      time.current += Math.min(dt, .05);
      if (playing.current) progress.current = THREE.MathUtils.clamp((time.current - .8) / 3.2, 0, 1);
    }
    thumb.current.position.x = -2.65 + progress.current * 5.3;
    fill.current.scale.x = Math.max(.001, progress.current * 5.3);
    fill.current.position.x = -2.65 + progress.current * 2.65;
  });
  const scrub = (event: ThreeEvent<PointerEvent>,force=false) => {
    event.stopPropagation();
    if (reduced||!interactive) return;
    const point = timeline.current.worldToLocal(event.point.clone());
    progress.current = THREE.MathUtils.clamp((point.x + 2.65) / 5.3, 0, 1);
    playing.current = false;
    const now=performance.now();if(force||now-lastSent.current>200){lastSent.current=now;onScrub(progress.current);}
  };
  return <group position={[3.2, -.2, .1]} scale={size.width < 800 ? .67 : 1}>
    {[modelA, modelB].map((vectors, side) => <group key={side} position={[side ? 2.1 : -2.1, 0, 0]}>
      <Billboard position={[0, 2.1, 0]}><Text font={font} fontSize={.25} color="#dcebf5">{side ? 'Model B' : 'Model A'}</Text></Billboard>
      <group scale={.57}><CoordinateSpace {...{ vectors, time, progress, reduced }} compact /></group>
    </group>)}
    <group ref={timeline} position={[0, -1.5, 2.25]} rotation={[-.15, 0, 0]}>
      <Text font={font} fontSize={.22} color="#dcebf5" position={[0, .43, 0]}>Time</Text>
      <Line points={[[-2.65, 0, 0], [2.65, 0, 0]]} color="#506c80" lineWidth={2} />
      <mesh ref={fill} position={[-2.65, 0, .012]}><boxGeometry args={[1, .035, .025]} /><meshBasicMaterial color="#62d8f5" /></mesh>
      {Array.from({ length: 11 }, (_, i) => <Line key={i} points={[[-2.65 + i * .53, -.09, 0], [-2.65 + i * .53, .09, 0]]} color="#8bb0c7" lineWidth={1} transparent opacity={.5} />)}
      <mesh ref={thumb} position={[-2.65, 0, .06]}><sphereGeometry args={[.09, 24, 24]} /><meshStandardMaterial color="#d9f8ff" emissive="#62d8f5" emissiveIntensity={1.1} /></mesh>
      <Text font={font} fontSize={.17} color="#9ab8ca" position={[-2.65, -.3, 0]}>Earlier</Text>
      <Text font={font} fontSize={.17} color="#9ab8ca" position={[2.65, -.3, 0]}>Later</Text>
      <mesh position={[0, 0, .14]} onPointerDown={event=>scrub(event,true)} onPointerUp={event=>scrub(event,true)} onPointerMove={event => { if (event.buttons === 1) scrub(event); }}>
        <planeGeometry args={[5.8, .45]} /><meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
    </group>
  </group>;
}
