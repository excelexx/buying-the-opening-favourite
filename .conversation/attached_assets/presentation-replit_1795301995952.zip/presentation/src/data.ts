export const items = ['children', 'learning', 'growth', 'music', 'weather', 'architecture'];
export const formulas = {
  fitted: String.raw`J_{\ell}=\mathbb{E}_{i}\!\left[\mathbb{E}_{s'\geq s}\!\left[\frac{\partial h_{s',i}^{(\mathrm{final})}}{\partial h_{s,i}^{(\ell)}}\right]\right]`,
  reconstruction: String.raw`h_J=\sum_{v\in S}\alpha_v\,\bar d_v,\quad |S|=25,\;\alpha_v\geq0`,
  decomposition: String.raw`\color{#62D8F5}{h}=\color{#FFBD69}{h_J}+\color{#C6B1FF}{r}`,
  dictionary: String.raw`D_{\ell}=\widetilde W_U J_{\ell}`,
  readout: String.raw`\operatorname{lens}_{\ell}(h)=\operatorname{softmax}\!\left(W_U\,\operatorname{norm}(J_{\ell}h)\right)`,
  neighbours: String.raw`\operatorname{mNN}_{\kappa}(A,B)=\frac{1}{n\kappa}\sum_{i=1}^{n}|N_\kappa^A(i)\cap N_\kappa^B(i)|`,
  kernel: String.raw`K_\omega(i,j)=\langle\widehat h_{\omega,i},\widehat h_{\omega,j}\rangle`,
};
export const retention = [{ label: 'Full activation', value: 54.1, color: '#62D8F5' }, { label: 'J-space component', value: 26.3, color: '#FFBD69' }];
// Figure 2 and Section 4, supplied paper. Slope: change in alignment per unit HellaSwag accuracy.
export const slopes = { text: [0.76, 0.23], vision: [0.11, 0.12] };
export const pipeline = [
  { title: 'Models & data', short: '01 / INPUT', detail: 'A common set of examples for independently trained models.', decision: '11 text models; 1,000 Pile documents for the text comparison. Four vision encoders; 1,024 image–caption pairs for the cross-modal comparison.', reason: 'Shared examples let the comparison ask how models organise the same information.', tradeoff: 'The results cover these models and datasets, rather than all possible model families.' },
  { title: 'Activations', short: '02 / EXTRACT', detail: 'Read the internal representations at multiple layers.', decision: 'Mean-pool the residual stream over token positions. Compare a relative-depth band, from 35% to 90% through each model.', reason: 'Different models have different widths and layer counts. Relative depth gives a consistent sampling rule.', tradeoff: 'Pooling makes the comparison manageable but discards token-level structure.' },
  { title: 'J-space', short: '03 / DECOMPOSE', detail: 'Reconstruct a component using 25 word directions.', decision: 'Use prefitted J-lenses, greedy orthogonal matching pursuit, and non-negative least-squares coefficient refitting.', reason: 'The same decomposition procedure can be applied to each model, before comparing their representations.', tradeoff: 'A sparse reconstruction is selective; the remainder can still carry semantic information.' },
  { title: 'Alignment', short: '04 / COMPARE', detail: 'Compare neighbours instead of raw model coordinates.', decision: 'Build within-model cosine-similarity kernels and measure shared nearest neighbours. Average over the specified layer pairs.', reason: 'Models need not have the same hidden dimension to organise the same examples similarly.', tradeoff: 'Neighbour overlap measures one aspect of representational similarity. It does not equate the full representations.' },
  { title: 'Analysis', short: '05 / INTERPRET', detail: 'Relate alignment to competence and examine content sensitivity.', decision: 'Compute HellaSwag results consistently, compare original and content-randomised corpora, and analyse text–text and text–vision trends.', reason: 'The original concentration hypothesis was not supported; the content intervention helps interpret what the measurements capture.', tradeoff: 'The intervention and model sample limit the conclusions. The paper describes the full experimental checks.' },
];
