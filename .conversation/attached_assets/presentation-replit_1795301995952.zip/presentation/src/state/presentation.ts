export type ExhibitKind = 'training' | 'vectors' | 'convergence' | 'neighbourhoods' | 'models' | 'crossmodal' | 'surface' | 'workspace' | 'wordfield' | 'results' | 'engineering';
function slide<Id extends string>(value: {id:Id;label:string;title:string[];caption:string;note?:string;exhibit:ExhibitKind;visualBeat?:number;beats:string[];appendix?:boolean}) {
  return {note:'',visualBeat:0,appendix:false,...value,count:value.beats.length};
}
export const scenes = [
  slide({id:'implications',label:'Training and scaling',title:['How much does the way we train','an AI model matter?'],caption:'In recent years, the pursuit of AGI has largely followed the trend of scaling intelligence with compute, alongside breakthroughs such as attention and mixture-of-experts architectures.',exhibit:'training',beats:['Introduce representations']}),
  slide({id:'vectors',label:'Representations',title:['Ideas are high-dimensional vectors','in some representational space.'],caption:'Inside a model, a representation is a pattern of numbers. These arrows are a schematic view of those vectors.',exhibit:'vectors',visualBeat:2,beats:['Introduce convergence']}),
  slide({id:'convergence',label:'Convergence',title:['Evidence suggests that representations','converge as models grow smarter.'],caption:'Independently trained models increasingly organise similar examples in similar ways as their competence rises.',exhibit:'convergence',visualBeat:4,beats:['Extend to text and vision']}),
  slide({id:'crossmodal',label:'Beyond language',title:['Even vision and text models have representations','that converge with competence.'],caption:'This pattern has been observed across different kinds of inputs, including paired images and captions.',exhibit:'crossmodal',visualBeat:2,beats:['Name the hypothesis']}),
  slide({id:'platonic',label:'Platonic hypothesis',title:['This idea is known as the','Platonic Representation Hypothesis.'],caption:'Models trained on different data, objectives and modalities may approach a shared representation of the world.',exhibit:'crossmodal',visualBeat:2,beats:['Introduce our finding']}),
  slide({id:'inflation',label:'Our finding',title:['We show that some of this apparent','convergence is inflated.'],caption:'Part of the measured agreement reflects shared surface structure. We ask how much of the convergence is actually meaningful.',exhibit:'models',visualBeat:4,beats:['Explain alignment measures']}),
  slide({id:'alignment',label:'Measuring alignment',title:['There are many ways to measure alignment,','or notions of similarity.'],caption:'Give two models the same input and observe the similarity of their internal patterns.',exhibit:'neighbourhoods',beats:['Explain superficial agreement']}),
  slide({id:'surface',label:'Surface structure',title:['Traditional methods can track superficial content,','like sentence structure and language.'],caption:'',exhibit:'surface',visualBeat:1,beats:['Scramble the meaning']}),
  slide({id:'retention',label:'Scrambling meaning',title:['Traditional alignment can stay high','even when meaning is scrambled.'],caption:'',note:'Corpus-level results across 1,000 documents and 55 model pairs; not a measurement of this example sentence.',exhibit:'models',visualBeat:4,beats:['Introduce the global workspace']}),
  slide({id:'workspace',label:'Global workspace',title:['A small part of the model’s activity','acts like a global workspace.'],caption:'Most activity is in the background, but a small subset is available for report and reasoning.',note:'The global workspace is a functional analogy, not a claim about conscious experience. The decision is illustrative, not a recorded model readout.',exhibit:'workspace',visualBeat:1,beats:['Split the representation']}),
  slide({id:'jspace',label:'Splitting a representation',title:['We can split a representation','into the J-space and remainder.'],caption:'',exhibit:'wordfield',beats:['Compare semantic selectivity']}),
  slide({id:'content',label:'Semantic selectivity',title:['Comparing J-space alignment is more','semantically selective than full alignment.'],caption:'',note:'In this intervention · 1,000 documents · 55 model pairs · Table 1',exhibit:'results',visualBeat:1,beats:['Compare within language']}),
  slide({id:'language',label:'Within language',title:['Language models converge at much','slower rates in the J-space.'],caption:'',note:'With the neighbourhood-based alignment measure used here · slopes per unit HellaSwag accuracy',exhibit:'results',visualBeat:1,beats:['Compare across modalities']}),
  slide({id:'vision',label:'Across modalities',title:['Across text and vision, convergence rates','are similar in J-space and full space.'],caption:'Images and words have less shared surface structure. This is consistent with the similar rates we see in J-space and full-space alignment across modalities.',note:'A possible explanation, rather than a causal test · J-space decomposition on the text side only',exhibit:'results',visualBeat:1,beats:['Back to the beginning']}),
  slide({id:'engineering',label:'Implementation appendix',title:['I implemented the pipeline','to compare different models.'],caption:'From extracting activations to running the comparisons and analysing the results, I implemented every stage.',note:'The reported experiments took about 40 GPU hours.',exhibit:'engineering',appendix:true,beats:['Trace one example','Return to the results']}),
] as const;
export const narrativeScenes=scenes.filter(scene=>!scene.appendix);
export const narrativeCount=narrativeScenes.length;
export type SceneId = typeof scenes[number]['id'];
export const sceneIndex = (id: SceneId) => scenes.findIndex(scene => scene.id === id);
export type PresentationState = { scene: number; beat: number; randomised: boolean; selectedItem: number; component: 'full' | 'j' | 'remainder'; modality: 'text' | 'vision'; pipeline: number; convergenceProgress: number|null };
export const initialState: PresentationState = { scene: 0, beat: 0, randomised: false, selectedItem: 0, component: 'full', modality: 'text', pipeline: 0, convergenceProgress:null };
export type Action = { type: 'next' } | { type: 'back' } | { type: 'jump'; scene: number; beat?: number } | { type: 'randomise'; value: boolean } | { type: 'select'; item: number } | { type: 'component'; value: PresentationState['component'] } | { type: 'pipeline'; value: number } | {type:'scrub';progress:number};
export function stateAt(scene: number, beat: number): PresentationState {
  return { ...initialState, scene, beat, randomised: scenes[scene].id === 'retention', modality: scenes[scene].id === 'vision' ? 'vision' : 'text' };
}
export function reducer(state: PresentationState, action: Action): PresentationState {
  switch (action.type) {
    case 'next': {
      if(state.beat<scenes[state.scene].count-1)return stateAt(state.scene,state.beat+1);
      if(scenes[state.scene].appendix)return stateAt(sceneIndex('vision'),0);
      return stateAt((state.scene+1)%narrativeCount,0);
    }
    case 'back': return state.beat > 0 ? stateAt(state.scene, state.beat - 1) : state.scene > 0 ? stateAt(state.scene - 1, scenes[state.scene - 1].count - 1) : state;
    case 'jump': { const scene = Math.max(0, Math.min(scenes.length - 1, action.scene)); return stateAt(scene, Math.max(0, Math.min(scenes[scene].count - 1, action.beat ?? 0))); }
    case 'randomise': return scenes[state.scene].id==='retention'?{...state,randomised:action.value}:state;
    case 'select': return { ...state, selectedItem: Math.max(0, Math.min(5, action.item)) };
    case 'component': return { ...state, component: action.value };
    case 'pipeline': return { ...state, pipeline: Math.max(0, Math.min(4, action.value)) };
    case 'scrub': return {...state,convergenceProgress:Math.max(0,Math.min(1,action.progress))};
  }
}
