import { useCallback, useEffect, useRef, useState } from 'react';
import { applyCommand, DECK_VERSION, initialDeck, validDeck, type DeckState, type LiveCommand, type RoomSnapshot } from './protocol';

type Role='local'|'presenter'|'audience';
type Mode={role:Role;id:string|null};
type Status='local'|'connecting'|'connected'|'reconnecting'|'ended'|'error';
function route():Mode {const p=new URLSearchParams(location.search);return p.has('join')?{role:'audience',id:p.get('join')}:p.has('present')?{role:'presenter',id:p.get('present')}:{role:'local',id:null};}
function tokenFor(id:string){try{return sessionStorage.getItem(`presenter:${id}`)??'';}catch{return '';}}
function setRoute(mode:Mode){const url=new URL(location.href);url.searchParams.delete('join');url.searchParams.delete('present');if(mode.id)url.searchParams.set(mode.role==='presenter'?'present':'join',mode.id);history.replaceState(null,'',url);}
class RequestError extends Error {constructor(public status:number,message:string){super(message);}}
async function request(path:string,options:RequestInit={}){
  const response=await fetch(path,{...options,signal:AbortSignal.timeout(8000)});
  const data=await response.json();if(!response.ok)throw new RequestError(response.status,data.error??'Could not connect to the session.');return data;
}

export function useLiveSession(){
  const [mode,setMode]=useState<Mode>(route),[deck,setDeck]=useState<DeckState>(initialDeck);
  const [status,setStatus]=useState<Status>(mode.role==='local'?'local':'connecting');
  const [following,setFollowing]=useState(true),[snapshot,setSnapshot]=useState<RoomSnapshot|null>(null),[error,setError]=useState('');
  const modeRef=useRef(mode),deckRef=useRef(deck),followRef=useRef(following),latest=useRef<RoomSnapshot|null>(null),generation=useRef(0),token=useRef('');
  modeRef.current=mode;deckRef.current=deck;followRef.current=following;
  const queue=useRef<{commandId:string;command:LiveCommand}[]>([]),pumping=useRef(false),retry=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  const apply=useCallback((value:RoomSnapshot)=>{
    if(value.deckVersion!==DECK_VERSION||!validDeck(value))throw new RequestError(409,'This session uses another version. Reload the page.');
    const previous=latest.current;if(previous&&value.revision<previous.revision)return;
    latest.current=value;setSnapshot(value);
    if((modeRef.current.role==='presenter'||followRef.current)&&(!previous||value.revision!==previous.revision))setDeck({state:value.state,replay:value.replay});
    if(value.ended)setStatus('ended');
  },[]);
  const pump=useRef<()=>Promise<void>>(async()=>{});
  pump.current=async()=>{
    if(pumping.current||modeRef.current.role!=='presenter'||!modeRef.current.id)return;
    pumping.current=true;const current=generation.current,id=modeRef.current.id;
    try{
      while(queue.current.length&&current===generation.current){
        const item=queue.current[0];
        const result=await request(`/api/rooms/${id}/commands`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token.current}`},body:JSON.stringify({...item,deckVersion:DECK_VERSION})});
        if(current!==generation.current)return;
        queue.current.shift();apply(result);setError('');
      }
    }catch(err){
      if(current!==generation.current)return;
      if(err instanceof RequestError&&[400,403,404,409,410].includes(err.status)){queue.current=[];setError(err.message);setStatus(err.status===410?'ended':'error');}
      else{setStatus('reconnecting');setError('Reconnecting. Your last action will be retried.');retry.current=setTimeout(()=>void pump.current(),2000);}
    }finally{if(current===generation.current)pumping.current=false;}
  };
  const send=useCallback((command:LiveCommand)=>{
    const current=modeRef.current;
    if(current.role==='audience'&&followRef.current)return;
    if(current.role!=='presenter'){setDeck(value=>applyCommand(value,command));return;}
    if(queue.current.length>=50){setError('Waiting for the connection before sending more actions.');return;}
    const last=queue.current[queue.current.length-1];
    if(command.type==='scrub'&&last?.command.type==='scrub'&&queue.current.length>1)queue.current[queue.current.length-1]={commandId:crypto.randomUUID(),command};
    else queue.current.push({commandId:crypto.randomUUID(),command});
    void pump.current();
  },[]);
  useEffect(()=>{
    const current=++generation.current;queue.current=[];latest.current=null;setSnapshot(null);setError('');
    clearTimeout(retry.current);pumping.current=false;
    if(mode.role==='local'){setStatus('local');return;}
    setStatus('connecting');setFollowing(true);
    if(!mode.id||!/^[A-F0-9]{12}$/.test(mode.id)){setStatus('error');setError('This join link is not valid.');return;}
    const id=mode.id;token.current=mode.role==='presenter'?tokenFor(id):'';
    if(mode.role==='presenter'&&!token.current){setStatus('error');setError('Open the presenter tab where you started this session, or start a new one.');return;}
    let events:EventSource|undefined,heartbeat:ReturnType<typeof setInterval>|undefined,stopped=false,probing=false;
    const valid=()=>!stopped&&current===generation.current;
    const fail=(err:unknown)=>{if(!valid())return;setError(err instanceof Error?err.message:'Could not connect.');setStatus(err instanceof RequestError&&err.status===410?'ended':'error');events?.close();clearInterval(heartbeat);};
    const ping=async()=>{
      try{const result=await request(`/api/rooms/${id}/heartbeat`,{method:'POST',headers:{Authorization:`Bearer ${token.current}`}});if(valid()){apply(result);if(events?.readyState===EventSource.OPEN){setStatus('connected');setError('');}}}
      catch(err){if(err instanceof RequestError&&[403,404,410].includes(err.status))fail(err);else if(valid())setStatus('reconnecting');}
    };
    const connect=async()=>{
      try{
        const result=await request(`/api/rooms/${id}`);if(!valid())return;apply(result);if(result.ended)return;
        if(mode.role==='presenter'){await request(`/api/rooms/${id}/heartbeat`,{method:'POST',headers:{Authorization:`Bearer ${token.current}`}});if(!valid())return;heartbeat=setInterval(()=>void ping(),8000);}
        events=new EventSource(`/api/rooms/${id}/events?role=${mode.role}&client=${crypto.randomUUID()}`);
        events.addEventListener('snapshot',event=>{
          if(!valid())return;
          try{const value=JSON.parse((event as MessageEvent).data) as RoomSnapshot;apply(value);setStatus(value.ended?'ended':'connected');setError('');if(value.ended){events?.close();clearInterval(heartbeat);}}
          catch(err){fail(err);}
        });
        events.onerror=()=>{
          if(!valid())return;setStatus('reconnecting');
          if(!probing){probing=true;void request(`/api/rooms/${id}`).then(value=>{if(valid()){apply(value);if(value.ended){events?.close();clearInterval(heartbeat);}}}).catch(err=>{if(err instanceof RequestError&&[404,410].includes(err.status))fail(err);}).finally(()=>{probing=false;});}
        };
      }catch(err){if(err instanceof RequestError)fail(err);else if(valid()){setStatus('reconnecting');retry.current=setTimeout(()=>void connect(),2000);}}
    };
    void connect();
    return()=>{stopped=true;events?.close();clearInterval(heartbeat);clearTimeout(retry.current);generation.current++;};
  },[mode,apply]);

  const start=async(presenterKey:string)=>{
    const result=await request('/api/rooms',{method:'POST',headers:{'Content-Type':'application/json',...(presenterKey?{Authorization:`Bearer ${presenterKey}`}:{})},body:JSON.stringify({deck:deckRef.current,deckVersion:DECK_VERSION})});
    sessionStorage.setItem(`presenter:${result.snapshot.id}`,result.token);
    const next:Mode={role:'presenter',id:result.snapshot.id};setRoute(next);setMode(next);
  };
  const end=async()=>{if(mode.id){const result=await request(`/api/rooms/${mode.id}`,{method:'DELETE',headers:{Authorization:`Bearer ${token.current}`}});apply(result);sessionStorage.removeItem(`presenter:${mode.id}`);}};
  const leave=()=>{setRoute({role:'local',id:null});setMode({role:'local',id:null});setFollowing(true);};
  const toggleFollow=()=>{setFollowing(value=>{if(!value&&latest.current)setDeck({state:latest.current.state,replay:latest.current.replay});return !value;});};
  const joinUrl=mode.id?`${location.origin}${location.pathname}?join=${mode.id}`:'';
  return {state:deck.state,replay:deck.replay,send,role:mode.role,status,error,following,snapshot,joinUrl,start,end,leave,toggleFollow,canControl:mode.role==='local'||(mode.role==='presenter'&&status==='connected')||(mode.role==='audience'&&!following)};
}
export type LiveSession=ReturnType<typeof useLiveSession>;
