import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Copy, Radio, Users, X, Check } from 'lucide-react';
import type { LiveSession } from './useLiveSession';
import './live.css';

export function LiveSessionButton({live,onClick}:{live:LiveSession;onClick:()=>void}){
  if(live.role==='audience')return null;
  return <button className="text-button live-open" onClick={onClick}><Radio size={15}/>{live.role==='presenter'?'Live session':'Present live'}{live.role==='presenter'&&<span className="viewer-number">{live.snapshot?.viewers??0}<Users size={12}/></span>}</button>;
}
export function LiveStatus({live}:{live:LiveSession}){
  if(live.role==='local')return null;
  const terminal=live.status==='ended'||live.status==='error';
  const message=live.status==='ended'?'This session has ended.':live.status==='error'?live.error:live.status==='connecting'?'Joining the session…':live.status==='reconnecting'?'Reconnecting to the live session…':live.role==='audience'?!live.following?'Browsing on your own':!live.snapshot?.presenterOnline?'Waiting for the presenter to reconnect…':'Following the presenter':`${live.snapshot?.viewers??0} ${(live.snapshot?.viewers??0)===1?'viewer':'viewers'} connected`;
  return <div className={`live-status ${live.status}`} role="status"><span className="live-dot"/><span>{message}</span>
    {live.role==='audience'&&!terminal&&<button onClick={live.toggleFollow}>{live.following?'Explore on my own':'Follow presenter'}</button>}
    {terminal&&<button onClick={live.leave}>Open on my own</button>}
  </div>;
}
export function LiveSessionDialog({live,open,onClose}:{live:LiveSession;open:boolean;onClose:()=>void}){
  const dialog=useRef<HTMLDialogElement>(null),link=useRef<HTMLInputElement>(null);
  const [key,setKey]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[copied,setCopied]=useState(false);
  const [config,setConfig]=useState<{requiresKey:boolean;hostingEnabled:boolean}|null>(null);
  useEffect(()=>{if(open)dialog.current?.showModal();else dialog.current?.close();},[open]);
  useEffect(()=>{if(!open||live.role!=='local')return;let cancelled=false;setError('');void fetch('/api/config').then(async r=>{if(!r.ok)throw new Error();return r.json();}).then(value=>{if(!cancelled)setConfig(value);}).catch(()=>{if(!cancelled)setError('The live server is not running. Start the app with npm run dev, or ask Replit to start the supplied server.');});return()=>{cancelled=true;};},[open,live.role]);
  const start=async(e:FormEvent)=>{e.preventDefault();setBusy(true);setError('');try{await live.start(key);setKey('');}catch(err){setError(err instanceof Error?err.message:'Could not start the session.');}finally{setBusy(false);}};
  const copy=async()=>{try{await navigator.clipboard.writeText(live.joinUrl);setCopied(true);setTimeout(()=>setCopied(false),2000);}catch{link.current?.focus();link.current?.select();setError('Select and copy the link above.');}};
  const end=async()=>{setBusy(true);setError('');try{await live.end();onClose();}catch(err){setError(err instanceof Error?err.message:'Could not end the session.');}finally{setBusy(false);}};
  return <dialog ref={dialog} className="live-dialog" onCancel={onClose} onClick={e=>{if(e.target===dialog.current)onClose();}}>
    <button className="icon-button live-close" aria-label="Close live session" onClick={onClose}><X size={20}/></button>
    <div className="live-symbol"><Radio size={24}/></div>
    {live.role==='presenter'&&live.status!=='ended'?<>
      <h2>Invite your interviewers</h2><p>Send this link. Everyone who joins will follow your slides and interactions.</p>
      <label htmlFor="audience-link">Audience link</label><div className="join-link-row"><input ref={link} id="audience-link" readOnly value={live.joinUrl} onFocus={e=>e.currentTarget.select()}/><button className="live-primary copy-link" onClick={()=>void copy()} aria-label="Copy audience link">{copied?<Check size={18}/>:<Copy size={18}/>}</button></div>
      <div className="session-summary"><Users size={17}/><span>{live.snapshot?.viewers??0} connected</span><span>{copied?'Link copied':live.status==='connected'?'You control the presentation':'Connecting…'}</span></div>
      <div className="live-dialog-actions"><button className="live-secondary" disabled={busy} onClick={()=>void end()}>End session</button><button className="live-primary" onClick={onClose}>Back to presenting</button></div>
    </>:<>
      <h2>Present together</h2><p>Create a live session, send the audience link, and guide everyone through the presentation.</p>
      <form onSubmit={start}>
        {config?.requiresKey&&<><label htmlFor="presenter-key">Presenter key</label><input id="presenter-key" type="password" autoComplete="off" value={key} onChange={e=>setKey(e.target.value)} placeholder="Your private presenter key" required/></>}
        {config&&!config.hostingEnabled&&<p className="live-error">Ask Replit to set the PRESENTER_KEY secret and restart the server.</p>}
        <button className="live-primary start-live" disabled={busy||!config?.hostingEnabled}>{busy?'Starting…':'Start live session'}</button>
      </form>
    </>}
    {(error||live.error)&&<p className="live-error" role="alert">{error||live.error}</p>}
  </dialog>;
}
