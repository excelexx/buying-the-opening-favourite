import { initialState, reducer, scenes, type Action, type PresentationState } from '../state/presentation.js';

export const DECK_VERSION = 'jspace-14-live-v1';
export type LiveCommand = Action | {type:'replay'};
export type DeckState = {state:PresentationState;replay:number};
export type RoomSnapshot = DeckState & {id:string;revision:number;deckVersion:string;viewers:number;presenterOnline:boolean;ended:boolean;expiresAt:number};
export const initialDeck:DeckState = {state:initialState,replay:0};
const object = (v:unknown):v is Record<string,unknown> => !!v && typeof v==='object' && !Array.isArray(v);
const integer = (v:unknown,min:number,max:number):v is number => typeof v==='number' && Number.isInteger(v) && v>=min && v<=max;

export function validState(v:unknown):v is PresentationState {
  if(!object(v)||!integer(v.scene,0,scenes.length-1))return false;
  const scene=scenes[v.scene];
  return integer(v.beat,0,scene.count-1)&&typeof v.randomised==='boolean'&&(!v.randomised||scene.id==='retention')&&
    integer(v.selectedItem,0,5)&&['full','j','remainder'].includes(String(v.component))&&
    v.modality===(scene.id==='vision'?'vision':'text')&&integer(v.pipeline,0,4)&&
    (v.convergenceProgress===null||(typeof v.convergenceProgress==='number'&&Number.isFinite(v.convergenceProgress)&&v.convergenceProgress>=0&&v.convergenceProgress<=1));
}
export function validDeck(v:unknown):v is DeckState {return object(v)&&validState(v.state)&&integer(v.replay,0,1_000_000);}
export function validCommand(v:unknown):v is LiveCommand {
  if(!object(v))return false;
  switch(v.type){
    case 'next':case 'back':case 'replay':return true;
    case 'jump':return integer(v.scene,0,scenes.length-1)&&(v.beat===undefined||integer(v.beat,0,scenes[v.scene].count-1));
    case 'randomise':return typeof v.value==='boolean';
    case 'select':return integer(v.item,0,5);
    case 'component':return ['full','j','remainder'].includes(String(v.value));
    case 'pipeline':return integer(v.value,0,4);
    case 'scrub':return typeof v.progress==='number'&&Number.isFinite(v.progress)&&v.progress>=0&&v.progress<=1;
    default:return false;
  }
}
export function applyCommand(deck:DeckState,command:LiveCommand):DeckState {
  if(command.type==='replay')return {state:{...deck.state,convergenceProgress:null},replay:deck.replay+1};
  return {state:reducer(deck.state,command),replay:deck.replay+(command.type==='randomise'?1:0)};
}
