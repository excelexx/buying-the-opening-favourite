# J-space research presentation

A React/TypeScript presentation for Alexander Zhang's Replit panel interview, with a Node server for live audience following. The main narrative has **14 slides and 14 presenter-controlled steps**, each slide at its own location in a fullscreen 3D room. An optional implementation appendix sits at a fifteenth location and has two additional reveals outside the main cycle.

## Run

Use Node.js 22.12+ (Node 22 is configured for Replit).

```sh
npm ci
npm run dev
```

Open `http://localhost:5173`. The Node server runs Vite and the live-session API together. On Replit the supplied port mapping uses port 3000.

```sh
npm test
npm run build
# With PRESENTER_KEY supplied through the environment:
npm start
```

The build produces the frontend in `dist/` and the server in `build/`. `npm start` serves both on `0.0.0.0:$PORT` (default 3000). Production startup requires the `PRESENTER_KEY` environment variable. Fonts, mathematics assets, 3D word fonts, and the supplied paper are local assets. No model inference, external API key, or database is needed. `npm run preview` previews only the static visuals; use the Node server for live sessions.

## Present live

1. Open the deployed app and choose **Present live**.
2. Enter your private presenter key, then choose **Start live session**. A local loopback development session does not require a key unless one is configured.
3. Copy the **Audience link** and send it to your interviewers. They join without an account and immediately see your current slide.
4. Keep presenting from the original tab. Slides, reveals, sentence toggles, replay actions, the convergence timeline and appendix interactions follow your controls.
5. Viewers can choose **Explore on my own**, then **Follow presenter** to return to your current state. **End session** stops following for everyone.

The audience link grants viewing access only. The presenter credential stays in the original tab's session storage, so refreshing that tab restores control. The address containing `?present=` is not a shareable presenter login. Use the `?join=` link shown in the dialog for the audience.

Rooms last up to eight hours and live in server memory. Restarting or redeploying the server clears them. Start a fresh session before the interview and leave the presenter tab open. Transient connection loss reconnects to the current state; a viewer arriving late also receives the current state. Ambient animations run locally, so matching frames and pointer movement are not streamed.

## Present

- Right arrow or Space: next reveal, then next slide.
- Left arrow: previous reveal or slide.
- Home: opening slide.
- F: fullscreen, where the browser permits it.
- Scene rail or dropdown: jump to a slide; the dropdown also includes the appendix.
- Top-bar pause control: reduce motion while preserving every visual state.
- Tap the in-scene sentence toggles, neighbourhood comparison, workspace replay, or pipeline controls to inspect them.
- The single paper entry point in the top bar opens source details and links.

Headings are extruded 3D meshes that float above each exhibit. Equations and supporting copy are projected from world-space anchors. The sentence, scene controls, vectors and result charts are physical 3D objects. The extended room contains 14 main exhibit locations and an appendix location. Transitions physically move the camera deeper into the room or back through its floor grid and architectural frames. Adjacent slides can reuse a graphic while showing different headings and captions. The next control is an accessible arrow-only button.

The flow is training and scaling → representations → convergence → text–vision convergence → the Platonic Representation Hypothesis → the measurement concern → alignment measures → shared surface structure → scrambling and retained alignment → global workspace → J-space decomposition → semantic selectivity → within-language results → cross-modal results.

Slide 2 shows cat, philosophy, number and music as labeled arrows in a 3D Cartesian space. Slide 3 places two coordinate spaces beside each other: over a four-second schematic time scale, both models’ arrows turn visibly toward similar directions. Click or drag along the time scale to inspect an earlier or later state, or use Replay to run the animation again. The motion control pauses the animation.

Slide 7 compares two Cartesian spaces with different arrow directions. Its caption introduces giving both models the same input. The animation waits for the camera to settle, then reveals the cat pair, dog and kitten, and the corresponding triangular neighbourhoods over approximately 7.5 seconds. A rigid rotation preserves their grouping while changing their coordinates. Replay comparison restarts the sequence; returning to the slide waits for arrival again.

Slide 8 feeds two sentences into two models, with arrows identifying their shared syntax, English language and equal length. A high traditional-alignment bar replaces the caption, with schematic labelled contributions. Slide 9 combines content scrambling, retained alignment and the goal of meaningful alignment. Original / Randomised switches the input in place, keeping the camera and heading unchanged. It compares normal content at 100% with randomised content retaining 54.1%, with a halfway marker. The instruction is inside the sentence plane; the measurement objective sits below the chart. The nearly matching arrows are schematic and do not imply an unchanged score.

Slide 10 combines the global-workspace introduction and decision animation. Its compact two-line caption sits beneath the heading in the 3D room. The graphic keeps its width and is slightly compressed vertically. After camera arrival, rain, umbrella and stay dry emerge from background activity and broadcast outward; Replay the decision repeats it in place. The decision is illustrative, not a model trace. Slide 11 is one large tip-to-tail component split with the fitted J-lens and vector-sum formulas, no caption and no component or replay buttons. Each main slide has one reveal. Small disclaimer footnotes are kept off the slides; source context remains in the paper details and private notes.

Slide 12 centers and enlarges the retention chart without a caption, with a bracket marking the 27.8 percentage-point gap between full activation and J-space. Slide 13 also has no caption and centers the language-results chart. Its slope axis runs from 0 to 0.8; slide 14 uses a separate 0–0.2 axis to make the text–vision slopes of +0.11 and +0.12 easier to compare.

The final result slide has a physical **How I built it** control that opens the implementation appendix. The appendix is also in the slide dropdown but not in the 14-slide rail or ordinary Next cycle. It has two reveals and returns to the final text–vision result; Next from that result loops to the opening. The appendix preserves Alexander's confirmed ownership of every implementation stage and his coauthor's minor final edits.

Use a full browser window for presenting. Narrow windows use a vertically stacked mobile layout. Supporting copy remains enlarged for screen-sharing readability.

## Replit handoff

The server, presenter controls, audience links and `.replit` configuration are implemented. **Public deployment is still for Replit.** Follow [REPLIT_SETUP.md](./REPLIT_SETUP.md), which includes a ready-to-paste handoff prompt.

Use one always-running server instance because rooms are held in memory. Replit Reserved VM is the intended target. A static deployment cannot run the live API, and multiple instances would need a shared room store and pub/sub first.

`src/state/presentation.ts` is the source of truth for slide headings, captions, notes, exhibit kinds, reveals and serialisable navigation state. `narrativeScenes` excludes the appendix. The server applies the same reducer to authenticated commands and broadcasts snapshots over Server-Sent Events. Paper drawers, motion preferences and fullscreen remain local.

- `server/index.ts`: development/production entry point and port binding.
- `server/http.ts`: authentication, HTTP API, event streams and built-asset serving.
- `server/rooms.ts`: bounded in-memory sessions, presenter presence and idempotent commands.
- `src/live/protocol.ts`: validated shared state and command types.
- `src/live/useLiveSession.ts`: session lifecycle, reconnects, command queue and audience following.
- `src/live/LiveSessionUI.tsx`: hosting dialog, invite link and following controls.
- `.replit`: run, build and port configuration.
- `tests/live.test.ts`: authentication, isolation, state sync, retries, expiry, SSE reconnection and HTTP boundary checks.

- `src/three/ResearchStage.tsx`: persistent world, models, pulses, physical charts, extruded headings, camera travel and fallback.
- `src/three/sceneLayout.ts`: slide stations and heading layout.
- `src/three/NeighbourhoodExhibit.tsx`: arrival-gated matching-neighbourhood animation.
- `src/three/AlignmentBars.tsx`: contribution and retention charts, plus the merged experiment objective.
- `src/three/RepresentationExhibits.tsx`: Cartesian idea vectors and the two-model convergence animation with its time scale.
- `src/three/ImplicationsExhibit.tsx`: shared-concept and training visuals.
- `src/three/GlobalWorkspaceExhibit.tsx`: background activity, highlighted concepts and the replayable decision.
- `src/three/WordField.tsx`: subdued drifting vocabulary, the single children example and the enlarged tip-to-tail activation sum.
- `src/three/representationDirections.ts`: deterministic, closely matching schematic directions before and after scrambling.
- `src/sceneControls.ts`: commands for raycastable scene controls and their accessible equivalents.
- `src/App.tsx`: slide copy, controls, retention charts, equations, paper and contribution drawers.
- `src/data.ts`: equations, sourced results and implementation details.
- `src/styles.css`: presentation layout and responsive styling.
- `notes/speaker-notes.md`: private preparation notes, not imported into the app or copied to the production build.
- `public/paper.pdf`: the supplied paper.
- `tests/presentation.test.ts`: navigation, slide order, reversible state, vector addition and equation checks.

The 3D visuals are schematic. Retention values come from Table 1; slope values come from Figure 2 / Section 4 of the supplied paper. No fabricated scatter points are used. Experimental controls remain in private speaker notes for verbal discussion. The J-lens is prior work, J-space is not a perfect separation of meaning, and the cross-modal explanation is an interpretation rather than a causal test.
