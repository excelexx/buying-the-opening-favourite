# Do AIs Think Alike?

## Current direction — 26 October 2026

This document replaces the earlier ten-scene, 28-reveal storyboard. The implemented presentation now follows Alexander's revised narration as **14 main slides and 14 main steps**. Each main slide has a separate station in the shared 3D room. Every main slide now has one reveal. The implementation walkthrough is an optional fifteenth station with two reveals, outside the main Next cycle.

The exact headings, captions, source notes and exhibit types live in `presentation/src/state/presentation.ts`. The storyboard below records that copy. Adjacent slides may reuse the same kind of graphic while their captions and headings change. The camera still travels between distinct locations, so the presentation feels like moving through one room.

The final text–vision result includes How I built it. That control and the slide dropdown open the appendix. The appendix returns to the final result; ordinary Next from the final result loops to the opening. The rail and scene counter show the 14 main slides, with the appendix separately labelled.

## Product brief and scope

Build the presentation frontend for Alexander Zhang's Replit panel interview: narrative, real 3D animation, interactive demonstrations, LaTeX-style equations, accurate result charts, local navigation and visual polish. The audience is unfamiliar with mechanistic interpretability. Keep the story understandable from the graphics and ordinary language, without requiring a derivation.

The central question is how much measured similarity between AI representations reflects shared meaning. Begin with training and scaling, introduce vectors and convergence, name the Platonic Representation Hypothesis, explain the measurement problem, then introduce J-space and show the results.

The original project asked whether convergence was concentrated in J-space; that hypothesis was not supported. Preserve that research history in speaker notes and discussion. Do not imply that the final paper framing was necessarily the starting hypothesis.

Alexander implemented every stage of the pipeline. His coauthor contributed minor final edits. The J-lens itself is prior work. Do not invent optimisation stories, bugs, or contributions beyond those confirmed facts.

The latest scope includes live audience following: one Node server, protected presenter session creation, a separate audience join link, shared slide/interaction state, viewer count, reconnects, and independent browsing with a return-to-presenter control. Public deployment remains for the Replit bot. Use the supplied `.replit` configuration and `REPLIT_SETUP.md` handoff. The current in-memory room store requires one always-running server instance; it does not require a database. Keep paper drawers, motion preferences and fullscreen local.

## Visual and interaction rules

- Fill the viewport with one continuous 3D room, including a visible floor and architecture that establish depth.
- Give all 14 main slides and the optional appendix their own stations. Transitions move the camera through the room, with forward/back depth motion rather than sideways panels.
- Render visible slide headings as extruded 3D meshes above the exhibits. Project body copy and KaTeX from world-space anchors so they move with the exhibit. Give graphs physical planes, visible edges and extruded bars.
- Keep side copy large enough for screen sharing and adjust layout so it does not collide with the headings, diagrams or equations.
- Do not restore small all-caps subheadings, symbol-help headings, quote cards, an author byline or repeated paper links. Keep one paper entry point in the toolbar and an arrow-only next button.
- Use DM Sans for the counter, now `01 / 14`. Keep the dark navy, cyan full-activation, amber J-space and lilac remainder palette with clear labels as well as colour.
- Put the sentence, Original / Randomised controls, neighbourhood highlighting, relevant replay controls and pipeline stages inside the 3D scene. Global navigation and the toolbar can remain outside it.
- The word bank has 340 gently drifting words on desktop and 150 on narrow screens. The decomposition brings forward one example, children, while the actual method retains 25 selected directions.
- Draw a long diagonal full-activation arrow. Draw J-space from the same origin, then the remainder from its tip to the full-activation tip. This is tip-to-tail addition, not a branching diagram or an orthogonal projection.
- Keep arrow fans very similar before and after content scrambling. Their geometry is schematic; it does not encode the measured 54.1% retention.
- Use a single travelling input pulse that forks to the models. Replay controls repeat meaningful animations; ambient movement stays subtle.
- Support reduced motion with settled, readable states. No conclusion may depend on seeing an animation. No sound, flashing or mandatory free-camera navigation.
- Use a readable stacked arrangement on narrow screens. Provide semantic controls and keyboard access for every physical interaction.

## Main storyboard

### 01 — Training and scaling

**Headline:** How much does the way we train an AI model matter?

**Caption:** In recent years, the pursuit of AGI has largely followed the trend of scaling intelligence with compute, alongside breakthroughs such as attention and mixture-of-experts architectures.

**Visual and interaction:** Hovering models connect to a shared central constellation. Keep the training-and-scaling motivation in the opening caption; this is a schematic introduction, not a measured scaling result.

### 02 — Representations

**Headline:** Ideas are high-dimensional vectors in some representational space.

**Caption:** Inside a model, a representation is a pattern of numbers. These arrows are a schematic view of those vectors.

**Visual and interaction:** A 3D Cartesian space with visible grid planes and four animated arrows labeled cat, philosophy, number and music. Three-dimensional arrows stand in for high-dimensional vectors.

### 03 — Convergence

**Headline:** Evidence suggests that representations converge as models grow smarter.

**Caption:** Independently trained models increasingly organise similar examples in similar ways as their competence rises.

**Visual and interaction:** Two 3D Cartesian spaces show the same four idea colors. As a schematic time scale advances, corresponding arrows turn toward similar directions. The time scale supports scrubbing and Replay restarts the animation.

### 04 — Beyond language

**Headline:** Even vision and text models have representations that converge with competence.

**Caption:** This pattern has been observed across different kinds of inputs, including paired images and captions.

**Visual and interaction:** Pair text and vision representations in the shared-concept exhibit. The visual introduces the claim before naming it.

### 05 — Platonic hypothesis

**Headline:** This idea is known as the Platonic Representation Hypothesis.

**Caption:** Models trained on different data, objectives and modalities may approach a shared representation of the world.

**Visual and interaction:** Reuse the text–vision exhibit with the new title and caption. Let the audience connect the name to the idea already introduced.

### 06 — Our finding

**Headline:** We show that some of this apparent convergence is inflated.

**Caption:** Part of the measured agreement reflects shared surface structure. We ask how much of the convergence is actually meaningful.

**Visual and interaction:** Return to the model comparison. Explain the measurement concern before walking through how alignment is measured. Do not depict all convergence as an artefact.

### 07 — Measuring alignment

**Headline:** There are many ways to measure alignment, or notions of similarity.

**Caption:** Give two models the same input and observe the similarity of their internal patterns.

**Visual and interaction:** Two Cartesian spaces have differently directed arrows. Wait for the camera to arrive, then play a slower, approximately 7.5-second reveal: highlight cat in each, then dog and kitten, then the matching triangular groups and connecting pulses. Their orientation stays different throughout; a rigid rotation preserves the within-model relationships. Replay comparison repeats the sequence. Returning to this slide restarts it after arrival.

### 08 — Surface structure

**Headline:** Traditional methods can track superficial content, like sentence structure and language.

**Caption:** None. Use a high traditional-alignment bar with labelled segments for syntax, language, document length and meaning. Segment widths are schematic, not measured contributions.

**Visual and interaction:** Feed “The cat slept by the fire.” and “The car stopped by the shop.” into two hovering models. Arrows connect the sentences to three shared-feature callouts: syntax, English language and six-word document length.

### 09 — Scrambling meaning

**Headline:** Traditional alignment can stay high even when meaning is scrambled.

**Caption:** None. The sentence plane says “Keep the structure, but scramble the content words.” Below the chart, show “We seek a measure that tracks meaningful alignment.”

**Speaker context (off screen):** Corpus-level results across 1,000 documents and 55 model pairs; not a measurement of this example sentence.

**Visual and interaction:** One slide combines the intervention, retained alignment and motivation for a meaningful measure. Original / Randomised switches the sentence and triggers its input pulse without moving the camera or changing slides. The initial view is randomised. Keep nearly matching schematic arrow fans. Compare normal content at 100% with randomised content retaining 54.1%; a halfway marker and “More than half remains” emphasize the retained fraction. Next goes directly to the global workspace.

### 10 — Global workspace

**Headline:** A small part of the model’s activity acts like a global workspace.

**Caption:** Most activity is in the background, but a small subset is available for report and reasoning.

**Speaker context (off screen):** The global workspace is a functional analogy, not a claim about conscious experience. The rain-and-umbrella decision is illustrative, not a recorded model readout.

**Visual and interaction:** Place the caption in two compact lines beneath the heading, inside the 3D scene. Keep the illustration wide and compress its height slightly to leave the graphic dominant. After the camera arrives, rain, umbrella and stay dry rise from background activity into J-space and broadcast outward. Replay the decision repeats the animation on this slide. Next goes directly to the vector split; there is no separate report-and-reasoning slide.

### 11 — Splitting a representation

**Headline:** We can split a representation into the J-space and remainder.

**Caption:** None. Show only the fitted J-lens and vector-sum formulas alongside the graphic.

**Visual and interaction:** One enlarged tip-to-tail vector addition, animated on entry, with the single children example and a subdued word field. Remove the component-selection and Replay addition buttons, the explanatory caption and the children footnote. Both formulas remain visible together.

### 12 — Semantic selectivity

**Headline:** Comparing J-space alignment is more semantically selective than full alignment.

**Caption:** None. Center and enlarge the retention chart.

**Speaker context (off screen):** In this intervention · 1,000 documents · 55 model pairs · Table 1

**Visual and interaction:** Show two large extruded bars on a visible physical plane: full activation 54.1%, J-space 26.3%. A bracket spans their difference and labels the 27.8 percentage-point gap. The scene is already in its readable result state; do not require an extra reveal before advancing.

### 13 — Within language

**Headline:** Language models converge at much slower rates in the J-space.

**Caption:** None. Center the language-results chart beneath the heading.

**Speaker context (off screen):** With the neighbourhood-based alignment measure used here · slopes per unit HellaSwag accuracy

**Visual and interaction:** Show full activation +0.76 and J-space +0.23 as regression slopes per unit HellaSwag accuracy. Use a 0–0.8 chart scale. No invented scatter points.

### 14 — Across modalities

**Headline:** Across text and vision, convergence rates are similar in J-space and full space.

**Caption:** Images and words have less shared surface structure. This is consistent with the similar rates we see in J-space and full-space alignment across modalities.

**Speaker context (off screen):** A possible explanation, rather than a causal test · J-space decomposition on the text side only

**Visual and interaction:** Show full activation +0.11 and J-space +0.12 on a 0–0.2 axis with 0.05 tick intervals. This scale differs from the language chart so the two cross-modal bars are easier to compare. The source interpretation is qualified in the caption. How I built it opens the optional engineering appendix; ordinary Next returns to the opening.

### Appendix — Implementation

**Headline:** I implemented the pipeline to compare different models.

**Caption:** From extracting activations to running the comparisons and analysing the results, I implemented every stage.

The physical pipeline covers models and data, activation extraction, decomposition, alignment and analysis. Stages are inspectable. The appendix has two reveals: introduce the implementation, then trace one example. Next returns to the final text–vision result. It is reachable from How I built it on that result or from the dropdown, and is absent from the normal 14-slide cycle.

Show the verified scale: 11 text models, four vision encoders and one RTX 3080 with 10 GB memory. The reported experiments took about 40 GPU hours; this is not total project development time. The contributions drawer records Alexander's full implementation and his coauthor's minor final edits. Keep engineering prompts and any unverified personal anecdotes in private preparation notes.

## Slide 11 equation choreography

Use bundled KaTeX and accessible descriptions. Both formulas are visible on the single split view, without a caption or extra controls:

$$
J_{\ell}=\mathbb{E}_{i}\!\left[\mathbb{E}_{s'\geq s}\!\left[\frac{\partial h_{s',i}^{(\mathrm{final})}}{\partial h_{s,i}^{(\ell)}}\right]\right].
$$

$$
h=h_J+r.
$$

Explain the fitted lens verbally as an average local sensitivity. The long diagonal is the full activation; the J-space component and remainder reach the same endpoint when added tip to tail. Sparse reconstruction details and the 25-direction selection belong in speaker notes. The single children example illustrates one direction, not the complete selected set. Do not invent coefficients or restore percentage-definition, alignment-definition or Spearman equations.

## Source and interpretation boundaries

Source PDF: `/Users/alex/Downloads/neurips_2026_camera_ready.pdf`, copied to `presentation/public/paper.pdf`. Research repository: https://github.com/excelexx/jspace-convergence.

- Retention: full activation 54.1%, J-space 26.3%, Table 1. These are means of per-pair retention ratios over 1,000 documents and 55 model pairs, not results from the displayed sentence.
- Within-language slopes: +0.76 full activation and +0.23 J-space. Text–vision slopes: +0.11 and +0.12. Slopes are alignment increase per unit HellaSwag accuracy, not correlations. The language axis is 0–0.8; the text–vision axis is 0–0.2. Keep both axes clearly labelled and do not compare raw bar heights across slides.
- The text–vision setting uses 1,024 image–caption pairs and four image encoders. Only the text-side representation receives J-space decomposition.
- Alignment compares a model pair; convergence describes the association between alignment and competence across pairs. Do not describe one arrow pair as a measured convergence result.
- Similar concepts across training routes motivate the opening question. The study does not establish that data and compute are the only things that matter, that training methods are interchangeable, or that one modality provides every capability.
- Content randomisation preserves aspects of structure while disrupting content. Do not assert that it changes only meaning, that the generated text is necessarily meaningless, or that traditional alignment remains numerically unchanged.
- J-space is a sparse reconstruction using word-associated directions, not all of meaning. The remainder can still contain semantic information. More semantic selectivity refers to the tested intervention.
- The global-workspace interpretation and J-lens are prior work. Use a functional analogy rather than claims about subjective consciousness. Rain, umbrella and stay dry are illustrative words, not a measured model trace.
- Similar cross-modal slopes are consistent with less shared superficial structure between images and words. This is an interpretation, not a causal test or a direct measurement of cross-modal semantic selectivity.
- Keep Gaussian and other controls out of audience-facing copy, charts and drawers. Alexander will discuss them verbally. Private notes preserve that sparse coding accounts for much of the retention gap; do not attribute the entire gap to the dictionary.
- Preserve the initial, unsupported concentration hypothesis in speaker preparation and discussion. Do not invent experiment chronology.
- Do not infer a main-conference acceptance from the filename. Do not add a venue badge without verified status.

Remove the opening disclaimer and all small on-slide source notes. Keep source context in the paper details and private preparation notes for verbal discussion.

## Architecture and navigation

The existing stack is React, TypeScript, Vite, Motion, Three.js/React Three Fiber with selected Drei helpers, and bundled KaTeX. Keep a single persistent canvas. All local figures are deterministic and source values are separate from rendering code. No model inference or live AI API runs in the browser.

`presentation/src/state/presentation.ts` owns the slide data and reducer. Each slide declares an exhibit kind, title, caption, optional note, default visual beat and next-action labels. `narrativeScenes` excludes the appendix; `narrativeCount` is 14. Each main slide has one reveal; the main cycle therefore has 14 states. The two appendix states are extra.

The serialisable state contains `scene`, `beat`, `randomised`, `selectedItem`, `component`, `modality` and `pipeline`. `sceneIndex` resolves stable slide IDs. The randomise action changes the sentence state on the single retention slide without moving to another station. The appendix returns to vision when complete. Drawer visibility and motion preferences remain local UI state.

Relevant implementation files:

- `src/state/presentation.ts`: authoritative content and navigation.
- `src/three/sceneLayout.ts`: station locations and heading placement.
- `src/three/ResearchStage.tsx`: room, models, pulses, graphs, physical headings and camera travel.
- `src/three/RepresentationExhibits.tsx`: Cartesian idea vectors and the two-model convergence timeline.
- `src/three/GlobalWorkspaceExhibit.tsx`: accessible-concept animation and decision broadcast.
- `src/three/WordField.tsx`: drifting vocabulary and tip-to-tail reconstruction.
- `src/three/ImplicationsExhibit.tsx`: opening and cross-modal shared-concept exhibit.
- `src/three/representationDirections.ts`: deterministic schematic arrow geometry.
- `src/sceneControls.ts`: physical controls and accessible command equivalents.
- `src/App.tsx`: supporting copy, equations, navigation and drawers.
- `src/data.ts`: equations, measured values and pipeline descriptions.
- `src/styles.css`: layout, typography and responsive rules.
- `notes/speaker-notes.md`: private preparation, outside public assets and production imports.

Right/Space advances through reveals, Left reverses, Home returns to the opening, and F requests fullscreen. Preserve usable touch controls, keyboard focus, reduced motion and fallback content. Keep geometric/material reuse, modest pixel density and only necessary neighbouring exhibits mounted so the longer room does not multiply rendering cost unnecessarily.

## Verification and handoff

- Verify all 14 main slides follow the requested narrative, with the new captions and no stale ten-scene copy in public UI or documentation.
- Verify 14 main steps loop back to the opening; J-space has one reveal; appendix access and return do not insert it into the main cycle.
- Check forward and reverse transitions through the extended room. Titles, equations, controls and chart panels should travel with their station rather than float outside the environment.
- Test Original / Randomised toggling on the same slide, keeping near-identical schematic fans and accurate 54.1% retention.
- Test input pulses after toggling, workspace decision replay, neighbourhood comparison replay and convergence time scale. Verify that neighbourhood highlights wait for camera arrival and restart on re-entry. Confirm the split has no component or replay buttons.
- Confirm the vector endpoints add correctly; the remainder starts at the J-space tip and ends at the full-activation tip.
- Confirm fitted J-lens and activation identity render cleanly with bundled fonts. No unwanted math or symbol-help UI should reappear.
- Verify source values, the 27.8 percentage-point retention gap, and the separate language and text–vision chart scales; keep the text-only decomposition context in speaker notes.
- Inspect desktop and narrow layouts, especially the longer headlines and larger side copy. Check for clipping and overlapping equations.
- Run the navigation/mathematics tests and production build. Check the browser for runtime errors after navigating.
- Update the Replit ZIP with frontend and server source, `.replit`, README, Replit setup instructions, plan and private authoring notes, excluding dependencies, build output, secrets and screenshots. Check authenticated session creation, audience permissions, following, independent browsing, replay/toggle sync, reconnects and session ending. The local Node server runs the presentation and live API together.
- Rehearse aloud at screen-sharing distance. Keep supporting discussion and engineering detail available through the appendix and private notes without extending the main narrative.
