# Private preparation notes

These notes are outside the public asset directory and are not bundled into the built website. Do not import them into a public sharing UI.

## Timing and delivery

Allow roughly 8–10 minutes for the main sequence, then questions. The 14 slides below follow Alexander's revised narration, with one presenter-controlled step per slide. Adjacent slides can reuse a graphic while the heading and caption change. The presentation is paced by buttons or arrow keys. Rehearse in a full-size browser window and check the enlarged side text at screen-sharing distance. Small disclaimers are omitted from the slides; keep their context in mind when speaking.

All animations are schematic. They illustrate the argument rather than displaying measured activation trajectories, literal word locations, or a map of neurons. Numerical results remain measurements from the paper.

## 1 — How much does the way we train an AI model matter?

On-screen caption: “In recent years, the pursuit of AGI has largely followed the trend of scaling intelligence with compute, alongside breakthroughs such as attention and mixture-of-experts architectures.”

Use the models and shared constellation to introduce the motivation. If different training routes lead towards shared concepts, could scaling data and compute in one modality recover some of what models learn in another? This could inform choices about data and training. It does not follow that all training methods are interchangeable or that one modality provides every capability. The paper measures an association between competence and alignment, not a causal effect of scaling.

## 2 — Ideas are high-dimensional vectors in some representational space.

Explain a representation as an internal pattern of numbers that can encode information about an input. An arrow is a manageable picture of a vector; the real vectors have many more than three dimensions. Do not imply that every idea corresponds to one clean, isolated direction.

## 3 — Evidence suggests that representations converge as models grow smarter.

Build on the vector picture: independently trained systems can organise examples in increasingly similar ways. “Evidence suggests” keeps the claim empirical rather than presenting convergence as a universal law. Competence is measured using HellaSwag in the study being presented.

## 4 — Even vision and text models have representations that converge with competence.

Reuse the convergence graphic with an image model and a text model. Explain that each receives a different rendering of related content: an image and its caption. Similarity concerns the organisation of many examples, not equality of individual coordinates.

## 5 — This idea is known as the Platonic Representation Hypothesis.

Keep the same graphic so the name follows the intuition. It is a hypothesis about increasingly shared representations, not a claim that the models have identical capabilities or that every training route reaches an identical endpoint.

## 6 — We show that some of this apparent convergence is inflated.

This introduces the measurement question. Apparent agreement may include shared surface structure as well as meaning. Avoid implying the work disproves all representational convergence.

Privately retain the project history: Alexander originally asked whether convergence was concentrated in J-space. The results did not support that original hypothesis. The revised opening is the final narrative, not a claim that the project began with this conclusion.

## 7 — There are many ways to measure alignment, or notions of similarity.

The caption introduces the setup: give both models the same input and compare their internal patterns. Wait for the camera to arrive; the reveal then runs over about 7.5 seconds. The cat arrows point in different directions in the two coordinate systems. Then dog and kitten light up: the same examples are neighbours in both models. Highlight the matching triangular groups. The graphic applies a rigid rotation, preserving relationships while changing coordinates. Different measures answer different questions about the representations. The main presentation does not need the Spearman or alignment-definition equations.

## 8 — Traditional methods can track superficial content, like sentence structure and language.

The caption is replaced by a high traditional-alignment bar, with arrows labelling syntax, language, document length and meaning. Its segment widths are schematic, not estimated contributions. Show how these features can contribute to agreement between text models. “Can track” is deliberate: these measures can also capture semantic information. Avoid saying that every conventional metric is mostly superficial in every setting.

## 9 — Traditional alignment can stay high even when meaning is scrambled.

The slide opens in the Randomised state. Use Original, then Randomised, to demonstrate the intervention on the same slide: the sentence changes and a pulse passes to both models. The camera and heading stay in place. The intervention disrupts the original content while preserving aspects of structure. It does not guarantee the resulting text is entirely meaningless.

The two arrow fans remain very similar across the sentence states, with only subtle changes. They are schematic and do not encode numerical retention.

Compare the two bars: normal content is the 100% baseline; randomised content retains **54.1%** of full-space alignment, just beyond the halfway marker. The score changes substantially; do not say it is unchanged or that the metric detects no meaning. This is the mean of per-pair ratios across 55 pairs and 1,000 documents, not a score from the displayed sentence. Do not substitute appendix metrics that measure different things.

The statement below the chart gives the motivation: “We seek a measure that tracks meaningful alignment.” Next goes straight to the global workspace.

Move from the limitation to the method: compare a component associated with word-readable concepts. J-space is not a complete or perfect isolation of meaning, and the remainder can retain semantic information.

## 10 — A small part of the model’s activity acts like a global workspace.

The caption sits in two compact lines beneath the heading: “Most activity is in the background, but a small subset is available for report and reasoning.” The wide illustration is slightly compressed vertically to make room. Prior J-lens research argues that a subset of representations has workspace-like functions: concepts become especially available for expression and flexible reasoning.

“Unconscious” can be used as an analogy for background processing, not as a claim about whether an AI has subjective experience. The J-lens and global-workspace interpretation are prior work; this project studies alignment using the lens.

Spoken context, with no on-screen caption: “Imagine the model deciding what to take when rain is forecast. Rain, an umbrella, staying dry: the key ideas come into focus.”

On this same slide, the decision animation starts after camera arrival. Replay the decision repeats it; Next goes directly to the vector split. Watch as the surrounding words keep moving while **rain → umbrella → stay dry** emerge into the illuminated J-space and broadcast outward. “Take an umbrella” illustrates a relevant concept contributing to a decision. This is an illustrative decision, not a recorded model readout. The highlighted region is not a literal anatomical chamber in a transformer.

## 11 — We can split a representation into the J-space and remainder.

There is no on-screen caption here: just the large vector addition graphic, the fitted J-lens formula and the full-activation identity.

Explain the fitted J-lens as the average local sensitivity from an intermediate layer to the final representation, averaged over examples and relevant token positions. Then explain the full-activation identity. Sparse reconstruction details can be covered verbally.

Use 25 selected word directions to form the weighted reconstruction. The displayed **children** direction is one illustrative example, not the entire 25-direction method. The diagonal full activation is recovered by the J-space component followed tip to tail by the remainder. The single view animates this addition on entry; there are no component-selection or replay buttons.

The lens provides an incomplete view of the proposed workspace. The claimed workspace similarity is functional; it does not assert that transformers reproduce the brain's architecture.

## 12 — Comparing J-space alignment is more semantically selective than full alignment.

The enlarged chart replaces the caption: after replacing content words, J-space alignment retains 26.3% of its original value, compared with 54.1% for the full activation. Point to the bracket showing the **27.8 percentage-point gap**.

The result is more sensitivity to this intervention, not a perfect semantic test. Mention controls verbally here if useful: the Gaussian dictionary has 34.7% retention versus 26.3% for J-space and 54.1% for full-space. Under that comparison, much of the gap is associated with sparse coding; the paper reports 69.7%. Do not attribute the whole difference to the J-lens dictionary. These controls intentionally remain off screen.

## 13 — Language models converge at much slower rates in the J-space.

The centered chart has no caption. Within language, the fitted slopes are **+0.76** for full activation and **+0.23** for J-space. They are regression slopes per unit HellaSwag accuracy, not Spearman correlations or absolute alignment scores. The result does not support the original hypothesis that convergence was concentrated in J-space.

## 14 — Across text and vision, convergence rates are similar in J-space and full space.

On-screen caption: “Images and words have less shared surface structure. This is consistent with the similar rates we see in J-space and full-space alignment across modalities.”

Across modalities, the slopes are **+0.11** and **+0.12**, averaged across vision encoders as described in the paper. This chart uses a **0–0.2 axis**, compared with 0–0.8 on the language slide; compare the labelled values rather than bar heights across slides. The decomposition is applied only on the caption side; vision representations stay in full space.

The shared-structure explanation is an interpretation consistent with the findings, not a demonstrated causal mechanism. The slope comparison does not by itself test semantic selectivity under a cross-modal corruption intervention. Do not claim that the full representation and J-space contain identical meaning.

## Appendix — Implementation and interview questions

Alexander confirmed he implemented every stage; his coauthor contributed minor final edits. Use How I built it on the final result or the dropdown to open the optional engineering appendix for questions. It has two reveals outside the main cycle and returns to the final result. No unverified optimisation or debugging story has been invented. Before rehearsal, add a genuine specific bug or performance challenge from memory if useful.

Discuss the choices in the paper: a fixed comparison procedure across model pairs, prefitted J-lenses, greedy orthogonal matching pursuit, non-negative least-squares coefficient refitting, and the tradeoff introduced by sparse reconstruction. Reported runs took approximately 40 hours on one RTX 3080 with 10 GB memory; this is not total project development time.

Return to what the results changed in your understanding. Recurring concepts could make it easier to compare explanations across independently trained LLMs, but transfer of interpretability tools is a motivation rather than a demonstrated outcome here. Likewise, the image–caption results do not demonstrate an improvement to a deployed multimodal system.

## Sources and presentation boundaries

- Primary source: the supplied research paper, especially its introduction, Table 1, and within-language and text–vision regression results. Exact measured values should remain unchanged.
- Workspace interpretation: the paper's Introduction (pp. 1–2) and Gurnee et al., [Verbalizable Representations Form a Global Workspace in Language Models](https://arxiv.org/html/2607.15495v1), Sections 1.1–1.3 and 2.3.
- The Platonic Representation Hypothesis is the motivation examined by the paper, not a new hypothesis introduced by this project.
- All visual motion, word placement, arrow geometry, and the umbrella decision are schematic. State this once rather than burdening each slide with repeated warnings.
- Do not include Gaussian-control charts, percentage-definition equations, the alignment-definition equation, or the Spearman equation in the main presentation. Keep the fitted J-lens equation and reconstruction/decomposition math.
- Sharing and live audience features remain work for the Replit bot.
