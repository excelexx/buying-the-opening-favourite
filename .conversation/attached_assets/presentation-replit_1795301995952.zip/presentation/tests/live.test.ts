import test, { type TestContext } from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { RoomStore, HttpError } from '../server/rooms.ts';
import { createPresentationServer } from '../server/http.ts';
import { DECK_VERSION, initialDeck, validCommand, validDeck, type RoomSnapshot } from '../src/live/protocol.ts';
import { sceneIndex } from '../src/state/presentation.ts';

test('room commands are isolated, authenticated and safe to retry after a lost response', () => {
  const rooms = new RoomStore();
  const a = rooms.create(initialDeck), b = rooms.create(initialDeck);
  const id = a.snapshot.id, commandId = randomUUID();
  assert.throws(() => rooms.command(id, b.token, commandId, {type:'next'}), (e:unknown) => e instanceof HttpError && e.status === 403);
  const first = rooms.command(id, a.token, commandId, {type:'next'});
  const retry = rooms.command(id, a.token, commandId, {type:'next'});
  assert.equal(first.state.scene, 1);
  assert.deepEqual(first, retry);
  assert.equal(rooms.snapshot(b.snapshot.id).state.scene, 0);
  assert.equal(first.revision, 1);
  assert.ok(!JSON.stringify(first).includes(a.token));
  assert.ok(!('tokenHash' in first));
  rooms.close();
});

test('late joiners receive interactions, timeline scrubbing and replay state', () => {
  const rooms = new RoomStore();
  const {token, snapshot:{id}} = rooms.create(initialDeck);
  const command = (value:Parameters<RoomStore['command']>[3]) => rooms.command(id,token,randomUUID(),value);
  command({type:'jump',scene:sceneIndex('retention')});
  command({type:'randomise',value:false});
  let latest:RoomSnapshot|undefined;
  const unsubscribe = rooms.subscribe(id,randomUUID(),{audience:true,send:value=>{latest=value;},close:()=>{}});
  assert.equal(latest?.state.scene,sceneIndex('retention'));
  assert.equal(latest?.state.randomised,false);
  assert.equal(latest?.replay,1);
  command({type:'jump',scene:sceneIndex('convergence')});
  command({type:'scrub',progress:.62});
  assert.equal(latest?.state.convergenceProgress,.62);
  command({type:'replay'});
  assert.equal(latest?.state.convergenceProgress,null);
  assert.equal(latest?.replay,2);
  assert.equal(latest?.viewers,1);
  unsubscribe();
  assert.equal(rooms.snapshot(id).viewers,0);
  rooms.close();
});

test('presence recovers, presenter streams are not viewers, and ended sessions close streams', () => {
  let now=1000, closed=0;
  const rooms = new RoomStore({now:()=>now,hostTimeout:25_000,ttl:60_000});
  const {token,snapshot:{id}}=rooms.create(initialDeck);
  let latest:RoomSnapshot|undefined;
  rooms.subscribe(id,randomUUID(),{audience:false,send:()=>{},close:()=>{closed++;}});
  rooms.subscribe(id,randomUUID(),{audience:true,send:s=>{latest=s;},close:()=>{closed++;}});
  assert.equal(latest?.viewers,1);
  now+=26_000;rooms.sweep();
  assert.equal(latest?.presenterOnline,false);
  rooms.heartbeat(id,token);
  assert.equal(latest?.presenterOnline,true);
  rooms.end(id,token);
  assert.equal(latest?.ended,true);
  assert.equal(latest?.presenterOnline,false);
  assert.equal(closed,2);
  assert.throws(()=>rooms.command(id,token,randomUUID(),{type:'next'}),(e:unknown)=>e instanceof HttpError&&e.status===410);
  rooms.sweep();
  assert.throws(()=>rooms.snapshot(id),(e:unknown)=>e instanceof HttpError&&e.status===404);
});

test('room capacity is bounded and expired rooms release their slots', () => {
  let now=0, closed=false;
  const rooms=new RoomStore({now:()=>now,ttl:100,maxRooms:1});
  const {snapshot:{id}}=rooms.create(initialDeck);
  rooms.subscribe(id,randomUUID(),{audience:true,send:()=>{},close:()=>{closed=true;}});
  assert.throws(()=>rooms.create(initialDeck),(e:unknown)=>e instanceof HttpError&&e.status===503);
  now=101;
  rooms.create(initialDeck);
  assert.ok(closed);
  assert.throws(()=>rooms.snapshot(id),(e:unknown)=>e instanceof HttpError&&e.status===404);
  rooms.close();
});

test('network validation rejects malformed commands and impossible deck states', () => {
  assert.ok(validDeck(initialDeck));
  for(const command of [null,{}, {type:'jump',scene:999},{type:'jump',scene:0,beat:1},{type:'scrub',progress:NaN},{type:'scrub',progress:1.1},{type:'pipeline',value:-1},{type:'component',value:'secret'},{type:'randomise',value:'yes'}])assert.equal(validCommand(command),false);
  for(const state of [{...initialDeck.state,scene:-1},{...initialDeck.state,modality:'vision'},{...initialDeck.state,randomised:true},{...initialDeck.state,convergenceProgress:Infinity}])assert.equal(validDeck({...initialDeck,state}),false);
});

async function fixture(t:TestContext) {
  const dir=await mkdtemp(join(tmpdir(),'presentation-live-'));
  await writeFile(join(dir,'index.html'),'<h1>Presentation fixture</h1>');
  await mkdir(join(dir,'assets'));
  await writeFile(join(dir,'assets','test.js'),'export const ready = true;');
  const app=createPresentationServer({presenterKey:'test-only-presenter-key',distDir:dir});
  app.server.listen(0,'127.0.0.1');await once(app.server,'listening');
  const address=app.server.address();assert.ok(address&&typeof address==='object');
  const origin=`http://127.0.0.1:${address.port}`;
  const controllers:AbortController[]=[];
  t.after(async()=>{controllers.forEach(c=>c.abort());app.dispose();await rm(dir,{recursive:true,force:true});});
  const json=async(path:string,method='GET',data?:unknown,token?:string)=>{
    const response=await fetch(origin+path,{method,headers:{...(data===undefined?{}:{'Content-Type':'application/json'}),...(token?{Authorization:`Bearer ${token}`}:{})},body:data===undefined?undefined:JSON.stringify(data)});
    return {status:response.status,data:await response.json()};
  };
  const create=async()=>{const response=await json('/api/rooms','POST',{deck:initialDeck,deckVersion:DECK_VERSION},'test-only-presenter-key');assert.equal(response.status,201);return response.data as {token:string;snapshot:RoomSnapshot};};
  const stream=async(id:string)=>{
    const controller=new AbortController();controllers.push(controller);
    const response=await fetch(`${origin}/api/rooms/${id}/events?client=${randomUUID()}`,{signal:controller.signal});
    assert.equal(response.status,200);assert.match(response.headers.get('content-type')??'',/text\/event-stream/);
    const reader=response.body!.getReader(),decoder=new TextDecoder();let buffer='';
    const next=async():Promise<RoomSnapshot>=>{
      for(;;){
        const boundary=buffer.indexOf('\n\n');
        if(boundary>=0){const frame=buffer.slice(0,boundary);buffer=buffer.slice(boundary+2);const data=frame.split('\n').find(line=>line.startsWith('data: '));if(data)return JSON.parse(data.slice(6));continue;}
        const {done,value}=await reader.read();if(done)throw new Error('Stream ended without a snapshot');buffer+=decoder.decode(value,{stream:true});
      }
    };
    return {next,close:()=>controller.abort()};
  };
  return {origin,json,create,stream};
}

test('HTTP gates session creation and mutations while audience links reveal only public state', async t => {
  const f=await fixture(t);
  assert.equal((await f.json('/api/health')).data.ok,true);
  assert.equal((await f.json('/api/config')).data.requiresKey,true);
  const payload={deck:initialDeck,deckVersion:DECK_VERSION};
  assert.equal((await f.json('/api/rooms','POST',payload)).status,403);
  assert.equal((await f.json('/api/rooms','POST',payload,'wrong')).status,403);
  const {snapshot:{id},token}=await f.create();
  const publicRoom=await f.json(`/api/rooms/${id}`);
  assert.equal(publicRoom.status,200);
  assert.ok(!JSON.stringify(publicRoom).includes(token));
  const command={commandId:randomUUID(),deckVersion:DECK_VERSION,command:{type:'next'}};
  for(const route of ['commands','heartbeat'])assert.equal((await f.json(`/api/rooms/${id}/${route}`,'POST',command)).status,403);
  assert.equal((await f.json(`/api/rooms/${id}`,'DELETE')).status,403);
  assert.equal((await f.json(`/api/rooms/${id}/commands`,'POST',command,token)).data.state.scene,1);
  assert.equal((await f.json(`/api/rooms/${id}/commands`,'POST',command,token)).data.state.scene,1);
  assert.equal((await f.json(`/api/rooms/${id}/heartbeat`,'POST',undefined,token)).status,200);
});

test('SSE carries updates, reconnects at the current state, and announces session end', {timeout:10_000}, async t => {
  const f=await fixture(t),{snapshot:{id},token}=await f.create();
  const send=(command:unknown)=>f.json(`/api/rooms/${id}/commands`,'POST',{commandId:randomUUID(),deckVersion:DECK_VERSION,command},token);
  await send({type:'jump',scene:sceneIndex('retention')});
  const audience=await f.stream(id);
  const initial=await audience.next();
  assert.equal(initial.state.scene,sceneIndex('retention'));assert.equal(initial.viewers,1);
  await send({type:'randomise',value:false});
  assert.equal((await audience.next()).state.randomised,false);
  audience.close();
  await send({type:'jump',scene:sceneIndex('convergence')});
  await send({type:'scrub',progress:.42});
  const reconnected=await f.stream(id);
  assert.equal((await reconnected.next()).state.convergenceProgress,.42);
  await f.json(`/api/rooms/${id}`,'DELETE',undefined,token);
  let ended=await reconnected.next();while(!ended.ended)ended=await reconnected.next();
  assert.equal(ended.presenterOnline,false);
});

test('HTTP rejects invalid requests and serves only the built public directory', async t => {
  const f=await fixture(t),{snapshot:{id},token}=await f.create();
  const path=`/api/rooms/${id}/commands`;
  assert.equal((await f.json(path,'POST',{commandId:randomUUID(),deckVersion:'old',command:{type:'next'}},token)).status,409);
  assert.equal((await f.json(path,'POST',{commandId:randomUUID(),deckVersion:DECK_VERSION,command:{type:'jump',scene:999}},token)).status,400);
  assert.equal((await f.json(path,'POST',{padding:'x'.repeat(9000)},token)).status,413);
  assert.equal((await f.json(path,'POST',null,token)).status,400);
  assert.equal((await fetch(f.origin+path,{method:'POST',headers:{Authorization:`Bearer ${token}`},body:'not json'})).status,415);
  assert.equal((await fetch(f.origin+'/api/rooms',{method:'POST',headers:{Origin:'https://unrelated.example'}})).status,403);
  assert.equal((await fetch(f.origin+'/')).status,200);
  const asset=await fetch(f.origin+'/assets/test.js');assert.equal(asset.status,200);assert.match(asset.headers.get('cache-control')??'',/immutable/);
  for(const path of ['/package.json','/.env','/server/index.ts','/notes/speaker-notes.md','/%2e%2e%2fpackage.json'])assert.equal((await fetch(f.origin+path)).status,404);
});
