import test from 'node:test';
import assert from 'node:assert/strict';
import katex from 'katex';
import { reducer, initialState, scenes, narrativeScenes, narrativeCount, sceneIndex, type Action, type PresentationState } from '../src/state/presentation.ts';
import { formulas } from '../src/data.ts';
import { headingForState } from '../src/three/sceneLayout.ts';
import { schematicDirection, representationCount } from '../src/three/representationDirections.ts';
import { activationTriangle, vectorBetween } from '../src/three/activationGeometry.ts';
import { sceneControls } from '../src/sceneControls.ts';
import { neighbourhoodDirection, neighbourhoodItems } from '../src/three/neighbourhoodGeometry.ts';

const expectedNarrative = [
  'implications', 'vectors', 'convergence', 'crossmodal', 'platonic', 'inflation',
  'alignment', 'surface', 'retention',
  'workspace', 'jspace', 'content', 'language', 'vision',
];
const currentId = (state: PresentationState) => scenes[state.scene].id;

function controlAction(state: PresentationState, label: string): Action {
  const control = sceneControls(state).find(item => item.label === label);
  assert.ok(control, `Missing control: ${label}`);
  assert.ok(control.command.type !== 'replay' && control.command.type !== 'details', `${label} must navigate or update presentation state`);
  return control.command;
}

test('the 14-slide narrative reaches every reveal in order and loops without entering the appendix', () => {
  assert.deepEqual(narrativeScenes.map(scene => scene.id), expectedNarrative);
  assert.equal(narrativeCount, 14);
  let state = initialState;
  const visited: string[] = [];
  for (const scene of narrativeScenes) {
    for (let beat = 0; beat < scene.count; beat++) {
      assert.equal(currentId(state), scene.id);
      assert.equal(state.beat, beat);
      assert.equal(scenes[state.scene].appendix, false);
      visited.push(`${state.scene}:${state.beat}`);
      state = reducer(state, { type: 'next' });
    }
  }
  assert.equal(new Set(visited).size, 14);
  assert.deepEqual(state, initialState);
});

test('back reverses the full narrative and restores the experiment and modality state', () => {
  let state = reducer(initialState, { type: 'jump', scene: sceneIndex('vision') });
  for (const scene of [...narrativeScenes].reverse()) {
    for (let beat = scene.count - 1; beat >= 0; beat--) {
      assert.equal(currentId(state), scene.id);
      assert.equal(state.beat, beat);
      assert.equal(state.randomised, scene.id === 'retention');
      assert.equal(state.modality, scene.id === 'vision' ? 'vision' : 'text');
      state = reducer(state, { type: 'back' });
    }
  }
  assert.deepEqual(state, initialState);
  assert.deepEqual(reducer(initialState, { type: 'back' }), initialState);
});

test('scene jumps clamp invalid scenes and reveal indices', () => {
  assert.equal(reducer(initialState, { type: 'jump', scene: 100 }).scene, scenes.length - 1);
  assert.deepEqual(reducer(initialState, { type: 'jump', scene: -3 }), initialState);
  const state = reducer(initialState, { type: 'jump', scene: sceneIndex('jspace'), beat: 1 });
  assert.equal(state.beat, 0);
  assert.equal(currentId(state), 'jspace');
  assert.equal(reducer(state, { type: 'jump', scene: state.scene, beat: 100 }).beat, 0);
  assert.equal(reducer(state, { type: 'jump', scene: state.scene, beat: -5 }).beat, 0);
});

test('the neighbourhood illustration preserves neighbours while its raw directions differ', () => {
  const cosine = (a: number[], b: number[]) => a.reduce((sum, value, i) => sum + value * b[i], 0) / Math.hypot(...a) / Math.hypot(...b);
  const neighbours = (side: number) => neighbourhoodItems.map((_, i) => i).slice(1)
    .sort((a, b) => cosine(neighbourhoodDirection(0, side), neighbourhoodDirection(b, side)) - cosine(neighbourhoodDirection(0, side), neighbourhoodDirection(a, side))).slice(0, 2);
  assert.deepEqual(neighbours(0), [1, 2]);
  assert.deepEqual(neighbours(1), neighbours(0));
  assert.ok(cosine(neighbourhoodDirection(0, 0), neighbourhoodDirection(0, 1)) < .25);
  for (let i = 0; i < neighbourhoodItems.length; i++) {
    for (let j = i + 1; j < neighbourhoodItems.length; j++) {
      assert.ok(Math.abs(cosine(neighbourhoodDirection(i, 0), neighbourhoodDirection(j, 0)) - cosine(neighbourhoodDirection(i, 1), neighbourhoodDirection(j, 1))) < 1e-12);
    }
  }
});

test('Original and Randomised controls stay on one combined slide, which advances directly to the workspace', () => {
  let state = reducer(initialState, { type: 'jump', scene: sceneIndex('retention') });
  const originalTitle = headingForState(state).join(' '), originalScene = state.scene;
  assert.equal(state.randomised, true);
  state = reducer(state, controlAction(state, 'Original'));
  assert.equal(state.randomised, false);
  assert.equal(sceneControls(state).find(control => control.label === 'Original')?.active, true);
  state = reducer(state, controlAction(state, 'Randomised'));
  assert.equal(currentId(state), 'retention');
  assert.equal(state.randomised, true);
  assert.equal(sceneControls(state).find(control => control.label === 'Randomised')?.active, true);
  assert.equal(state.scene, originalScene);
  assert.equal(headingForState(state).join(' '), originalTitle);
  state = reducer(state, controlAction(state, 'Original'));
  assert.equal(currentId(state), 'retention');
  assert.equal(state.randomised, false);
  assert.equal(headingForState(state).join(' '), originalTitle);
  state = reducer(state, { type: 'next' });
  assert.equal(currentId(state), 'workspace');
  assert.equal(state.randomised, false);
  state = reducer(state, { type: 'back' });
  assert.equal(currentId(state), 'retention');
  assert.equal(state.randomised, true);
  assert.deepEqual(reducer(initialState, { type: 'randomise', value: true }), initialState);
});

test('the combined workspace has a replay and advances directly to one clean J-space split', () => {
  let state = reducer(initialState, { type: 'jump', scene: sceneIndex('workspace') });
  assert.deepEqual(sceneControls(state).find(control => control.label === 'Replay the decision')?.command, { type: 'replay' });
  state = reducer(state, { type: 'next' });
  assert.equal(currentId(state), 'jspace');
  assert.equal(state.beat, 0);
  assert.equal(sceneControls(state).length, 0);
  state = reducer(state, { type: 'next' });
  assert.equal(currentId(state), 'content');
  const previous = reducer(state, { type: 'back' });
  assert.equal(currentId(previous), 'jspace');
  assert.equal(previous.beat, 0);
});

test('the implementation appendix opens explicitly from vision and returns to the results', () => {
  let state = reducer(initialState, { type: 'jump', scene: sceneIndex('vision') });
  assert.deepEqual(reducer(state, { type: 'next' }), initialState);
  state = reducer(state, controlAction(state, 'How I built it'));
  assert.equal(currentId(state), 'engineering');
  assert.equal(scenes[state.scene].appendix, true);
  assert.equal(currentId(reducer(state, { type: 'back' })), 'vision');
  state = reducer(state, { type: 'next' });
  assert.equal(currentId(state), 'engineering');
  assert.equal(state.beat, 1);
  state = reducer(state, { type: 'next' });
  assert.equal(currentId(state), 'vision');
  assert.equal(state.modality, 'vision');
  assert.equal(state.beat, 0);
});

test('all presentation equations render to HTML and accessible MathML', () => {
  for (const tex of Object.values(formulas)) {
    const html = katex.renderToString(tex, { throwOnError: true, output: 'htmlAndMathml' });
    assert.ok(html.includes('katex-mathml'));
    assert.ok(!html.includes('katex-error'));
  }
});

test('the illustrated tip-to-tail components reach the full activation endpoint', () => {
  const { origin, jTip, fullTip } = activationTriangle;
  const full = vectorBetween(origin, fullTip), j = vectorBetween(origin, jTip), remainder = vectorBetween(jTip, fullTip);
  full.forEach((value, i) => assert.ok(Math.abs(value - j[i] - remainder[i]) < 1e-12));
  assert.ok(full[0] > 0 && full[1] > 0, 'the full activation is diagonal');
  assert.ok(j.reduce((dot, v, i) => dot + v * remainder[i], 0) !== 0, 'the schematic does not imply an orthogonal projection');
});

test('the randomized illustration preserves nearly the same arrow directions', () => {
  const cosine = (a: number[], b: number[]) => a.reduce((sum, v, i) => sum + v * b[i], 0) / Math.hypot(...a) / Math.hypot(...b);
  for (let i = 0; i < representationCount; i++) {
    for (const side of [0, 1]) assert.ok(cosine(schematicDirection(i, side, false), schematicDirection(i, side, true)) > .99);
    assert.ok(cosine(schematicDirection(i, 0, true), schematicDirection(i, 1, true)) > .98);
  }
});
