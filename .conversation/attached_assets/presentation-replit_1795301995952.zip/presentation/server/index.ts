import { createPresentationServer } from './http.js';

const dev=process.argv.includes('--dev');
if(!dev&&!process.env.PRESENTER_KEY)throw new Error('Set PRESENTER_KEY before starting the production server.');
const port=Number(process.env.PORT??(dev?5173:3000));
const app=createPresentationServer({presenterKey:process.env.PRESENTER_KEY,allowLocalCreate:dev,publicOrigin:process.env.PUBLIC_ORIGIN});
let closeFrontend:(()=>Promise<void>)|undefined;
if(dev){
  const {createServer}=await import('vite');
  const vite=await createServer({server:{middlewareMode:true,hmr:{server:app.server}},appType:'spa'});
  app.setFrontend((req,res)=>vite.middlewares(req,res));closeFrontend=()=>vite.close();
}
app.server.listen(port,'0.0.0.0',()=>console.log(`Presentation server ready on port ${port} (${dev?'development':'production'})`));
for(const signal of ['SIGINT','SIGTERM'] as const)process.once(signal,()=>{app.dispose();void closeFrontend?.().finally(()=>process.exit(0));setTimeout(()=>process.exit(0),1500).unref();});
