import { randomBytes, createHash, timingSafeEqual } from 'node:crypto';
import { applyCommand, DECK_VERSION, type DeckState, type LiveCommand, type RoomSnapshot } from '../src/live/protocol.js';

export class HttpError extends Error {constructor(public status:number,message:string){super(message);}}
const digest=(token:string)=>createHash('sha256').update(token).digest();
type Subscriber={audience:boolean;send:(snapshot:RoomSnapshot)=>void;close:()=>void};
type Room={id:string;tokenHash:Buffer;deck:DeckState;revision:number;expiresAt:number;lastHost:number;ended:boolean;subscribers:Map<string,Subscriber>;commands:Set<string>;online:boolean};

/** Deliberately a single-process room store. Replit should run one Reserved VM. */
export class RoomStore {
  private rooms=new Map<string,Room>();
  constructor(private options:{now?:()=>number;ttl?:number;maxRooms?:number;hostTimeout?:number}={}){}
  private now(){return this.options.now?.()??Date.now();}
  private online(room:Room){return !room.ended&&this.now()-room.lastHost<(this.options.hostTimeout??25_000);}
  private get(id:string){const room=this.rooms.get(id);if(!room)throw new HttpError(404,'This session is no longer available.');if(room.expiresAt<=this.now()&&!room.ended)this.finish(room);return room;}
  snapshot(id:string):RoomSnapshot {
    const room=this.get(id);
    return {...room.deck,id,revision:room.revision,deckVersion:DECK_VERSION,viewers:[...room.subscribers.values()].filter(s=>s.audience).length,presenterOnline:this.online(room),ended:room.ended,expiresAt:room.expiresAt};
  }
  create(deck:DeckState){
    this.sweep();
    if(this.rooms.size>=(this.options.maxRooms??32))throw new HttpError(503,'All live-session slots are in use. Try again later.');
    let id:string;do{id=randomBytes(6).toString('hex').toUpperCase();}while(this.rooms.has(id));
    const token=randomBytes(32).toString('base64url');
    this.rooms.set(id,{id,tokenHash:digest(token),deck:structuredClone(deck),revision:0,expiresAt:this.now()+(this.options.ttl??8*60*60*1000),lastHost:this.now(),online:true,ended:false,subscribers:new Map(),commands:new Set()});
    return {token,snapshot:this.snapshot(id)};
  }
  authorize(id:string,token:string){
    const room=this.get(id);
    if(!token||!timingSafeEqual(room.tokenHash,digest(token)))throw new HttpError(403,'Presenter access is required.');
    if(room.ended)throw new HttpError(410,'This session has ended.');
    return room;
  }
  heartbeat(id:string,token:string){const room=this.authorize(id,token),wasOnline=this.online(room);room.lastHost=this.now();if(!wasOnline){room.online=true;this.broadcast(room);}return this.snapshot(id);}
  command(id:string,token:string,commandId:string,command:LiveCommand){
    const room=this.authorize(id,token);room.lastHost=this.now();
    if(!room.commands.has(commandId)){
      room.deck=applyCommand(room.deck,command);room.revision++;room.commands.add(commandId);
      if(room.commands.size>1024)room.commands.delete(room.commands.values().next().value!);
      this.broadcast(room);
    }
    return this.snapshot(id);
  }
  subscribe(id:string,clientId:string,subscriber:Subscriber){
    const room=this.get(id);if(room.ended)throw new HttpError(410,'This session has ended.');
    if(room.subscribers.size>=100&&!room.subscribers.has(clientId))throw new HttpError(503,'This session is full.');
    room.subscribers.get(clientId)?.close();room.subscribers.set(clientId,subscriber);this.broadcast(room);
    return ()=>{if(room.subscribers.get(clientId)===subscriber){room.subscribers.delete(clientId);if(!room.ended)this.broadcast(room);}};
  }
  end(id:string,token:string){const room=this.authorize(id,token);this.finish(room);return this.snapshot(id);}
  private finish(room:Room){room.ended=true;room.revision++;this.broadcast(room);for(const s of room.subscribers.values())s.close();room.subscribers.clear();}
  private broadcast(room:Room){const value=this.snapshot(room.id);for(const s of room.subscribers.values())s.send(value);}
  sweep(){
    for(const room of this.rooms.values()){
      if(room.expiresAt<=this.now()&&!room.ended)this.finish(room);
      if(room.ended&&room.subscribers.size===0){this.rooms.delete(room.id);continue;}
      const online=this.online(room);if(online!==room.online){room.online=online;this.broadcast(room);}
    }
  }
  close(){for(const room of this.rooms.values())for(const s of room.subscribers.values())s.close();this.rooms.clear();}
}
