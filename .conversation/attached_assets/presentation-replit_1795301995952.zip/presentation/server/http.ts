import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { createHash, timingSafeEqual } from 'node:crypto';
import { resolve, sep, extname } from 'node:path';
import { DECK_VERSION, validCommand, validDeck } from '../src/live/protocol.js';
import { HttpError, RoomStore } from './rooms.js';

type Options={presenterKey?:string;allowLocalCreate?:boolean;publicOrigin?:string;distDir?:string;store?:RoomStore};
type Frontend=(req:IncomingMessage,res:ServerResponse)=>void;
const hash=(v:string)=>createHash('sha256').update(v).digest();
const bearer=(req:IncomingMessage)=>req.headers.authorization?.startsWith('Bearer ')?req.headers.authorization.slice(7):'';
const json=(res:ServerResponse,status:number,data:unknown)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
const mime:Record<string,string>={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.pdf':'application/pdf','.ico':'image/x-icon'};
async function body(req:IncomingMessage){
  if(!req.headers['content-type']?.startsWith('application/json'))throw new HttpError(415,'Send JSON.');
  let size=0;const chunks:Buffer[]=[];
  for await(const chunk of req.iterator({destroyOnReturn:false})){size+=chunk.length;if(size>8192){req.resume();throw new HttpError(413,'Request too large.');}chunks.push(chunk);}
  try{const value=JSON.parse(Buffer.concat(chunks).toString());if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();return value as Record<string,unknown>;}catch{throw new HttpError(400,'Invalid JSON.');}
}
export function createPresentationServer(options:Options={}){
  const store=options.store??new RoomStore(),limits=new Map<string,{start:number;count:number}>();let frontend:Frontend|undefined;
  const local=(req:IncomingMessage)=>!!options.allowLocalCreate&&['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress??'')&&/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(req.headers.host??'');
  const limit=(key:string,max:number)=>{const now=Date.now(),entry=limits.get(key);if(!entry||now-entry.start>60_000){limits.set(key,{start:now,count:1});return;}if(++entry.count>max)throw new HttpError(429,'Too many requests. Try again in a minute.');};
  const server=createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','SAMEORIGIN');
    try{
      const url=new URL(req.url??'/','http://localhost');
      if(!url.pathname.startsWith('/api/')){
        if(frontend){frontend(req,res);return;}
        if(req.method!=='GET'&&req.method!=='HEAD')throw new HttpError(405,'Method not allowed.');
        const root=resolve(options.distDir??'dist'),pathname=decodeURIComponent(url.pathname),path=resolve(root,pathname==='/'?'index.html':'.'+pathname);
        if(!path.startsWith(root+sep)||pathname.includes('\0')||pathname.split('/').some(p=>p.startsWith('.')))throw new HttpError(404,'Not found.');
        const info=await stat(path).catch(()=>null);if(!info?.isFile())throw new HttpError(404,'Not found.');
        res.writeHead(200,{'Content-Type':mime[extname(path)]??'application/octet-stream','Content-Length':info.size,'Cache-Control':url.pathname.startsWith('/assets/')?'public, max-age=31536000, immutable':'no-cache'});
        if(req.method==='HEAD')res.end();else createReadStream(path).on('error',()=>res.destroy()).pipe(res);return;
      }
      const origin=req.headers.origin;
      if(origin&&new URL(origin).host!==(options.publicOrigin?new URL(options.publicOrigin).host:req.headers.host))throw new HttpError(403,'Use this app’s own origin.');
      if(url.pathname==='/api/health'&&req.method==='GET'){json(res,200,{ok:true,deckVersion:DECK_VERSION});return;}
      if(url.pathname==='/api/config'&&req.method==='GET'){json(res,200,{requiresKey:!!options.presenterKey,hostingEnabled:!!options.presenterKey||local(req),deckVersion:DECK_VERSION});return;}
      if(url.pathname==='/api/rooms'&&req.method==='POST'){
        // One bounded global creation bucket also covers reverse proxies without trusting forwarded IPs.
        limit('create',30);
        if(options.presenterKey){if(!timingSafeEqual(hash(bearer(req)),hash(options.presenterKey)))throw new HttpError(403,'The presenter key is incorrect.');}
        else if(!local(req))throw new HttpError(503,'Set PRESENTER_KEY on the server to enable hosting.');
        const value=await body(req);if(value.deckVersion!==DECK_VERSION)throw new HttpError(409,'Reload the presentation before starting a session.');
        if(!validDeck(value.deck))throw new HttpError(400,'Invalid presentation state.');
        json(res,201,store.create(value.deck));return;
      }
      const match=url.pathname.match(/^\/api\/rooms\/([A-F0-9]{12})(?:\/(events|commands|heartbeat))?$/);
      if(!match)throw new HttpError(404,'Not found.');
      const [,id,route]=match;
      if(!route&&req.method==='GET'){json(res,200,store.snapshot(id));return;}
      if(route==='events'&&req.method==='GET'){
        const client=url.searchParams.get('client')??'';if(!/^[a-zA-Z0-9-]{16,64}$/.test(client))throw new HttpError(400,'Invalid connection.');
        const initial=store.snapshot(id);if(initial.ended)throw new HttpError(410,'This session has ended.');
        const audience=url.searchParams.get('role')!=='presenter';
        let cleanup=()=>{};let closed=false;
        const close=()=>{if(closed)return;closed=true;clearInterval(timer);res.end();cleanup();};
        const send=(snapshot:unknown)=>{if(!res.headersSent){res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});res.write('retry: 2000\n\n');}if(!res.write(`event: snapshot\ndata: ${JSON.stringify(snapshot)}\n\n`))close();};
        const timer=setInterval(()=>{if(!res.write(': heartbeat\n\n'))close();},10_000);timer.unref();
        res.on('close',()=>{if(!closed){closed=true;clearInterval(timer);cleanup();}});
        try{cleanup=store.subscribe(id,client,{audience,send,close});}catch(error){clearInterval(timer);throw error;}
        if(closed)cleanup();return;
      }
      if(route==='heartbeat'&&req.method==='POST'){store.authorize(id,bearer(req));limit(`${id}:heartbeat`,120);json(res,200,store.heartbeat(id,bearer(req)));return;}
      if(route==='commands'&&req.method==='POST'){
        store.authorize(id,bearer(req));limit(`${id}:commands`,600);
        const value=await body(req);if(value.deckVersion!==DECK_VERSION)throw new HttpError(409,'Reload both presentation tabs to use the same version.');
        if(typeof value.commandId!=='string'||!/^[a-zA-Z0-9-]{16,64}$/.test(value.commandId)||!validCommand(value.command))throw new HttpError(400,'Invalid presentation command.');
        json(res,200,store.command(id,bearer(req),value.commandId,value.command));return;
      }
      if(!route&&req.method==='DELETE'){json(res,200,store.end(id,bearer(req)));return;}
      throw new HttpError(405,'Method not allowed.');
    }catch(error){if(res.headersSent){res.end();return;}json(res,error instanceof HttpError?error.status:400,{error:error instanceof HttpError?error.message:'The request could not be processed.'});}
  });
  const sweep=setInterval(()=>{store.sweep();for(const [key,value]of limits)if(Date.now()-value.start>60_000)limits.delete(key);},5000);sweep.unref();
  server.on('close',()=>{clearInterval(sweep);store.close();});
  return {server,store,setFrontend:(handler:Frontend)=>{frontend=handler;},dispose:()=>{clearInterval(sweep);store.close();server.closeAllConnections();server.close();}};
}
