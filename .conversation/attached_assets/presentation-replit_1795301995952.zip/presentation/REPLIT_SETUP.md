# Replit handoff

The presentation and live-follow server are implemented and tested locally. Replit needs to install, configure and publish this project. There is no public interview link until that deployment is live.

## Prompt to give the Replit agent

> Set up and publish this existing presentation app. Preserve its slides and 3D visuals. The app already includes a Node HTTP server, authenticated presenter sessions, audience links and live following; do not replace these with a separate service. Read README.md and REPLIT_SETUP.md first. Put the contents of the uploaded presentation folder at the project root so package.json and .replit are at the root. Use Node 22.12+ and npm ci. Run npm test and npm run build. Production must run npm start, which serves dist/ and the API together on 0.0.0.0 and process.env.PORT. Configure one Reserved VM instance, not Static publishing or multiple Autoscale instances, because live rooms are in process memory. Have me set a strong private PRESENTER_KEY through Replit Secrets, make it available to the published app, and never place it in frontend code or a VITE_ variable. Keep one port mapped to the app. Verify /api/health, then test the published URL using separate presenter and audience tabs: start a session, join at the current slide, advance, switch Original/Randomised, explore and rejoin, refresh, and end the session. Return the public app URL and show me how to copy an audience link from Present live.

## Configuration

| Setting | Value |
| --- | --- |
| Runtime | Node.js 22.12+ |
| Install | `npm ci` |
| Development | `npm run dev` |
| Build | `npm run build` |
| Production | `npm start` |
| Binding | `0.0.0.0`, `PORT` environment variable (3000 by default) |
| Health check | `GET /api/health` |
| Deployment | One Reserved VM process |
| Required secret | `PRESENTER_KEY` — a strong random passphrase known only to the presenter |
| Optional setting | `PUBLIC_ORIGIN` — exact published origin, e.g. `https://your-app.replit.app`, if the reverse proxy changes the Host header |

`.replit` already defines the build/run commands and the 3000-to-80 port mapping. Replit provides HTTPS externally. The server handles the frontend and API on the same origin. Replit's documentation covers [deployment types](https://docs.replit.com/features/publishing/deployment-types), [project configuration](https://docs.replit.com/features/project-setup/configuration), and [ports](https://docs.replit.com/features/project-setup/ports).

Set `PRESENTER_KEY` in the published app's environment, and in workspace Secrets if live sessions are needed in the Replit preview. Production startup intentionally fails without it. `.env.example` documents the names but is not automatically loaded; never upload a real `.env` or hard-code the key. `PUBLIC_ORIGIN` can normally be left unset. If set, use the origin of that environment; a production origin does not match a separate development preview.

Only `dist/` is served by the production server. Server code, private speaker notes, configuration and credentials are not static routes. The paper at `public/paper.pdf` is intentionally part of the published presentation.

## Before the interview

1. Open the **published app URL**, not a development preview or localhost.
2. Go to the starting slide and click **Present live**.
3. Enter the presenter key and click **Start live session**.
4. Click **Copy audience link**. Send that link to the interviewers; it looks like `https://your-app.replit.app/?join=…`.
5. Keep this original presenter tab open. A viewer count confirms who has connected (counts connected tabs, not unique people).
6. Test the link in a second browser or private window. Its slide controls should be disabled while following you.
7. Present normally. Use **Live session → End session** when finished.

The link is viewable by anyone who has it, without an account. It cannot issue presenter commands. The `?present=` URL requires the separate credential stored in the originating tab's session storage; copying that URL to another browser does not transfer control. Refreshing the original tab restores it. If that tab is lost, start a new session and share its new audience link.

## What follows the presenter

- Slide navigation, reveal steps and appendix navigation.
- Original/Randomised sentence changes and selection state.
- Replay actions and manual convergence timeline position.
- Pipeline stages and representation components.

Each viewer renders the same 3D scene on their own device. Ambient motion, automatic animation timing, pointer parallax, fullscreen, reduced-motion preferences and the paper drawer stay local. This is presentation-state following rather than video streaming. An audience member can choose **Explore on my own**, then **Follow presenter** to jump to the latest shared state.

## Server behavior

One Node process holds up to 32 rooms, with up to 100 simultaneous event-stream connections per room, including the presenter. These are safety limits, not a load-tested capacity guarantee. Rooms expire after eight hours. A server restart or redeploy clears them, so finish deployment before creating the interview session.

The browser receives snapshots through Server-Sent Events and reconnects automatically. Presenter changes use authenticated POST requests with unique command IDs, so a retry after a lost response does not advance twice. New or reconnected viewers receive the latest state. A disconnected presenter is marked offline after approximately 25 seconds; the slide stays visible while they reconnect.

The event endpoint sets `text/event-stream`, disables caching/buffering and sends a heartbeat every ten seconds. Keep these responses unbuffered if adding a reverse proxy. Do not put an independent cache in front of `/api/`. If switching to multiple server instances later, replace the in-memory room store with a shared store plus pub/sub and preserve the authorization and idempotency checks.

## Acceptance checks on the published URL

Run `npm test` and `npm run build`, then verify:

- `/api/health` returns `ok: true`; the root URL renders the 3D presentation.
- A wrong presenter key cannot create a session.
- A new audience link opens the current slide without a login.
- Next/Back, sentence toggles and replay controls update an audience tab.
- Audience controls cannot change the live session. Independent browsing affects only that viewer; following again restores the latest presenter state.
- Refreshing the presenter tab preserves control. Refreshing or reconnecting an audience tab restores the current slide.
- Ending a session informs the audience and offers local browsing.

## Files to keep

Keep `package.json`, `package-lock.json`, `.replit`, TypeScript/Vite configuration, `server/`, `src/`, `public/` and `index.html`. `npm ci` installs dependencies and `npm run build` generates `build/` and `dist/`. Authoring notes and tests can stay in the project but are not served publicly. No external model API, database, or separate WebSocket service is needed for this version.
