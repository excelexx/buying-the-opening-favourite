import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins: [react()], server: { port: 5173, allowedHosts: process.env.REPLIT_DOMAINS?.split(',').filter(Boolean) }, base: './', build: { rollupOptions: { output: { manualChunks: { three: ['three', '@react-three/fiber', '@react-three/drei'], math: ['katex'] } } } } });
